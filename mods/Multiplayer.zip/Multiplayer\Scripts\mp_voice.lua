-- Multiplayer Hub: proximity voice. MPCore does the audio (voice.cpp): the microphone while you talk, Opus, sending
-- on the session's voice channel, and each other player's voice placed in 3D. This module tells it where you hear
-- from (the game camera), where everyone else in your level is (their puppet's head), and how much wall is in between
-- (line traces, 5 times a second), and keeps the settings (voice.txt beside the mod) and the two checks:
--   Test your voice: while you talk you hear yourself through Opus, as the others will, and the menu shows the
--   microphone's level.
--   Voice test block: a small block 3 m in front of you. Talk to record (up to 10 s); stop and it plays the
--   recording back on a loop from where it stands, so you can walk round it and hear distance, direction and walls.
-- Talking is V: held (mode "hold", push to talk) or pressed once to switch the microphone on and again to switch it off
-- (mode "toggle"; it starts off in each hub, and a HUD message says each switch). MPCore reads the key either way.
-- The microphone is only open in a hub with voice chat on, or while a check runs.

local UEHelpers = require("UEHelpers")

local voice = { enabled = true, volume = 1.0, mode = "hold", test = "off", why = "", devices = "" }
local net, players

local HEAD_CM = 150         -- a puppet's voice comes from about head height above its feet
local TRACE_EVERY = 0.2
local BLOCK_ID = "test-block"
local BLOCK_SIZE = 0.4      -- the cube is 100 cm; the block is 40 cm
local BLOCK_AHEAD_CM = 300
local LABEL_ABOVE_CM = 45
local BLOCK_TRACE_UP_CM = 40 -- wall traces aim at the block's top: floor edges and steps near its foot don't count
local VOLUMES = { 0.5, 0.75, 1.0, 1.25, 1.5, 2.0 }
local TALKING_COLOR = { R = 120, G = 255, B = 140, A = 255 }
local QUIET_COLOR = { R = 255, G = 255, B = 255, A = 255 }
local BLOCK_COLOR = { R = 0.75, G = 0.05, B = 0.05, A = 1.0 } -- tried as the cube's "Color"; the engine cube stays grey
local COMMON_LIBRARY = "/Game/Blueprints/BPFL_CommonFunctions.Default__BPFL_CommonFunctions_C"
local MESSAGE_COLOUR = { R = 0.95, G = 0.85, B = 1.0, A = 1.0 }

local settings_file
local running = false
local sources = {} -- source id -> true, while MPCore has it
local occlusion = {} -- source id -> 0 or 1
local last_trace = -1
local block = nil -- { address, world, x, y, z } while the test block stands
local tag_colors = {} -- peer -> "talking" | "quiet"
local mic_shown = nil -- toggle mode: the microphone switch last told on the HUD

local function valid(object)
    return object ~= nil and object:IsValid()
end

local function controller()
    local pc = FindFirstOf("PlayerController")
    if valid(pc) then return pc end
end

local function pawn()
    local pc = controller()
    if pc and valid(pc.Pawn) then return pc.Pawn end
end

local function save_settings()
    local file = settings_file and io.open(settings_file, "w")
    if not file then return end
    file:write(string.format("enabled=%d\nvolume=%.2f\nmode=%s\n", voice.enabled and 1 or 0, voice.volume, voice.mode))
    file:close()
end

local function load_settings()
    local file = settings_file and io.open(settings_file, "r")
    if not file then return end
    for line in file:lines() do
        local key, value = line:match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
        if key == "enabled" then voice.enabled = value ~= "0" end
        if key == "volume" then voice.volume = math.max(0.0, math.min(2.0, tonumber(value) or 1.0)) end
        if key == "mode" then voice.mode = value == "toggle" and "toggle" or "hold" end
    end
    file:close()
end

-- No game objects here: init runs on UE4SS's thread while the engine starts.
function voice.init(session, player_module, mod_dir)
    net, players = session, player_module
    settings_file = mod_dir .. "\\voice.txt"
    load_settings()
end

-- ---- The test block ---------------------------------------------------------------------------------------------

local function find_block()
    if not block then return nil end
    for _, actor in ipairs(FindAllOf("TextRenderActor") or {}) do
        if valid(actor) and actor:GetAddress() == block.address then return actor end
    end
    return nil
end

local function remove_block()
    local actor = find_block()
    if actor then pcall(function() actor:K2_DestroyActor() end) end
    block = nil
end

-- A TextRenderActor (rare in the game, so it is quick to find again) holding the label, with the cube under it.
local function spawn_block()
    local me = pawn()
    local pc = controller()
    if not me or not pc then return false, "no player to put it in front of" end
    local at = me:K2_GetActorLocation()
    local half = 90
    pcall(function() half = me.CapsuleComponent:GetScaledCapsuleHalfHeight() end)
    local yaw = math.rad(pc:GetControlRotation().Yaw)
    local x, y = at.X + math.cos(yaw) * BLOCK_AHEAD_CM, at.Y + math.sin(yaw) * BLOCK_AHEAD_CM
    -- It stands on the floor where it lands, which may be higher or lower than the player's (steps, slopes).
    local floor = at.Z - half
    pcall(function()
        local hit = {}
        if StaticFindObject("/Script/Engine.Default__KismetSystemLibrary"):LineTraceSingle(me, { X = x, Y = y, Z = at.Z + 150 },
                { X = x, Y = y, Z = at.Z - half - 300 }, 0, false, {}, 0, hit, true,
                { R = 0, G = 0, B = 0, A = 0 }, { R = 0, G = 0, B = 0, A = 0 }, 0) then
            floor = hit.ImpactPoint.Z
        end
    end)
    local center = { X = x, Y = y, Z = floor + BLOCK_SIZE * 50 }
    local label_at = { X = center.X, Y = center.Y, Z = center.Z + LABEL_ABOVE_CM }
    local actor = UEHelpers.GetWorld():SpawnActor(StaticFindObject("/Script/Engine.TextRenderActor"), label_at, { Pitch = 0, Yaw = 0, Roll = 0 })
    if not valid(actor) then return false, "the block could not be spawned" end
    local label = actor.TextRender
    pcall(function()
        label:SetHorizontalAlignment(1)
        label:SetWorldSize(18)
        label:K2_SetText(FText("Voice test block"))
    end)
    local mesh = StaticFindObject("/Engine/BasicShapes/Cube.Cube")
    if not valid(mesh) then
        pcall(function()
            mesh = StaticFindObject("/Script/AssetRegistry.Default__AssetRegistryHelpers"):GetAsset({
                PackageName = FName("/Engine/BasicShapes/Cube", EFindName.FNAME_Add), AssetName = FName("Cube", EFindName.FNAME_Add) })
        end)
    end
    local identity = { Rotation = { X = 0, Y = 0, Z = 0, W = 1 }, Translation = { X = 0, Y = 0, Z = 0 }, Scale3D = { X = 1, Y = 1, Z = 1 } }
    local cube = actor:AddComponentByClass(StaticFindObject("/Script/Engine.StaticMeshComponent"), false, identity, false)
    if valid(cube) and valid(mesh) then
        cube:SetStaticMesh(mesh)
        cube:K2_SetRelativeLocation({ X = 0, Y = 0, Z = -LABEL_ABOVE_CM }, false, {}, true)
        cube:SetRelativeScale3D({ X = BLOCK_SIZE, Y = BLOCK_SIZE, Z = BLOCK_SIZE })
        pcall(function() cube:SetCollisionEnabled(0) end) -- walk through it; line traces pass it
        pcall(function()
            local material = cube:CreateDynamicMaterialInstance(0, nil, FName("None"))
            material:SetVectorParameterValue(FName("Color"), BLOCK_COLOR)
        end)
    end
    local world = UEHelpers.GetWorld()
    block = { address = actor:GetAddress(), world = world:GetAddress(), x = center.X, y = center.Y, z = center.Z }
    return true
end

local function update_block_label(camera)
    local actor = find_block()
    if not actor then return end
    local state = voice.state and voice.state.test or ""
    local phase, seconds = state:match("^block (%a+) ([%d%.]+)$")
    local toggle = voice.mode == "toggle"
    local text = toggle and "Voice test block\nPress V to record" or "Voice test block\nHold V to record"
    if phase == "recording" then
        text = string.format(toggle and "Recording %.1f s\nPress V to play it back" or "Recording %.1f s\nLet go of V to play it back",
            tonumber(seconds) or 0)
    elseif phase == "playing" then
        text = string.format(toggle and "Playing back %.1f s\nPress V to record again" or "Playing back %.1f s\nHold V to record again",
            tonumber(seconds) or 0)
    end
    pcall(function()
        local label = actor.TextRender
        if label.Text:ToString() ~= text then label:K2_SetText(FText(text)) end
        if camera then
            local face = math.deg(math.atan(camera.Y - block.y, camera.X - block.x))
            label:K2_SetWorldRotation({ Pitch = 0, Yaw = face, Roll = 0 }, false, {}, true)
        end
    end)
end

-- ---- Settings and checks, for the menu ----------------------------------------------------------------------------

function voice.toggle_enabled()
    voice.enabled = not voice.enabled
    save_settings()
    net.log("Voice chat " .. (voice.enabled and "on" or "off"))
end

-- "hold" (push to talk) or "toggle" (a press of V switches the microphone on or off).
function voice.set_mode(mode)
    voice.mode = mode == "toggle" and "toggle" or "hold"
    mic_shown = nil
    save_settings()
    net.log("Voice talk mode: " .. voice.mode)
end

function voice.cycle_mode()
    voice.set_mode(voice.mode == "toggle" and "hold" or "toggle")
end

-- How you talk, for the menu texts.
function voice.talk_hint()
    return voice.mode == "toggle" and "Press V to switch your microphone on, and again to switch it off." or "Hold V to talk."
end

function voice.cycle_volume()
    local next_volume = VOLUMES[1]
    for i, v in ipairs(VOLUMES) do
        if math.abs(v - voice.volume) < 0.01 then next_volume = VOLUMES[i % #VOLUMES + 1] end
    end
    voice.volume = next_volume
    save_settings()
    net.log(string.format("Voice volume %d%%", math.floor(voice.volume * 100 + 0.5)))
end

function voice.toggle_test()
    voice.test = voice.test == "loopback" and "off" or "loopback"
    if voice.test == "loopback" then remove_block() end
    net.log("Voice test: " .. voice.test)
end

function voice.toggle_block()
    if block then
        remove_block()
        voice.test = "off"
        net.log("Voice test block removed")
        return
    end
    local ok, why = spawn_block()
    if ok then
        voice.test = "block"
        net.log(string.format("Voice test block at (%.0f, %.0f, %.0f)", block.x, block.y, block.z))
    else
        net.log("No voice test block: " .. tostring(why))
    end
end

function voice.has_block()
    return block ~= nil
end

-- The microphone's level as a bar for the menu.
function voice.meter()
    local state = voice.state
    if not state or not state.running then return "Microphone: off" end
    if state.devices == "" or state.devices:sub(1, 1) == "|" then return "No microphone found" end
    local filled = math.floor((state.level or 0) * 24 + 0.5)
    local label = state.talking and "Talking  " or (voice.mode == "toggle" and "Mic off  " or "Mic  ")
    return label .. string.rep("|", filled) .. string.rep(".", 24 - filled)
end

-- Toggle mode: a HUD message each time the microphone is switched (not when voice starts; it starts off).
local function tell_mic(on)
    if mic_shown == nil then
        mic_shown = on
        return
    end
    if on == mic_shown then return end
    mic_shown = on
    local text = on and "Microphone on. Press V to switch it off." or "Microphone off. Press V to talk."
    if on and (voice.devices == "" or voice.devices:sub(1, 1) == "|") then text = "No microphone found." end
    net.log("Voice: " .. text)
    local me = pawn()
    if me then
        pcall(function() StaticFindObject(COMMON_LIBRARY):ShowHudMessage(FText(text), MESSAGE_COLOUR, me) end)
    end
end

-- ---- Each frame ---------------------------------------------------------------------------------------------------

local function wanted()
    return (net.in_session() and voice.enabled) or voice.test ~= "off"
end

local function start()
    local ok, started, why
    if voice.test_options then
        ok, started, why = pcall(MPCore_VoiceStart, true, voice.test_options.input or "", voice.test_options.output or "")
    else
        ok, started, why = pcall(MPCore_VoiceStart)
    end
    if not ok then
        voice.why = "MPCore has no voice: " .. tostring(started)
        net.log(voice.why)
        voice.unavailable = true
        return
    end
    running = started == true
    voice.why = why or ""
    local _, _, _, _, devices = MPCore_VoiceState()
    voice.devices = devices or ""
    net.log(string.format("Voice %s; microphone '%s', speakers '%s'%s", running and "on" or "could not start",
        voice.devices:match("^([^|]*)") or "", voice.devices:match("|(.*)$") or "", voice.why ~= "" and (" (" .. voice.why .. ")") or ""))
    voice.applied = nil
end

local function stop()
    MPCore_VoiceStop()
    running = false
    sources = {}
    occlusion = {}
    mic_shown = nil
    net.log("Voice off")
end

-- 1 when the line from the camera to a point is blocked (walls; puppets and the block have no collision).
local function blocked(camera, x, y, z)
    local ok, hit = pcall(function()
        return StaticFindObject("/Script/Engine.Default__KismetSystemLibrary"):LineTraceSingle(pawn() or UEHelpers.GetWorld(),
            camera, { X = x, Y = y, Z = z }, 0, false, {}, 0, {}, true,
            { R = 0, G = 0, B = 0, A = 0 }, { R = 0, G = 0, B = 0, A = 0 }, 0)
    end)
    return (ok and hit == true) and 1 or 0
end

function voice.tick(seconds, level)
    if voice.unavailable or not MPCore_VoiceStart then return end
    if block then
        local world = UEHelpers.GetWorld()
        if not valid(world) or world:GetAddress() ~= block.world then
            block = nil -- gone with its level
            if voice.test == "block" then voice.test = "off" end
        end
    end
    if wanted() and not running then start() end
    if not wanted() and running then stop() end
    if not running then
        voice.state = nil
        return
    end
    local applied = string.format("%s|%.2f|%s|%s", tostring(voice.enabled), voice.volume, voice.mode, voice.test)
    if applied ~= voice.applied then
        voice.applied = applied
        MPCore_VoiceSettings(voice.enabled, voice.volume, voice.mode)
        MPCore_VoiceTest(voice.test)
    end
    local up, talking, mic_level, test_state, devices, stats, mic_on = MPCore_VoiceState()
    voice.state = { running = up, talking = talking, level = mic_level, test = test_state, devices = devices, stats = stats,
        mic_on = mic_on == true }
    if voice.mode == "toggle" then tell_mic(mic_on == true) end

    local pc = controller()
    local camera, yaw
    pcall(function()
        camera = pc.PlayerCameraManager:GetCameraLocation()
        yaw = pc.PlayerCameraManager:GetCameraRotation().Yaw
    end)
    if not camera then return end
    MPCore_VoiceListener(camera.X, camera.Y, camera.Z, yaw)

    local trace = seconds - last_trace >= TRACE_EVERY
    if trace then last_trace = seconds end
    local seen = {}
    for peer, where in pairs(players.displayed()) do
        seen[peer] = true
        local z = where.Z + HEAD_CM
        if trace then occlusion[peer] = blocked(camera, where.X, where.Y, z) end
        MPCore_VoiceSource(peer, where.X, where.Y, z, occlusion[peer] or 0)
        sources[peer] = true
        local now = MPCore_VoicePeerTalking(peer) and "talking" or "quiet"
        if tag_colors[peer] ~= now then
            tag_colors[peer] = now
            players.color_tag(peer, now == "talking" and TALKING_COLOR or QUIET_COLOR)
        end
    end
    if block and voice.test == "block" then
        seen[BLOCK_ID] = true
        if trace then occlusion[BLOCK_ID] = blocked(camera, block.x, block.y, block.z + BLOCK_TRACE_UP_CM) end
        MPCore_VoiceSource(BLOCK_ID, block.x, block.y, block.z, occlusion[BLOCK_ID] or 0)
        sources[BLOCK_ID] = true
        update_block_label(camera)
    end
    for id in pairs(sources) do
        if not seen[id] then
            MPCore_VoiceRemove(id) -- left, or in another level
            sources[id] = nil
            occlusion[id] = nil
            tag_colors[id] = nil
        end
    end
end

-- For a test: what the wall trace to the block runs into, in a few variants.
function voice.trace_probe(log)
    local pc = controller()
    local camera = pc and pc.PlayerCameraManager:GetCameraLocation()
    if not camera or not block then return end
    local system = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
    local function try(label, context, ignore_self, to, ignore)
        local out = {}
        local ok, hit = pcall(function()
            return system:LineTraceSingle(context, camera, to, 0, false, ignore or {}, 0, out, ignore_self,
                { R = 0, G = 0, B = 0, A = 0 }, { R = 0, G = 0, B = 0, A = 0 }, 0)
        end)
        local keys = {}
        for key, value in pairs(out) do keys[#keys + 1] = tostring(key) .. "=" .. tostring(value) end
        local what = ""
        pcall(function() what = " actor " .. out.HitObjectHandle.Actor:GetFullName() end)
        pcall(function() what = what .. " component " .. out.Component:GetFullName() end)
        pcall(function() what = what .. string.format(" at (%.0f, %.0f, %.0f)", out.ImpactPoint.X, out.ImpactPoint.Y, out.ImpactPoint.Z) end)
        log(string.format("Trace probe %s: ok %s, hit %s (%s), out {%s}%s", label, tostring(ok), tostring(hit), type(hit),
            table.concat(keys, ", "), what))
    end
    local center = { X = block.x, Y = block.y, Z = block.z }
    local above = { X = block.x, Y = block.y, Z = block.z + 150 }
    try("to the block, pawn as context", pawn(), true, center)
    try("to 1.5 m above the block", pawn(), true, above)
    try("to the block, world as context", UEHelpers.GetWorld(), false, center)
    local actor = find_block()
    if actor then try("to the block, ignoring it", pawn(), true, center, { actor }) end
    pcall(function()
        local cube = actor and actor:GetComponentByClass(StaticFindObject("/Script/Engine.StaticMeshComponent"))
        log("Trace probe: the block's cube collision is " .. tostring(cube and cube:GetCollisionEnabled()))
    end)
end

-- For tests and logs.
function voice.block_position()
    return block and { X = block.x, Y = block.y, Z = block.z } or nil
end

function voice.occlusion(id)
    return occlusion[id]
end

return voice
