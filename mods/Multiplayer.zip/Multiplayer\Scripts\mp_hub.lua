-- Multiplayer Hub: hub mode. In a session the Starting Hall is the hub: every portal is switched on, and holding E on
-- one (or on the Backrooms door) is taken over just before the game would travel, and the whole lobby goes as a party
-- (mp_party). Hosting or joining (from the browser, mp_browser) switches to the multiplayer character (mp_character)
-- and travels there; quitting to the main menu ends the session. Steam invites: one that starts the game
-- ("+connect_lobby") joins from the main menu, and one accepted while the game runs (or Join Game on a friend) joins
-- once you are in the main menu or the hub, so it never pulls you out of a run.

local UEHelpers = require("UEHelpers")

local hub = { level = "StartingHall", menu_level = "MenuMap", leaving = false }
local net

local INTERACT_CLASS = "/Game/Blueprints/Components/BP_InteractableObject.BP_InteractableObject_C"
local HOLD_TAKEOVER_SECONDS = 0.12
-- Doors whose hold takes the party along: the portals, and the Backrooms mod's door (a plain area door).
local PARTY_DOORS = { BP_DoorPortal_C = true, BP_BaseAreaDoor_C = true }
local INVITE_CHECK_EVERY = 0.5
-- World events the hall's level script checks when it loads. At stage 0 "SavinaIntroDia" moves the player in front of
-- Savina and starts her first dialogue, which happens whenever the hall opens without a save loaded (as from the main
-- menu), so a hub marks it seen. Only in the game instance's memory, and put back when the session ends.
local QUIET_EVENTS = { SavinaIntroDia = 1 }

local hooked = {}
local portals_done_for = nil
local holds = {}
local pending_lobby = nil -- a Steam lobby to join once in the main menu or the hub
local travel_requested = false
local arrived = false -- reached the hub in this session, so a later main menu means the player left
local last_invite_check = -1
local quieted = nil -- world event -> its stage before the hub (false: it had none), while the hub has them set

local function valid(object)
    return object ~= nil and object:IsValid()
end

local function fname(text)
    return FName(text, EFindName.FNAME_Add)
end

local function statics()
    return StaticFindObject("/Script/Engine.Default__GameplayStatics")
end

local function game_seconds()
    local ok, result = pcall(function() return statics():GetTimeSeconds(UEHelpers.GetWorld()) end)
    return ok and result or 0
end

local function hook(path, callback)
    if hooked[path] then return end
    local ok = pcall(RegisterHook, path, function(...)
        local ok_call, problem = pcall(callback, ...)
        if not ok_call then net.log("Hook error: " .. tostring(problem)) end
    end)
    if ok then hooked[path] = true end
end

local function world_events()
    local ok, events = pcall(function() return statics():GetGameInstance(UEHelpers.GetWorld()).WorldEvents end)
    if ok then return events end
    return nil
end

local function plain(value)
    if type(value) == "userdata" then
        local ok, inner = pcall(function() return value:get() end)
        if ok then return inner end
    end
    return value
end

local function quiet_story()
    if quieted then return end
    local events = world_events()
    if not events then return end
    quieted = {}
    for key, stage in pairs(QUIET_EVENTS) do
        local before = false
        pcall(function()
            if events:Contains(key) then before = plain(events:Find(key)) end
        end)
        quieted[key] = before
        local ok, problem = pcall(function() events:Add(key, stage) end)
        net.log(ok and string.format("Hub: world event %s set to %d (was %s)", key, stage, tostring(before))
            or ("Hub: could not set world event " .. key .. ": " .. tostring(problem)))
    end
end

local function restore_story()
    if not quieted then return end
    local events = world_events()
    if events then
        for key, before in pairs(quieted) do
            pcall(function()
                if before == false then events:Remove(key) else events:Add(key, before) end
            end)
            net.log("Hub: world event " .. key .. " put back to " .. tostring(before))
        end
    end
    quieted = nil
end

function hub.go()
    if travel_requested then return end
    travel_requested = true
    local switched = hub.character and hub.character.begin()
    quiet_story()
    if hub.party then
        hub.party.travel(hub.level, nil, switched == true)
    else
        statics():OpenLevel(UEHelpers.GetWorld(), fname(hub.level), true, "")
    end
end

function hub.go_menu()
    arrived = false
    hub.leaving = true
    statics():OpenLevel(UEHelpers.GetWorld(), fname(hub.menu_level), true, "")
end

local function portals()
    local list = {}
    for _, portal in ipairs(FindAllOf("BP_DoorPortal_C") or {}) do
        if valid(portal) then list[#list + 1] = portal end
    end
    return list
end

local function on_hold_start(interact)
    local owner = interact:GetOwner()
    if not valid(owner) or not net.in_session() then return end
    local ok, class = pcall(function() return owner:GetClass():GetFName():ToString() end)
    if ok and PARTY_DOORS[class] then
        holds[owner:GetAddress()] = { interact = interact, door = owner, started = game_seconds(), time = interact.InteractTime,
            map = owner.MapName:ToString() }
    end
end

-- No game objects here: init runs on UE4SS's thread while the engine is still starting.
function hub.init(session)
    net = session
    net.on("state", function(state)
        if state == "hosting" and not hub.is_test then
            hub.go()
            net.log(MPCore_Invite() and "Asked Steam to open its invite window" or "No Steam hub to invite to")
        elseif state == "joined" then
            hub.go()
        elseif not net.in_session() then
            travel_requested = false
        end
    end)
    local launch = MPCore_LaunchLobby and MPCore_LaunchLobby() or ""
    if launch ~= "" then
        pending_lobby = launch
        net.log("Started from a Steam invite to hub " .. launch)
    end
end

local function check_invites(seconds, level)
    if seconds - last_invite_check < INVITE_CHECK_EVERY then return end
    last_invite_check = seconds
    local ok, lobby = pcall(function() return MPCore_TakeInvite and MPCore_TakeInvite() or "" end)
    if ok and lobby and lobby ~= "" then
        if net.hub == "steam:" .. lobby then
            net.log("Steam invite to the hub you are already in")
        else
            pending_lobby = lobby
            local here = level == hub.menu_level or level == hub.level
            net.log("Steam invite accepted for hub " .. lobby .. (here and "" or "; joining once you are in the main menu or the hub"))
        end
    end
    if pending_lobby and (level == hub.menu_level or level == hub.level) then
        local lobby_to_join = pending_lobby
        pending_lobby = nil
        if net.in_session() then net.leave() end
        local joined, why = net.join_steam(lobby_to_join)
        net.log(joined and ("Joining hub " .. lobby_to_join .. " from a Steam invite") or ("Could not join the hub: " .. tostring(why)))
    end
end

function hub.tick(seconds, level)
    if level == hub.menu_level then hub.leaving = false end
    check_invites(seconds, level)
    if level == hub.menu_level and arrived and net.in_session() then
        -- Back in the main menu after being in the hub (the game's own Quit to Main Menu, for one): the session ends.
        arrived = false
        net.log("Back in the main menu, so leaving the hub")
        net.leave()
    end
    if quieted and not net.in_session() and not travel_requested and level ~= hub.level then
        restore_story()
    end
    if level ~= hub.level then
        portals_done_for = nil
        return
    end
    travel_requested = false -- arrived
    if not net.in_session() then return end
    arrived = true
    local world = UEHelpers.GetWorld()
    local address = valid(world) and world:GetAddress() or 0
    if portals_done_for ~= address then
        local list = portals()
        if #list > 0 then
            portals_done_for = address
            for _, portal in ipairs(list) do pcall(function() portal:Activate() end) end
            net.log("Hub mode: " .. #list .. " portals on")
        end
    end
    hook(INTERACT_CLASS .. ":StartInteractTimer", function(self) on_hold_start(self:get()) end)
    for address_key, hold in pairs(holds) do
        if game_seconds() - hold.started >= hold.time - HOLD_TAKEOVER_SECONDS then
            holds[address_key] = nil
            pcall(function() hold.interact:CancelHeldInteraction() end)
            if hub.party and valid(hold.door) then
                hub.party.start(hold.door)
            else
                net.log("Door to " .. hold.map .. ": no party module")
            end
        end
    end
end

return hub
