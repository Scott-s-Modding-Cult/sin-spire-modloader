-- Multiplayer Hub: players. Sends where you are 20 times a second and shows everyone else in your level as a puppet
-- (the player body on a SkeletalMeshActor), drawn 100 ms in the past and smoothed between updates, with a name tag
-- that turns to your camera. Placeholder until the walk and run clips exist: the body's rest pose, so puppets slide.
-- Message: S|session time|x|y|z (feet, cm)|yaw|speed|flags|level

local UEHelpers = require("UEHelpers")

local players = {}
local net

local SEND_EVERY = 0.05
local INTERP_DELAY = 0.10
local MAX_EXTRAPOLATE = 0.25
local MESH_YAW = -90.0 -- the player rig faces its mesh's +Y
local MAX_SNAPS = 40
local LIMIT = 10000000.0 -- coordinates beyond this are ignored
-- A joining player's session clock starts on their own PC's clock and switches to the host's at the first ping answer,
-- so it can jump back by hours. An update this much older than the newest one is such a jump, not a late packet.
local CLOCK_RESET = 1.0

local remote = {} -- peer id -> { name, level, snaps = {}, puppet }
local last_send = -1
local assets = {}
local identity = {
    Rotation = { X = 0.0, Y = 0.0, Z = 0.0, W = 1.0 },
    Translation = { X = 0.0, Y = 0.0, Z = 0.0 },
    Scale3D = { X = 1.0, Y = 1.0, Z = 1.0 },
}

local function valid(object)
    return object ~= nil and object:IsValid()
end

local function fname(text)
    return FName(text, EFindName.FNAME_Add)
end

local function load_asset(package, asset)
    local found = StaticFindObject(package .. "." .. asset)
    if valid(found) then return found end
    local helpers = StaticFindObject("/Script/AssetRegistry.Default__AssetRegistryHelpers")
    local loaded = helpers:GetAsset({ PackageName = fname(package), AssetName = fname(asset) })
    if valid(loaded) then return loaded end
    return nil
end

local function controller()
    local pc = FindFirstOf("PlayerController")
    if valid(pc) then return pc end
end

local function pawn()
    local pc = controller()
    if pc and valid(pc.Pawn) then return pc.Pawn end
end

local function on_state(peer, f)
    local t, x, y, z, yaw = tonumber(f[2]), tonumber(f[3]), tonumber(f[4]), tonumber(f[5]), tonumber(f[6])
    if not (t and x and y and z and yaw) or math.abs(x) > LIMIT or math.abs(y) > LIMIT or math.abs(z) > LIMIT then
        return
    end
    local r = remote[peer]
    if not r then
        r = { name = net.peers[peer] and net.peers[peer].name or "Player", snaps = {} }
        remote[peer] = r
    end
    r.level = (f[9] or ""):sub(1, 64)
    local snaps = r.snaps
    if not r.heard then
        r.heard = true
        net.log(string.format("First position from %s: level %s, their clock %.1f s, ours %.1f s", r.name, r.level, t, net.now()))
    end
    if #snaps > 0 and t <= snaps[#snaps].t then
        local back = snaps[#snaps].t - t
        if back <= CLOCK_RESET then
            return -- late or repeated (positions travel unreliably)
        end
        -- Their clock was set back (a guest switching to the host's clock): start again from this update.
        net.log(string.format("%s's clock went back %.1f s; following it from now", r.name, back))
        for i = #snaps, 1, -1 do snaps[i] = nil end
    end
    snaps[#snaps + 1] = { t = t, x = x, y = y, z = z, yaw = yaw, speed = tonumber(f[7]) or 0, flags = tonumber(f[8]) or 0 }
    while #snaps > MAX_SNAPS do
        table.remove(snaps, 1)
    end
end

local function despawn(r)
    if r and r.puppet then
        if valid(r.puppet.actor) then
            r.puppet.actor:K2_DestroyActor()
        end
        r.puppet = nil
    end
end

-- Held poses on the player skeleton, until the walk and run clips exist: { package, asset, time in the clip }.
-- Puppets use none (the rest pose, arms out): the test lineup showed walksout's first frame puts the body 4.6 m from
-- the actor (the clip is placed for the ending scene), fists is a raised-fists stance, standing a bent sex-scene pose.
local POSES = {
    walksout = { "/Game/Models/Characters/Savina/Anims/PlayerWalksOut", "PlayerWalksOut", 0.0 },
    fists = { "/Game/Animations/Weapons/FP/Fists/Plr_Fist_Idle", "Plr_Fist_Idle", 0.0 },
    standing = { "/Game/Models/Characters/Monsters/Manneq/Anims/Mannequin_SexStanding01_PLR1", "Mannequin_SexStanding01_PLR1", 0.0 },
}
players.pose = "none"

-- A player body with a held pose (none: the mesh's rest pose) and a name tag. yaw is the player's facing.
function players.figure(at, yaw, pose_name, label)
    if not assets.mesh then
        assets.mesh = load_asset("/Game/Models/Characters/Human/Player/SK_PlayerCharacter", "SK_PlayerCharacter")
    end
    if not assets.mesh then
        return nil
    end
    local actor = UEHelpers.GetWorld():SpawnActor(StaticFindObject("/Script/Engine.SkeletalMeshActor"), at,
        { Pitch = 0, Yaw = yaw + MESH_YAW, Roll = 0 })
    if not valid(actor) then
        return nil
    end
    local mesh = actor.SkeletalMeshComponent
    mesh:SetSkinnedAssetAndUpdate(assets.mesh, false)
    pcall(function() mesh:SetCollisionEnabled(0) end) -- nothing bumps into a puppet, and voice wall traces pass it
    local pose = POSES[pose_name or ""]
    if pose then
        assets[pose_name] = assets[pose_name] or load_asset(pose[1], pose[2])
        local clip = assets[pose_name]
        if clip then
            mesh:SetAnimationMode(1, true)
            mesh:PlayAnimation(clip, false)
            mesh:SetPosition(pose[3], false)
            mesh:SetPlayRate(0.0)
        end
    end
    local tag = actor:AddComponentByClass(StaticFindObject("/Script/Engine.TextRenderComponent"), false, identity, false)
    if valid(tag) then
        tag:K2_SetRelativeLocation({ X = 0, Y = 0, Z = 205 }, false, {}, true)
        tag:SetHorizontalAlignment(1)
        tag:SetWorldSize(22)
        tag:K2_SetText(FText(label or "Player"))
    end
    return actor, mesh, tag
end

-- Where a figure's body really is, for test logs: the actor, and the root, pelvis and head bones in the world.
function players.describe(actor)
    if not valid(actor) then
        return "gone"
    end
    local mesh = actor.SkeletalMeshComponent
    local at = actor:K2_GetActorLocation()
    local parts = { string.format("actor (%.0f, %.0f, %.0f)", at.X, at.Y, at.Z) }
    pcall(function()
        local asset = mesh:GetSkinnedAsset()
        parts[#parts + 1] = "mesh " .. (valid(asset) and asset:GetFName():ToString() or "none")
    end)
    pcall(function() parts[#parts + 1] = "visible " .. tostring(mesh:IsVisible()) end)
    for _, bone in ipairs({ "root", "pelvis", "head" }) do
        pcall(function()
            local p = mesh:GetSocketLocation(fname(bone))
            parts[#parts + 1] = string.format("%s (%.0f, %.0f, %.0f)", bone, p.X, p.Y, p.Z)
        end)
    end
    return table.concat(parts, ", ")
end

local function spawn(r, at)
    local actor, mesh, tag = players.figure(at, 0.0, players.pose, r.name)
    if actor then
        r.puppet = { actor = actor, mesh = mesh, tag = tag, named = r.name }
    end
end

local function lerp(a, b, f)
    return a + (b - a) * f
end

local function lerp_yaw(a, b, f)
    local d = ((b - a + 540.0) % 360.0) - 180.0
    return a + d * f
end

-- Where a peer was at session time t: between two updates, or carried on briefly past the last one.
local function sample(r, t)
    local snaps = r.snaps
    local n = #snaps
    if n == 0 then return nil end
    if t <= snaps[1].t then
        return snaps[1].x, snaps[1].y, snaps[1].z, snaps[1].yaw
    end
    for i = n - 1, 1, -1 do
        local a, b = snaps[i], snaps[i + 1]
        if a.t <= t and t <= b.t then
            local f = (t - a.t) / math.max(b.t - a.t, 0.0001)
            return lerp(a.x, b.x, f), lerp(a.y, b.y, f), lerp(a.z, b.z, f), lerp_yaw(a.yaw, b.yaw, f)
        end
    end
    local last, previous = snaps[n], snaps[n - 1]
    if previous and last.t > previous.t then
        local ahead = math.min(t - last.t, MAX_EXTRAPOLATE)
        local span = last.t - previous.t
        return last.x + (last.x - previous.x) / span * ahead, last.y + (last.y - previous.y) / span * ahead,
            last.z + (last.z - previous.z) / span * ahead, last.yaw
    end
    return last.x, last.y, last.z, last.yaw
end

local function send_state(level)
    local me = pawn()
    -- Only the player character has a capsule; the main menu's pawn does not.
    if not me or level == "MenuMap" or not valid(me.CapsuleComponent) then return end
    local at = me:K2_GetActorLocation()
    local half = me.CapsuleComponent:GetScaledCapsuleHalfHeight()
    local yaw = me:K2_GetActorRotation().Yaw
    local v = me:GetVelocity()
    local speed = math.sqrt(v.X * v.X + v.Y * v.Y)
    net.send("*", 1, false, "S", string.format("%.3f", net.now()), string.format("%.1f", at.X), string.format("%.1f", at.Y),
        string.format("%.1f", at.Z - half), string.format("%.1f", yaw), string.format("%.0f", speed), 0, level)
end

function players.init(session)
    net = session
    net.on("msg:S", on_state)
    net.on("join", function(peer, name)
        remote[peer] = remote[peer] or { name = name, snaps = {} }
        remote[peer].name = name
    end)
    net.on("leave", function(peer)
        despawn(remote[peer])
        remote[peer] = nil
    end)
    net.on("state", function(state)
        if state ~= "hosting" and state ~= "joined" then
            for _, r in pairs(remote) do despawn(r) end
            remote = {}
        end
    end)
end

-- A puppet's name tag colour (voice: green while that player talks). color is an FColor table.
function players.color_tag(peer, color)
    local r = remote[peer]
    if r and r.puppet and valid(r.puppet.tag) then
        pcall(function() r.puppet.tag:SetTextRenderColor(color) end)
    end
end

-- The puppet actors, for test logs: peer id -> actor.
function players.puppets()
    local out = {}
    for peer, r in pairs(remote) do
        if r.puppet and valid(r.puppet.actor) then
            out[peer] = r.puppet.actor
        end
    end
    return out
end

-- Where a peer is drawn at session time t, and how many updates are kept: for tests.
function players.sample_for(peer, t)
    local r = remote[peer]
    if not r then return nil end
    local x, y, z, yaw = sample(r, t)
    return x, y, z, yaw, #r.snaps
end

-- Displayed positions for the test log: peer id -> x, y, z.
function players.displayed()
    local out = {}
    for peer, r in pairs(remote) do
        if r.puppet and valid(r.puppet.actor) then
            out[peer] = r.puppet.actor:K2_GetActorLocation()
        end
    end
    return out
end

function players.tick(seconds, level)
    if not net.in_session() then return end
    if seconds - last_send >= SEND_EVERY then
        last_send = seconds
        send_state(level)
    end
    local camera
    local pc = controller()
    if pc and valid(pc.PlayerCameraManager) then
        camera = pc.PlayerCameraManager:GetCameraLocation()
    end
    local now = net.now()
    for peer, r in pairs(remote) do
        local name = net.peers[peer] and net.peers[peer].name
        if name then r.name = name end
        if r.level ~= level or #r.snaps == 0 then
            despawn(r)
        else
            if r.puppet and not valid(r.puppet.actor) then
                r.puppet = nil -- gone with the old level
            end
            local x, y, z, yaw = sample(r, now - INTERP_DELAY)
            if x then
                if not r.puppet then
                    spawn(r, { X = x, Y = y, Z = z })
                end
                local p = r.puppet
                if p then
                    p.actor:K2_SetActorLocationAndRotation({ X = x, Y = y, Z = z }, { Pitch = 0, Yaw = yaw + MESH_YAW, Roll = 0 },
                        false, {}, true)
                    if valid(p.tag) then
                        if p.named ~= r.name then
                            p.tag:K2_SetText(FText(r.name or "Player"))
                            p.named = r.name
                        end
                        if camera then
                            -- Turn the tag to face the camera (TextRender faces its +X).
                            local face = math.deg(math.atan(camera.Y - y, camera.X - x))
                            p.tag:K2_SetWorldRotation({ Pitch = 0, Yaw = face, Roll = 0 }, false, {}, true)
                        end
                    end
                end
            end
        end
    end
end

return players
