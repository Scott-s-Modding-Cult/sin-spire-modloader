-- Multiplayer Hub: the multiplayer character. In a session everyone plays a separate character with its own save slot,
-- Multiplayer.sav, made the first time as a copy of their campaign save (weapons, perks, money, story). Runs write saves
-- (every door and portal autosaves, and so does a level-up), so while this character is in use every read or write of a
-- campaign slot goes to the multiplayer slot instead: the slot name is changed as the game calls SaveGameToSlot,
-- LoadGameFromSlot or DoesSaveGameExist. The campaign's files are never written.
-- The character stays in use after a session ends until you are back in the main menu, and only then is the game
-- pointed back at the campaign's slot, so nothing played as this character can reach a campaign save.

local UEHelpers = require("UEHelpers")

local character = { slot = "Multiplayer", active = false }
local net

-- Slots that are never the campaign's: the game's unlocks and stats, and the dungeon builder's cache.
local NOT_CAMPAIGN = { MetaSave = true, Initialiazation_map = true }
local CAMPAIGN = { Autosave = true, Endsave = true, default = true }
local PROFILE_SAVE_CLASS = "SG_ProfileSave_C"
local HOOKS = {
    save = "/Script/Engine.GameplayStatics:SaveGameToSlot",
    load = "/Script/Engine.GameplayStatics:LoadGameFromSlot",
    exists = "/Script/Engine.GameplayStatics:DoesSaveGameExist",
}

local hooked = {}
local redirected = 0

local function valid(object)
    return object ~= nil and object:IsValid()
end

local function statics()
    return StaticFindObject("/Script/Engine.Default__GameplayStatics")
end

local function game_instance()
    local ok, gi = pcall(function() return statics():GetGameInstance(UEHelpers.GetWorld()) end)
    if ok and valid(gi) then return gi end
    return nil
end

local function text(value)
    local ok, result = pcall(function() return value:ToString() end)
    if ok then return result end
    return tostring(value)
end

local function exists(slot)
    local ok, result = pcall(function() return statics():DoesSaveGameExist(slot, 0) end)
    return ok and result == true
end

-- Is this a campaign slot, to be sent to the multiplayer one?
local function is_campaign(slot, object)
    if slot == character.slot or NOT_CAMPAIGN[slot] then return false end
    if CAMPAIGN[slot] or slot == character.campaign_profile then return true end
    if object then
        local ok, class = pcall(function() return object:GetClass():GetFName():ToString() end)
        return ok and class == PROFILE_SAVE_CLASS
    end
    return false
end

local function redirect(kind, slot_param, object)
    if not character.active then return end
    local slot = text(slot_param:get())
    if is_campaign(slot, object) then
        slot_param:set(character.slot)
        redirected = redirected + 1
        if redirected <= 20 or redirected % 50 == 0 then
            net.log(string.format("Character: %s of slot %s went to %s (%d so far)", kind, slot, character.slot, redirected))
        end
    end
end

-- Native functions, so the hooks run before the game's call and can change its slot name. Registered once, from the
-- game thread.
local function install_hooks()
    local function add(key, fn)
        if hooked[key] then return end
        local ok, problem = pcall(RegisterHook, HOOKS[key], function(...)
            local ok_call, err = pcall(fn, ...)
            if not ok_call then net.log("Character hook error (" .. key .. "): " .. tostring(err)) end
        end)
        hooked[key] = ok
        if not ok then net.log("Character: could not hook " .. HOOKS[key] .. ": " .. tostring(problem)) end
    end
    add("save", function(_, object, slot) redirect("save", slot, object:get()) end)
    add("load", function(_, slot) redirect("load", slot) end)
    add("exists", function(_, slot) redirect("check", slot) end)
end

-- The campaign save to copy: the profile the game last used, else the autosave, else any other.
local function campaign_source()
    for _, slot in ipairs({ character.campaign_profile, "Autosave", "default", "Endsave" }) do
        if slot and slot ~= "" and slot ~= character.slot and not NOT_CAMPAIGN[slot] and exists(slot) then return slot end
    end
    return nil
end

local function create()
    local source = campaign_source()
    if not source then
        net.log("Character: no campaign save to copy, so the multiplayer character starts new")
        return false
    end
    local ok, problem = pcall(function()
        local save = statics():LoadGameFromSlot(source, 0)
        if not valid(save) then error("the save in " .. source .. " did not load") end
        if not statics():SaveGameToSlot(save, character.slot, 0) then error("SaveGameToSlot refused") end
    end)
    net.log(ok and ("Character: made the multiplayer character from your save in slot " .. source)
        or ("Character: could not copy slot " .. source .. ": " .. tostring(problem)))
    return ok
end

function character.init(session)
    net = session
end

-- Switches to the multiplayer character, before travelling to the hub. Its state goes into the game instance through
-- the game's own LoadGame, which the player picks up when it appears in the hub. True if it switched just now (so the
-- player standing here, if any, is still the campaign's and must not be saved), false if it was already in use.
function character.begin()
    install_hooks()
    if character.active then return false end
    local gi = game_instance()
    if not gi then
        net.log("Character: no game instance yet")
        return nil
    end
    character.campaign_profile = text(gi.CurrentProfileName)
    if not exists(character.slot) then create() end
    character.active = true
    gi.CurrentProfileName = character.slot
    if exists(character.slot) then
        gi.NewGame = false
        local out = {}
        local ok, problem = pcall(function() gi:LoadGame(out) end)
        net.log(ok and string.format("Character: playing the multiplayer character (loaded %s, campaign profile %s)",
            tostring(out.LoadSuccessful), character.campaign_profile)
            or ("Character: LoadGame failed: " .. tostring(problem)))
    else
        gi.LoadingFromSave = false
        net.log("Character: playing a new multiplayer character (campaign profile " .. character.campaign_profile .. ")")
    end
    return true
end

-- Writes the character's slot now, through the game's own SaveProfileProgress (which also takes the player's state).
-- Only once the game has put the character's state on the player in this level, or it would save an empty player.
function character.save(player)
    if not character.active or not valid(player) then return false end
    local gi = game_instance()
    if not gi then return false end
    gi.CurrentProfileName = character.slot
    local ok, problem = pcall(function() gi:SaveProfileProgress(player) end)
    if not ok then net.log("Character: saving failed: " .. tostring(problem)) end
    return ok
end

-- Back to the campaign: only in the main menu, where the next game is loaded from its slot.
function character.finish()
    if not character.active then return end
    local gi = game_instance()
    if not gi then return end
    character.active = false
    gi.CurrentProfileName = character.campaign_profile or "Autosave"
    gi.LoadingFromSave = false
    net.log(string.format("Character: back to the campaign profile %s (%d slot calls went to the multiplayer slot)",
        tostring(character.campaign_profile), redirected))
end

function character.tick(seconds, level)
    if character.active and not net.in_session() and level == "MenuMap" then
        character.finish()
    end
end

return character
