-- Multiplayer Hub: the hub browser and the in-hub menu. Both are a submenu of the game's own Extras menu, next to its
-- Boss Rush and Challenges submenus, made of the game's own Extras buttons. The game's pause menu (which is also the
-- main menu) already moves a highlight over the active submenu's buttons with the D-pad, presses with A and goes back
-- with B, and each button fires its row's event through the game's event manager, so the submenu takes the mouse and
-- the controller the way the rest of the menu does, and looks like it.
--
-- Main menu: Extras > Multiplayer Hub lists Host a hub, then your Steam friends' hubs to join.
-- In a hub: the pause menu's own Extras button, which the game hides during play, comes back as "Multiplayer Hub" and
-- opens the same submenu with Invite friends, everyone in the hub with their ping, and Leave hub. Back (or B) returns
-- to the pause menu.
--
-- Every button fires event MultiplayerHub with a message: "" opens the submenu, then "host", "join:<lobby>",
-- "udp:<ip>:<port>" (test hubs), "cancel", "invite", "leave" or "player:<id>" (nothing yet). Actions wait for the
-- next loop step, because the button being pressed may be rebuilt. Nothing here keeps a game object between ticks:
-- menus and buttons are found again by address.

local UEHelpers = require("UEHelpers")

local browser = { test_hubs = {} } -- test_hubs: { name, ip, port } from mp_test
local net, hub, voice

local EVENT = "MultiplayerHub"
local EXTRAS_TABLE = "/Game/Blueprints/UI/Menu/ExtraMenu/DT_ExtraStuff"
local HUB_ROW = "MultiplayerHub"
local EXTRAS_MENU_CLASS = "/Game/Blueprints/UI/Menu/ExtraMenu/BPW_ExtrasMenu.BPW_ExtrasMenu_C"
local EXTRAS_BUTTON_CLASS = "/Game/Blueprints/UI/Menu/ExtraMenu/BPW_ExtrasButton.BPW_ExtrasButton_C"
local PAUSE_MENU_CLASS = "/Game/Blueprints/UI/Menu/BPW_PauseMenu.BPW_PauseMenu_C"
local PAUSE_EXTRAS_PRESSED = PAUSE_MENU_CLASS .. ":BndEvt__BPW_PauseMenu_ExtrasButton_K2Node_ComponentBoundEvent_17_ButtonPressed__DelegateSignature"
local EXTRAS_BACK_CLICKED = EXTRAS_MENU_CLASS .. ":BndEvt__BPW_ExtrasMenu_BackButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature"
local F = { -- struct_ExtraSubInfo, the Extras table's row
    title = "Title_2_EDCEDE2244B5AF528CE50EB5F62A689A",
    description = "Description_4_B5CA21FF462981C8D219CC9A73D2C779",
    unlocked = "UnlockStatus_10_0803761C40DC8DAD8944BFAC236B2FF9",
    soon = "ComingSoon_14_A26FDD4E41EDFC1F43DFABB8835FAD5B",
    event = "EventToFire_17_028E7FA0494A842EF633D5AD5696555D",
    message = "MessageForEvent_19_243A5F2545F6E2FDFE53F18A66376D8B",
    reqs = "UnlockReqs_22_039CC82148B39083771A91A1ADE0F9D6",
    submenu = "SubmenuName_28_2BAF52C94BBFD05333A157B3F5E53691",
    req_info = "UnlockRequirementInfo_30_7AA24CA34D795707E771639122A12DC5",
    stat = "TrackedMetaStat_36_8D3C4DD34877DDC5FDA495ABAA9B997B",
    stat_text = "StatText_39_E92EFD61456400EA8C92ADA97FE81339",
}
local MAIN_ROW = {
    title = "Multiplayer Hub",
    body = "Meet up to 8 friends in the Starting Hall. Take a dungeon door together, 4 to a party.",
    message = "",
}
local VISIBLE, COLLAPSED = 0, 1 -- ESlateVisibility
local ACTIVE_TINT = { R = 1.0, G = 1.0, B = 1.0, A = 1.0 }
local INACTIVE_TINT = { R = 0.171875, G = 0.171875, B = 0.171875, A = 1.0 } -- the game's own locked rows
local REFRESH_EVERY = 0.5
local REFRESH_METER_EVERY = 0.1 -- while the voice test's level meter shows
local FRIENDS_EVERY = 2.0
local SAME_PRESS_SECONDS = 0.4 -- each Extras menu listening to the event hears a press, so one press acts once
local HUB_SIZE = 8

local hooked = {}
local row_added = false
local boxes = {} -- Extras menu address -> { box = address, keys = { ... }, context = "browser" | "hub" }
local actions = {} -- messages waiting for the next step
local last_press = { message = nil, at = -1 }
local last_refresh, last_friends = -1, -1
local friends = {} -- from MPCore_FriendsHubs: { lobby, friend, status, name, count, max }
local shown_pause_buttons = {} -- in-game pause menu address -> true, where the Extras button was brought back
local now_seconds = 0

local function valid(object)
    return object ~= nil and object:IsValid()
end

local function fname(text)
    return FName(text, EFindName.FNAME_Add)
end

local function widget_library()
    return StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
end

local function statics()
    return StaticFindObject("/Script/Engine.Default__GameplayStatics")
end

local function hook(path, callback)
    if hooked[path] then return end
    local ok = pcall(RegisterHook, path, function(...)
        local ok_call, problem = pcall(callback, ...)
        if not ok_call then net.log("Browser hook error: " .. tostring(problem)) end
    end)
    if ok then hooked[path] = true end
end

local function load_object(package, name)
    local found = StaticFindObject(package .. "." .. name)
    if valid(found) then return found end
    local ok, loaded = pcall(function()
        return StaticFindObject("/Script/AssetRegistry.Default__AssetRegistryHelpers"):GetAsset({
            PackageName = fname(package), AssetName = fname(name) })
    end)
    if ok and valid(loaded) then return loaded end
    return nil
end

local function extras_table()
    return load_object(EXTRAS_TABLE, "DT_ExtraStuff")
end

local function text_of(value)
    local ok, text = pcall(function() return value:ToString() end)
    return ok and text or ""
end

-- ---- The Extras table row: menus built after it list "Multiplayer Hub" themselves ------------------------------------

local function fill(entry_struct, entry)
    entry_struct[F.title] = FText(entry.title)
    entry_struct[F.description] = FText(entry.body or "")
    entry_struct[F.unlocked] = entry.active ~= false
    entry_struct[F.soon] = false
    entry_struct[F.event] = EVENT
    entry_struct[F.message] = entry.message or ""
    entry_struct[F.reqs] = FText(entry.note or "")
    entry_struct[F.submenu] = ""
    entry_struct[F.req_info] = ""
    entry_struct[F.stat] = ""
    entry_struct[F.stat_text] = FText("")
end

local function ensure_table_row()
    if row_added then return true end
    local dt = extras_table()
    if not dt then return false end
    if not dt:FindRow(HUB_ROW) then
        local source = dt:FindRow("FreeMode")
        if not source then return false end
        dt:AddRow(HUB_ROW, source)
    end
    fill(dt:FindRow(HUB_ROW), MAIN_ROW)
    row_added = true
    net.log("Extras row added")
    return true
end

-- ---- Menus ----------------------------------------------------------------------------------------------------------

-- Each pause menu (the main menu is one too) with its Extras menu. FindAllOf also returns the templates inside the
-- widget classes, whose widgets are empty, so those are skipped.
local function menu_pairs()
    local out = {}
    for _, pause in ipairs(FindAllOf("BPW_PauseMenu_C") or {}) do
        if valid(pause) then
            local ok, extras = pcall(function() return pause.BPW_ExtrasMenu end)
            if ok and valid(extras) and valid(extras.StartingMenu) and valid(extras.WidgetSwitcher_0) then
                out[#out + 1] = { pause = pause, extras = extras }
            end
        end
    end
    return out
end

local function pair_of_extras(address)
    for _, pair in ipairs(menu_pairs()) do
        if pair.extras:GetAddress() == address then return pair end
    end
    return nil
end

local function children(panel)
    local out = {}
    for i = 0, panel:GetChildrenCount() - 1 do
        local child = panel:GetChildAt(i)
        if valid(child) then out[#out + 1] = child end
    end
    return out
end

local function message_of(button)
    local ok, message = pcall(function() return button.AssociatedEntry[F.message]:ToString() end)
    return ok and message or nil
end

local function is_ours(button)
    local ok, event = pcall(function() return button.AssociatedEntry[F.event]:ToString() end)
    return ok and event == EVENT
end

local function new_button(extras)
    local class = StaticFindObject(EXTRAS_BUTTON_CLASS)
    if not valid(class) then
        load_object("/Game/Blueprints/UI/Menu/ExtraMenu/BPW_ExtrasButton", "BPW_ExtrasButton_C")
        class = StaticFindObject(EXTRAS_BUTTON_CLASS)
    end
    if not valid(class) then return nil end
    local button = widget_library():Create(extras, class, nil)
    if not valid(button) then return nil end
    local dt = extras_table()
    local template = dt and dt:FindRow(HUB_ROW)
    if template then button.AssociatedEntry = template end -- the icon and anything else the row carries
    return button
end

-- Puts an entry on a button: its row data (used when it is pressed), and its texts, which the button's Construct
-- only copies once. Inactive entries look like the game's locked rows, with our word instead of "Locked".
local function apply(button, entry)
    fill(button.AssociatedEntry, entry)
    pcall(function() button.Title:SetText(FText(entry.title)) end)
    pcall(function() button.Body:SetText(FText(entry.body or "")) end)
    pcall(function()
        if entry.note and entry.note ~= "" then
            button.Requirements:SetText(FText(entry.note))
            button.Requirements:SetVisibility(VISIBLE)
        else
            button.Requirements:SetVisibility(COLLAPSED)
        end
    end)
    pcall(function()
        if entry.active == false then
            button.Status:SetText(FText(entry.status or ""))
            button.Status:SetVisibility(VISIBLE)
            button.Button_68:SetColorAndOpacity(INACTIVE_TINT)
        else
            button.Status:SetVisibility(COLLAPSED)
            button.Button_68:SetColorAndOpacity(ACTIVE_TINT)
        end
    end)
end

-- Menus built before the table row existed lack the Multiplayer Hub row and never listened for its event; this adds
-- the row and the listener by hand, at the end of the list as the table's own order puts it (the engine gives Lua no
-- way to insert at a position). Menus built later have it from the table.
local function ensure_main_row(pair)
    local start = pair.extras.StartingMenu
    for _, child in ipairs(children(start)) do
        if is_ours(child) then return end
    end
    local button = new_button(pair.extras)
    if not button then return end
    fill(button.AssociatedEntry, MAIN_ROW)
    start:AddChild(button)
    apply(button, MAIN_ROW)
    StaticFindObject("/Script/EasyEventSystem.Default__EasyEventManagerLibrary"):BindEvent(UEHelpers.GetWorld(), fname(EVENT), pair.extras)
    net.log("Added the Multiplayer Hub row to a menu built before the table had it")
end

-- ---- What the submenu lists -----------------------------------------------------------------------------------------

local function steam_state()
    local ok, steam_ok, name, why = pcall(MPCore_Steam)
    if not ok then return false, "", "MPCore is too old" end
    return steam_ok, name or "", why or ""
end

local function parse_friends(text)
    local list = {}
    for line in tostring(text or ""):gmatch("[^\n]+") do
        local lobby, friend, status, name, count, max = line:match("^([^|]*)|([^|]*)|([^|]*)|([^|]*)|([^|]*)|([^|]*)$")
        if lobby and lobby ~= "" then
            list[#list + 1] = { lobby = lobby, friend = friend, status = status, name = name,
                count = tonumber(count) or 0, max = tonumber(max) or 0 }
        end
    end
    return list
end

local function browser_entries()
    local list = {}
    local state = net.state
    if state == "creating" or state == "joining" then
        list[#list + 1] = { key = "busy", title = state == "creating" and "Creating your hub..." or ("Joining " .. (browser.joining or "the hub") .. "..."),
            body = state == "creating" and "Steam is making a friends-only hub for up to 8 players." or "Connecting through Steam. This takes a few seconds.",
            active = false, status = "Please wait", message = "busy" }
        list[#list + 1] = { key = "cancel", title = "Cancel", body = "Stop, and stay in the menu.", message = "cancel" }
        return list
    end
    if browser.failure then
        list[#list + 1] = { key = "failed", title = browser.failure.title, body = browser.failure.text, active = false,
            status = "Failed", message = "noop" }
    end
    local steam_ok, steam_name, steam_why = steam_state()
    if steam_ok then
        list[#list + 1] = { key = "host", title = "Host a hub",
            body = "Start a friends-only hub for up to 8 players in the Starting Hall, then invite friends from Steam.",
            note = steam_name ~= "" and ("Hosting as " .. steam_name) or nil, message = "host" }
    else
        list[#list + 1] = { key = "host", title = "Host a hub",
            body = "Hubs run through Steam. Start Sin Spire from Steam to host or join one.",
            note = steam_why ~= "" and steam_why or nil, active = false, status = "No Steam", message = "noop" }
    end
    local any = false
    for _, h in ipairs(friends) do
        if h.status ~= "other" then
            any = true
            local name = h.name ~= "" and h.name or (h.friend .. "'s hub")
            local entry = { key = "hub:" .. h.lobby, title = "Join " .. name, message = "join:" .. h.lobby }
            if h.status == "checking" then
                entry.body, entry.active, entry.status = "Hosted by " .. h.friend .. ". Asking Steam about this hub...", false, "Checking"
            elseif h.status == "version" then
                entry.body, entry.active, entry.status = "Hosted by " .. h.friend .. ". It runs another version of Multiplayer Hub.", false, "Other version"
            else
                local max = h.max > 0 and h.max or HUB_SIZE
                entry.body = string.format("Hosted by %s. %d of %d players.", h.friend, math.max(h.count, 1), max)
                if h.count >= max then entry.active, entry.status = false, "Full" end
            end
            list[#list + 1] = entry
        end
    end
    for _, h in ipairs(browser.test_hubs) do
        any = true
        list[#list + 1] = { key = "udp:" .. h.ip .. ":" .. h.port, title = "Join " .. h.name .. "'s hub (test)",
            body = string.format("A test hub on this PC, over UDP at %s port %d.", h.ip, h.port),
            message = string.format("udp:%s:%d", h.ip, h.port), name = h.name }
    end
    if not any then
        list[#list + 1] = { key = "none", title = "No friends' hubs",
            body = "Hubs your Steam friends host show up here. The list updates every few seconds.",
            active = false, status = "None yet", message = "noop" }
    end
    list[#list + 1] = browser.voice_mode_entry()
    list[#list + 1] = browser.voice_test_entry()
    return list
end

-- Voice: hear yourself through the voice codec, with the microphone's level, while you talk.
function browser.voice_test_entry()
    local on = voice.test == "loopback"
    local toggle = voice.mode == "toggle"
    return { key = "voice:test", title = on and "Stop the voice test" or "Test your voice",
        body = on and (toggle and "Press V and talk (press it again to stop): you hear yourself as the others will."
                or "Hold V and talk: you hear yourself as the others will.") or
            ("Hear yourself as the others will, and check your microphone's level. " ..
                (toggle and "Voice chat: press V to switch your microphone on or off." or "Voice chat is push to talk on V.")),
        note = on and voice.meter() or nil, message = "voice:test" }
end

-- Hold V or press V: how you talk.
function browser.voice_mode_entry()
    local toggle = voice.mode == "toggle"
    return { key = "voice:mode", title = "Talk: " .. (toggle and "Press V on / off" or "Hold V"),
        body = toggle and "Press V once to switch your microphone on and again to switch it off. It starts off in each hub, and a message says each switch. Press for push to talk."
            or "Push to talk: you're heard while you hold V. Press to switch to pressing V once to turn your microphone on, and again to turn it off.",
        message = "voice:mode" }
end

local function voice_entries(list)
    list[#list + 1] = { key = "voice:on", title = "Voice chat: " .. (voice.enabled and "On" or "Off"),
        body = voice.enabled and (voice.talk_hint() .. " Voices come from where players stand: full volume up close, fading out by 25 m, muffled through walls.")
            or "You don't hear the others, and V sends nothing. Press to turn it on.",
        message = "voice:toggle" }
    list[#list + 1] = browser.voice_mode_entry()
    list[#list + 1] = { key = "voice:volume", title = string.format("Voice volume: %d%%", math.floor(voice.volume * 100 + 0.5)),
        body = "How loud the other players are. Press to change.", message = "voice:volume" }
    list[#list + 1] = browser.voice_test_entry()
    local has_block = voice.has_block()
    local toggle = voice.mode == "toggle"
    list[#list + 1] = { key = "voice:block", title = has_block and "Remove the voice test block" or "Spawn voice test block",
        body = has_block and (toggle and "Press V to record again; press it again and the block plays it back from where it stands."
                or "Hold V to record again; let go and the block plays it back from where it stands.")
            or (toggle and "A small block appears 3 m in front of you. Press V to record up to 10 s, press V again, and it plays your voice back from where it stands. Walk around it."
                or "A small block appears 3 m in front of you. Hold V to record up to 10 s, let go, and it plays your voice back from where it stands. Walk around it."),
        message = "voice:block" }
end

local function hub_entries()
    local list = {}
    local steam_hub = net.hub:find("^steam:") ~= nil
    list[#list + 1] = { key = "invite", title = "Invite friends",
        body = steam_hub and "Opens Steam's invite window. Friends who accept join this hub." or "Invites need a Steam hub. This is a test hub.",
        active = steam_hub, status = "Steam only", message = steam_hub and "invite" or "noop" }
    local hosting = net.role == "host"
    list[#list + 1] = { key = "me", title = (net.self_name ~= "" and net.self_name or "You") .. " (you)",
        body = hosting and "You host this hub." or "You're in this hub.", message = "player:me" }
    local others = {}
    for id, p in pairs(net.peers) do others[#others + 1] = { id = id, p = p } end
    table.sort(others, function(a, b) return (a.p.name or "") < (b.p.name or "") end)
    for _, o in ipairs(others) do
        local rtt = tonumber(o.p.rtt) or -1
        list[#list + 1] = { key = "p:" .. o.id, title = (o.p.name or "Player") .. (o.p.host and " (host)" or ""),
            body = rtt >= 0 and string.format("Ping %d ms", math.floor(rtt + 0.5)) or "Connecting...", message = "player:" .. o.id }
    end
    voice_entries(list)
    list[#list + 1] = { key = "leave", title = "Leave hub",
        body = hosting and steam_hub and "Back to the main menu. Steam hands the hub to another player." or "Back to the main menu.",
        message = "leave" }
    return list
end

local function title_for(context)
    if context == "hub" then
        return string.format("Hub: %d of %d", net.peer_count() + 1, HUB_SIZE)
    end
    return "Multiplayer Hub"
end

local function context_now()
    return net.in_session() and "hub" or "browser"
end

local function entries_for(context)
    return context == "hub" and hub_entries() or browser_entries()
end

-- ---- The submenu ----------------------------------------------------------------------------------------------------

local function find_box(extras, record)
    for _, child in ipairs(children(extras.WidgetSwitcher_0)) do
        if child:GetAddress() == record.box then return child end
    end
    return nil
end

local function ensure_box(extras)
    local address = extras:GetAddress()
    local record = boxes[address]
    local box = record and find_box(extras, record)
    if box then return box, record end
    box = StaticConstructObject(StaticFindObject("/Script/UMG.VerticalBox"), extras.WidgetTree)
    extras.WidgetSwitcher_0:AddChild(box)
    record = { box = box:GetAddress(), keys = {} }
    boxes[address] = record
    return box, record
end

local function same_keys(a, entries)
    if #a ~= #entries then return false end
    for i, entry in ipairs(entries) do
        if a[i] ~= entry.key then return false end
    end
    return true
end

-- Rebuilds the list when its entries change, updates their texts otherwise. If the pause menu's controller highlight
-- was on one of the old buttons, it moves to the new button for the same entry, as the D-pad would have left it.
local function fill_box(pair, box, record, entries)
    if same_keys(record.keys, entries) then
        local list = children(box)
        for i, entry in ipairs(entries) do
            if list[i] then apply(list[i], entry) end
        end
        return
    end
    local highlighted_key = nil
    pcall(function()
        local highlighted = pair.pause.HighlightedSettingButton
        if valid(highlighted) then
            local list = children(box)
            for i, child in ipairs(list) do
                if child:GetAddress() == highlighted:GetAddress() then highlighted_key = record.keys[i] end
            end
        end
    end)
    box:ClearChildren()
    record.keys = {}
    local highlight_button = nil
    for _, entry in ipairs(entries) do
        local button = new_button(pair.extras)
        if button then
            fill(button.AssociatedEntry, entry)
            box:AddChild(button)
            apply(button, entry)
            record.keys[#record.keys + 1] = entry.key
            if highlighted_key and entry.key == highlighted_key then highlight_button = button end
        end
    end
    if highlighted_key then
        local list = children(box)
        highlight_button = highlight_button or list[1]
        if highlight_button then pcall(function() pair.pause:SettingButtonHighlight(highlight_button) end) end
    end
end

local function refresh_pair(pair, context)
    local box, record = ensure_box(pair.extras)
    record.context = context
    fill_box(pair, box, record, entries_for(context))
    pcall(function() pair.extras.NameText:SetText(FText(title_for(context))) end)
    return box
end

local function open_submenu(pair, context)
    local box = refresh_pair(pair, context)
    pair.extras.WidgetSwitcher_0:SetActiveWidget(box)
    pcall(function() pair.extras.BackButton:SetVisibility(VISIBLE) end)
    pcall(function() pair.extras.ScrollBox_0:ScrollToStart() end)
    -- With the controller in use, the highlight starts on the first entry (A would otherwise press the row that opened it).
    pcall(function()
        if pair.pause.InGamepad then
            local first = children(box)[1]
            if first then pair.pause:SettingButtonHighlight(first) end
        end
    end)
    if not browser.steam_logged then
        browser.steam_logged = true
        local ok, status = pcall(MPCore_SteamStatus)
        net.log("Steam: " .. (ok and tostring(status) or "?"))
    end
    net.log("Opened the " .. context .. " menu: " .. table.concat(browser.titles(box), " | "))
end

-- On screen: the pause menu (or main menu) is up, on its Extras page, with our submenu active.
local function is_showing(pair)
    local record = boxes[pair.extras:GetAddress()]
    if not record then return false end
    local ok, shown = pcall(function()
        local active = pair.extras.WidgetSwitcher_0:GetActiveWidget()
        return valid(active) and active:GetAddress() == record.box and pair.pause:IsInViewport()
            and pair.pause.WidgetSwitcher_62:GetActiveWidgetIndex() == 6
    end)
    return ok and shown == true
end

-- The in-game pause menu's Extras button, back as "Multiplayer Hub" while in a hub; hidden again otherwise.
local function update_pause_buttons()
    local in_session = net.in_session()
    for _, pair in ipairs(menu_pairs()) do
        local pause = pair.pause
        if not pause.IsStartMenu then
            local address = pause:GetAddress()
            pcall(function()
                local button = pause.ExtrasButton
                if in_session then
                    if button:GetVisibility() ~= VISIBLE then button:SetVisibility(VISIBLE) end
                    if text_of(button.TextBlock_0:GetText()) ~= "Multiplayer Hub" then
                        button.TextBlock_0:SetText(FText("Multiplayer Hub"))
                    end
                    shown_pause_buttons[address] = true
                elseif shown_pause_buttons[address] then
                    button:SetVisibility(COLLAPSED)
                    shown_pause_buttons[address] = nil
                end
            end)
        end
    end
end

-- Back from the hub submenu of an in-game pause menu goes to the pause menu's first page, not the Extras list.
local function back_to_pause_page(extras_address)
    local pair = pair_of_extras(extras_address)
    if not pair or pair.pause.IsStartMenu then return end
    local record = boxes[extras_address]
    if not record or record.context ~= "hub" then return end
    pair.pause.WidgetSwitcher_62:SetActiveWidgetIndex(0)
    pair.pause.MenuState = 0
    pcall(function()
        if pair.pause.InGamepad then pair.pause:GamepadHighlightButton(pair.pause.ExtrasButton) end
    end)
end

-- ---- Actions --------------------------------------------------------------------------------------------------------

local function leave_hub()
    net.leave()
    browser.failure = nil
    pcall(function() statics():SetGamePaused(UEHelpers.GetWorld(), false) end)
    hub.go_menu()
end

local function act(message)
    if message == "" or message == "busy" or message == "noop" or message:find("^player:") then
        return
    end
    if not message:find("^voice:") then browser.failure = nil end
    if message == "host" then
        local ok, why = net.host_steam(HUB_SIZE, "")
        browser.action = "host"
        if not ok then browser.failure = { title = "Couldn't host a hub", text = tostring(why) } end
        net.log(ok and "Hosting a Steam hub" or ("Could not host a Steam hub: " .. tostring(why)))
    elseif message:find("^join:") then
        local lobby = message:sub(6)
        browser.action = "join"
        browser.joining = nil
        for _, h in ipairs(friends) do
            if h.lobby == lobby then browser.joining = h.name ~= "" and h.name or (h.friend .. "'s hub") end
        end
        local ok, why = net.join_steam(lobby)
        if not ok then browser.failure = { title = "Couldn't join " .. (browser.joining or "the hub"), text = tostring(why) } end
        net.log(ok and ("Joining hub " .. lobby) or ("Could not join: " .. tostring(why)))
    elseif message:find("^udp:") then
        local ip, port = message:match("^udp:([^:]+):(%d+)$")
        local name = nil
        for _, h in ipairs(browser.test_hubs) do
            if h.ip == ip and tostring(h.port) == port then name = h.name end
        end
        browser.action = "join"
        browser.joining = (name or "the test") .. "'s hub"
        local ok, why = net.join_udp(ip, tonumber(port), browser.udp_local_port or 7302, browser.udp_name or "Player")
        if not ok then browser.failure = { title = "Couldn't join " .. browser.joining, text = tostring(why) } end
        net.log(ok and ("Joining the test hub at " .. ip .. ":" .. port) or ("Could not join: " .. tostring(why)))
    elseif message == "cancel" then
        net.leave()
        net.log("Cancelled")
    elseif message == "invite" then
        net.log(MPCore_Invite() and "Asked Steam to open its invite window" or "No Steam hub to invite to")
    elseif message == "leave" then
        net.log("Leaving the hub")
        leave_hub()
    elseif message == "voice:toggle" then
        voice.toggle_enabled()
    elseif message == "voice:mode" then
        voice.cycle_mode()
    elseif message == "voice:volume" then
        voice.cycle_volume()
    elseif message == "voice:test" then
        voice.toggle_test()
    elseif message == "voice:block" then
        local had = voice.has_block()
        voice.toggle_block()
        if not had and voice.has_block() then
            -- Back to the game, standing in front of it.
            for _, pair in ipairs(menu_pairs()) do
                if not pair.pause.IsStartMenu and pair.pause:IsInViewport() then pcall(function() pair.pause:CloseMenu() end) end
            end
        end
    end
end

local function on_event(extras_address, message)
    if message == "" then
        local pair = pair_of_extras(extras_address)
        if pair then open_submenu(pair, context_now()) end
        return
    end
    -- Every Extras menu listening to the event hears one press.
    if message == last_press.message and now_seconds - last_press.at < SAME_PRESS_SECONDS then return end
    last_press.message, last_press.at = message, now_seconds
    actions[#actions + 1] = message
end

-- ---- Module ---------------------------------------------------------------------------------------------------------

-- No game objects here: init runs on UE4SS's thread while the engine starts (see main.lua).
function browser.init(session, hub_module, voice_module)
    net, hub, voice = session, hub_module, voice_module
    net.on("state", function(state)
        if state:find("^failed") then
            local why = state:gsub("^failed:%s*", "")
            browser.failure = { title = browser.action == "host" and "Couldn't host a hub" or ("Couldn't join " .. (browser.joining or "the hub")), text = why }
        end
    end)
end

-- The menu's event and buttons, hooked once their classes exist (the menus load with the main menu).
local function register_hooks()
    hook(EXTRAS_MENU_CLASS .. ":OnEventCalled", function(self, event, message)
        if event:get():ToString() ~= EVENT then return end
        on_event(self:get():GetAddress(), message:get():ToString())
    end)
    hook(PAUSE_EXTRAS_PRESSED, function(self)
        local pause = self:get()
        if pause.IsStartMenu or not net.in_session() then return end
        local pair = pair_of_extras(pause.BPW_ExtrasMenu:GetAddress())
        if pair then open_submenu(pair, "hub") end
    end)
    hook(EXTRAS_MENU_CLASS .. ":GoBack", function(self) back_to_pause_page(self:get():GetAddress()) end)
    hook(EXTRAS_BACK_CLICKED, function(self) back_to_pause_page(self:get():GetAddress()) end)
    -- Each time the pause menu opens, its Construct hides the Extras button again; it comes straight back in a hub.
    hook(PAUSE_MENU_CLASS .. ":Construct", function() update_pause_buttons() end)
end

function browser.tick(seconds, level)
    now_seconds = seconds
    if not row_added then pcall(ensure_table_row) end
    register_hooks()
    while #actions > 0 do
        local message = table.remove(actions, 1)
        local ok, problem = pcall(act, message)
        if not ok then net.log("Action error (" .. message .. "): " .. tostring(problem)) end
    end
    local every = voice.test == "loopback" and REFRESH_METER_EVERY or REFRESH_EVERY
    if seconds - last_refresh < every then return end
    last_refresh = seconds
    local pairs_now = menu_pairs()
    local showing = {}
    for _, pair in ipairs(pairs_now) do
        if pair.pause.IsStartMenu then pcall(ensure_main_row, pair) end
        if is_showing(pair) then showing[#showing + 1] = pair end
    end
    update_pause_buttons()
    if #showing == 0 then
        -- The hear-yourself test belongs to the menu: closing it closes the microphone too.
        if voice.test == "loopback" then voice.toggle_test() end
        return
    end
    if seconds - last_friends >= FRIENDS_EVERY and not net.in_session() then
        last_friends = seconds
        local ok, text = pcall(MPCore_FriendsHubs)
        friends = ok and parse_friends(text) or {}
        -- For the log: how many, by status, never whose (names stay out of it).
        local counts = {}
        for _, h in ipairs(friends) do counts[h.status] = (counts[h.status] or 0) + 1 end
        local summary = string.format("%d (ok %d, checking %d, other version %d, not a hub %d)", #friends, counts.ok or 0,
            counts.checking or 0, counts.version or 0, counts.other or 0)
        if summary ~= browser.friends_summary then
            browser.friends_summary = summary
            net.log("Friends playing from a lobby: " .. summary)
        end
    end
    for _, pair in ipairs(showing) do
        local record = boxes[pair.extras:GetAddress()]
        -- A hub submenu left open after the session ended (or the reverse) switches to what fits now.
        local context = record.context
        if pair.pause.IsStartMenu then context = context_now() end
        local ok, problem = pcall(refresh_pair, pair, context)
        if not ok then net.log("Refresh error: " .. tostring(problem)) end
    end
end

-- For tests: the pause menu pairs, the entries a submenu shows, and its box.
browser.menu_pairs = menu_pairs
browser.children = children
browser.message_of = message_of
browser.is_ours = is_ours
function browser.box_of(pair)
    local record = boxes[pair.extras:GetAddress()]
    return record and find_box(pair.extras, record) or nil
end
function browser.titles(panel)
    local out = {}
    for _, child in ipairs(children(panel)) do
        local ok, title = pcall(function() return child.Title:GetText():ToString() end)
        local status = ""
        pcall(function()
            if child.Status:GetVisibility() == VISIBLE then status = " [" .. child.Status:GetText():ToString() .. "]" end
        end)
        out[#out + 1] = (ok and title or "?") .. status
    end
    return out
end

return browser
