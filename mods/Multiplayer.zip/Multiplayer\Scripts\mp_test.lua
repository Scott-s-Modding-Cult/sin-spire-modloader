-- Multiplayer Hub: a test driver, active only when Mods\Multiplayer\test.txt exists (never in a normal install). It
-- starts the session from the file, goes to the hub, walks the local player round a circle, logs its true position
-- and where it shows the other players (session clock) to test_log.csv, takes screenshots, and logs "test done".
-- test.txt, one setting per line:  session=udp-host|udp-join  port=7301  host=127.0.0.1  local=7302  name=Alpha
--                                  circle=dx,dy,radius,seconds  look=dx,dy  duration=20
-- session=none goes to the hub alone and shows the pose lineup instead (see run_lineup).
-- session=browser drives the menus as a player would (see run_menu, run_hub_menu): Extras > Multiplayer Hub, the test
-- hub from test_hub=Name@ip:port joined with the game's own D-pad and A functions, then in the hub the pause menu's
-- Multiplayer Hub page, Back, and Leave hub. Uses local= and name= for its UDP join.
-- Voice (see run_voice_*): every test runs voice on miniaudio's silent null devices, with voice_in= (a WAV in the mod
-- folder) as the microphone and the mix written to voice_out.wav, so no test opens the real microphone or speakers.
--   session=voice-listener  hosts like udp-host, then listens from a fixed camera 4 m behind the spawn, facing down
--                           the hall (+Y), for listen= seconds
--   session=voice-talker    joins like udp-join, then talks (forced) from five places round that camera, 4 s each
--   session=voice-block     alone: spawns the voice test block, records 3 s, then listens from seven places
--   session=voice-toggle    joins like udp-join, then checks the talk modes with a simulated V key (run_voice_toggle)
-- Each logs "VOICE START <session time>" when its audio starts and "VOICE PHASE <n> <name> <session time>" as each
-- place begins; probe\voice_check.py measures voice_out.wav against them.
-- Party (Phase 2): with party=<map> (udp-host or udp-join), the copy with party_lead=1 waits in the hub for the other
-- player, then holds nothing but starts the party at the portal to that map as a hold would (mp_party.start). Both log
-- the multiplayer character's state on arrival, wait for the dungeon's layout check and the other's, take a screenshot,
-- and then the leader goes back to the hub (back_after= seconds) and the other must follow.

local UEHelpers = require("UEHelpers")

local test = { active = false }
local net, players, hub, browser, voice

local cfg = {}
local phase = "boot"
local phase_started = 0
local truth = {}
local shown = {}
local base
local camera
local shots_taken = {}

local function valid(object)
    return object ~= nil and object:IsValid()
end

local function statics()
    return StaticFindObject("/Script/Engine.Default__GameplayStatics")
end

local function system()
    return StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
end

local function controller()
    local pc = FindFirstOf("PlayerController")
    if valid(pc) then return pc end
end

local function pawn()
    local pc = controller()
    if pc and valid(pc.Pawn) then return pc.Pawn end
end

local function numbers(text)
    local out = {}
    for n in tostring(text or ""):gmatch("[-%d%.]+") do out[#out + 1] = tonumber(n) end
    return out
end

local function go(next_phase, seconds)
    phase = next_phase
    phase_started = seconds
    net.log("Test: " .. next_phase)
end

function test.init(session, player_module, hub_module, mod_dir, browser_module, voice_module)
    net, players, hub, browser, voice = session, player_module, hub_module, browser_module, voice_module
    test.dir = mod_dir
    local file = io.open(mod_dir .. "\\test.txt", "r")
    if not file then return end
    for line in file:lines() do
        local key, value = line:match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
        if key then cfg[key] = value end
    end
    file:close()
    test.active = true
    test.name = cfg.name
    hub.is_test = true
    if voice then
        voice.test_options = { input = cfg.voice_in and (mod_dir .. "\\" .. cfg.voice_in) or "", output = mod_dir .. "\\voice_out.wav" }
    end
    local name, ip, port = tostring(cfg.test_hub or ""):match("^([^@]+)@([^:]+):(%d+)$")
    if name and browser then
        browser.test_hubs = { { name = name, ip = ip, port = tonumber(port) } }
        browser.udp_local_port = tonumber(cfg["local"]) or 7302
        browser.udp_name = cfg.name or "Player"
    end
    net.log("Test mode from test.txt: " .. tostring(cfg.session) .. " as " .. tostring(cfg.name))
end

local function screenshot(name)
    system():ExecuteConsoleCommand(UEHelpers.GetWorld(), "HighResShot 960x540 filename=mphub_" .. name, controller())
end

-- Looks through a camera at eye, aimed at target (one camera, moved when called again).
local function set_camera(eye, target)
    local rotation = StaticFindObject("/Script/Engine.Default__KismetMathLibrary"):FindLookAtRotation(eye, target)
    if not valid(camera) then
        camera = UEHelpers.GetWorld():SpawnActor(StaticFindObject("/Script/Engine.CameraActor"), eye, rotation)
    else
        camera:K2_SetActorLocationAndRotation(eye, rotation, false, {}, true)
    end
    if valid(camera) then controller():SetViewTargetWithBlend(camera, 0, 0, 0, false) end
end

-- With the UI, which HighResShot leaves out; the engine names these ScreenShotNNNNN.png, so the log says which is which.
local function screenshot_ui(label)
    system():ExecuteConsoleCommand(UEHelpers.GetWorld(), "shot showui", controller())
    net.log("UI screenshot: " .. label)
end

local marks = {}
local function once(key, condition)
    if condition and not marks[key] then
        marks[key] = true
        return true
    end
    return false
end

local function menu_pair(start_menu)
    for _, pair in ipairs(browser.menu_pairs()) do
        if (pair.pause.IsStartMenu == true) == start_menu then return pair end
    end
    return nil
end

local function highlighted_message(pair)
    local ok, message = pcall(function() return browser.message_of(pair.pause.HighlightedSettingButton) end)
    return ok and message or nil
end

-- What the controller's D-pad does in the Extras page (the pause menu's GetSettingButton) until an entry whose message
-- starts with prefix is highlighted, then what A does (the highlighted button's Button). False if never reached.
local function pad_to_and_press(pair, box, prefix)
    for _ = 1, 12 do
        local message = highlighted_message(pair)
        if message and message:sub(1, #prefix) == prefix then
            net.log("Test: pad highlight on '" .. message .. "', pressing A")
            pair.pause.HighlightedSettingButton:Button()
            return true
        end
        pair.pause:GetSettingButton(true, box)
    end
    net.log("Test failed: the D-pad never reached an entry starting " .. prefix)
    return false
end

-- Main menu: open Extras with the game's own handler for its button, press our row as A does, list the submenu.
local function run_menu(t, seconds)
    local pair = menu_pair(true)
    if not pair then
        if t > 10 then
            net.log("Test failed: no main menu")
            go("report", seconds)
        end
        return
    end
    if once("extras", t > 1) then
        pair.pause.InGamepad = true -- as after a controller key: the submenu then starts with its first entry highlighted
        pair.pause:BndEvt__BPW_PauseMenu_ExtrasButton_K2Node_ComponentBoundEvent_17_ButtonPressed__DelegateSignature()
        net.log("Test: Extras page open (" .. pair.pause.WidgetSwitcher_62:GetActiveWidgetIndex() .. "), its list: "
            .. table.concat(browser.titles(pair.extras.StartingMenu), " | "))
    end
    if once("extras_shot", t > 2) then
        screenshot_ui("extras") -- taken at the end of this frame, before the row is pressed
    end
    if once("row", t > 3) then
        for _, child in ipairs(browser.children(pair.extras.StartingMenu)) do
            if browser.is_ours(child) and browser.message_of(child) == "" then
                pair.pause:SettingButtonHighlight(child)
                net.log("Test: pressing Multiplayer Hub with A")
                pair.pause.HighlightedSettingButton:Button()
            end
        end
    end
    if once("list", t > 4) then
        local box = browser.box_of(pair)
        net.log("Test: submenu '" .. pair.extras.NameText:GetText():ToString() .. "' shown: "
            .. tostring(box and pair.extras.WidgetSwitcher_0:GetActiveWidget():GetAddress() == box:GetAddress())
            .. "; entries: " .. (box and table.concat(browser.titles(box), " | ") or "none"))
        net.log("Test: highlight on '" .. tostring(highlighted_message(pair)) .. "'")
        screenshot_ui("browser")
    end
    if once("join", t > 5.5) then
        local box = browser.box_of(pair)
        if box and pad_to_and_press(pair, box, "udp:") then
            go("connecting", seconds)
        else
            go("report", seconds)
        end
    end
end

-- In the hub: the pause menu (shown as tests do) with its Multiplayer Hub button, the hub page, Back, and Leave hub.
local function run_hub_menu(t, seconds)
    local pair = menu_pair(false)
    if not pair then
        if t > 10 then
            net.log("Test failed: no pause menu in the hub")
            go("report", seconds)
        end
        return
    end
    local pause = pair.pause
    if once("hub_pause", t > 1) then
        pause:AddToViewport(10)
        pause.InGamepad = true
        net.log("Test: pause menu shown")
    end
    if once("hub_open", t > 2) then
        net.log(string.format("Test: its Extras button is visible %s, text '%s'",
            tostring(pause.ExtrasButton:GetVisibility() == 0), pause.ExtrasButton.TextBlock_0:GetText():ToString()))
        -- The D-pad on the pause menu's first page, round its buttons: ours must be one of them.
        local seen = {}
        for _ = 1, 10 do
            pause:HighlightMenuButtonGamepad(true)
            local ok, text = pcall(function() return pause.HighlightedButton.TextBlock_0:GetText():ToString() end)
            seen[#seen + 1] = ok and text or "?"
        end
        net.log("Test: D-pad down round the pause menu: " .. table.concat(seen, " > "))
        screenshot_ui("pause_menu")
        pause:BndEvt__BPW_PauseMenu_ExtrasButton_K2Node_ComponentBoundEvent_17_ButtonPressed__DelegateSignature()
    end
    if once("hub_list", t > 3.5) then
        local box = browser.box_of(pair)
        net.log("Test: hub page '" .. pair.extras.NameText:GetText():ToString() .. "' (pause page "
            .. pause.WidgetSwitcher_62:GetActiveWidgetIndex() .. "), entries: " .. (box and table.concat(browser.titles(box), " | ") or "none"))
        screenshot_ui("hub_menu")
    end
    if once("hub_back", t > 4.5) then
        pair.extras:GoBack()
        net.log(string.format("Test: after Back the pause menu is on page %d, menu state %d",
            pause.WidgetSwitcher_62:GetActiveWidgetIndex(), pause.MenuState))
    end
    if once("hub_reopen", t > 5.5) then
        pause:BndEvt__BPW_PauseMenu_ExtrasButton_K2Node_ComponentBoundEvent_17_ButtonPressed__DelegateSignature()
    end
    -- Voice: Test your voice on and off, then the test block: spawned (the menu closes), shown, removed.
    if once("hub_voice_test", t > 6.5) then
        local box = browser.box_of(pair)
        if box then pad_to_and_press(pair, box, "voice:test") end
    end
    if once("hub_voice_meter", t > 7.3) then
        local box = browser.box_of(pair)
        local note = "?"
        for _, child in ipairs(box and browser.children(box) or {}) do
            if browser.message_of(child) == "voice:test" then
                pcall(function() note = child.Title:GetText():ToString() .. " / " .. child.Requirements:GetText():ToString() end)
            end
        end
        net.log("Test: voice test " .. tostring(voice.test) .. ", MPCore says " .. tostring(voice.state and voice.state.test)
            .. "; its entry: " .. note)
        screenshot_ui("hub_voice_test")
    end
    if once("hub_voice_test_off", t > 8) then
        local box = browser.box_of(pair)
        if box then pad_to_and_press(pair, box, "voice:test") end
    end
    if once("hub_voice_block", t > 8.8) then
        net.log("Test: voice test now " .. tostring(voice.test))
        local box = browser.box_of(pair)
        if box then pad_to_and_press(pair, box, "voice:block") end
    end
    if once("hub_block_check", t > 9.8) then
        local b = voice.block_position()
        net.log(string.format("Test: block %s%s; pause menu still up %s; voice test %s", tostring(voice.has_block()),
            b and string.format(" at (%.0f, %.0f, %.0f)", b.X, b.Y, b.Z) or "", tostring(pause:IsInViewport()), tostring(voice.test)))
        screenshot((cfg.name or "player") .. "_voice_block_view")
    end
    if once("hub_reopen_2", t > 10.8) then
        pause:AddToViewport(10)
        pause.InGamepad = true
    end
    if once("hub_reopen_3", t > 11.5) then
        pause:BndEvt__BPW_PauseMenu_ExtrasButton_K2Node_ComponentBoundEvent_17_ButtonPressed__DelegateSignature()
    end
    if once("hub_block_remove", t > 12.3) then
        local box = browser.box_of(pair)
        net.log("Test: hub page again: " .. (box and table.concat(browser.titles(box), " | ") or "none"))
        if box then pad_to_and_press(pair, box, "voice:block") end
    end
    if once("hub_block_gone", t > 13) then
        net.log("Test: block after Remove: " .. tostring(voice.has_block()) .. ", voice test " .. tostring(voice.test))
    end
    if once("hub_leave", t > 13.6) then
        local box = browser.box_of(pair)
        if box and pad_to_and_press(pair, box, "leave") then
            go("left", seconds)
        else
            go("report", seconds)
        end
    end
end

-- ---- Voice tests ----------------------------------------------------------------------------------------------------

local voice_start_logged = false
local function log_voice_start()
    if not voice_start_logged and voice and voice.state and voice.state.running then
        voice_start_logged = true
        net.log(string.format("VOICE START %.3f", net.now()))
    end
end

local function voice_phase(n, name, extra)
    net.log(string.format("VOICE PHASE %d %s %.3f%s", n, name, net.now(), extra or ""))
end

-- The listener: a fixed camera 4 m behind the spawn at eye height, facing down the hall (+Y), so its right is -X.
local function run_voice_listen(t, seconds)
    if once("listen_camera", t > 0.5) then
        local eye = { X = base.X, Y = base.Y - 400, Z = base.Z + 60 }
        set_camera(eye, { X = eye.X, Y = eye.Y + 100, Z = eye.Z })
        local me = pawn()
        if me then me.BPC_HealthComponent.ExternalMultiplier = 0 end
        net.log(string.format("Test: listening at (%.0f, %.0f, %.0f) facing +Y", eye.X, eye.Y, eye.Z))
    end
    if once("listen_wall_" .. math.floor(t), t > 1) then
        for peer in pairs(players.displayed()) do
            net.log(string.format("VOICE WALL %s %s %.3f", peer, tostring(voice.occlusion(peer)), net.now()))
        end
    end
    -- Whether each player's voice is coming in, twice a second (the toggle test reads these).
    if once("listen_heard_" .. math.floor(t * 2), t > 1) then
        for peer in pairs(players.displayed()) do
            net.log(string.format("VOICE HEARD %s %s %.3f", peer, tostring(MPCore_VoicePeerTalking(peer)), net.now()))
        end
    end
    if t > (tonumber(cfg.listen) or 32) then
        net.log("Test: voice " .. tostring(voice.state and voice.state.stats or "?"))
        go("report", seconds)
    end
end

-- The talker: five places round the listener's camera, 4 s each, talking (the input WAV) all the while.
local TALK_SPOTS = {
    { "right_2m", -200, -400 }, { "left_2m", 200, -400 }, { "ahead_15m", -250, 1100 },
    { "ahead_30m", 0, 2600 }, { "behind_3m", 0, -700 },
}
local TALK_EACH = 4.0
local talk_index = 0

local function run_voice_talk(t, seconds)
    if t < 4 then return end -- the listener settles first
    local k = math.floor((t - 4) / TALK_EACH) + 1
    if k > #TALK_SPOTS then
        MPCore_VoiceTalk(false)
        net.log(string.format("VOICE END %.3f", net.now()))
        net.log("Test: voice " .. tostring(voice.state and voice.state.stats or "?"))
        go("report", seconds)
        return
    end
    local spot = TALK_SPOTS[k]
    if k ~= talk_index then
        talk_index = k
        if k == 1 then MPCore_VoiceTalk(true) end
        voice_phase(k, spot[1])
    end
    local me = pawn()
    if me then
        me:K2_SetActorLocation({ X = base.X + spot[2], Y = base.Y + spot[3], Z = base.Z }, false, {}, true)
    end
end

-- The talk modes, with the V key simulated (MPCore_VoiceKey: as if V were down; the real key goes the same way):
-- toggle on with a tap, stays on, toggle off with a tap, stays off; push to talk only while held; and a change of mode
-- leaves the microphone off. Each step logs "VOICE TOGGLE <step> <session time>" for the listener's VOICE HEARD lines,
-- and "Test: toggle check <name> ok|FAILED (...)".
local toggle_checks = { passed = 0, total = 0 }

local function voice_snapshot()
    local _, talking, _, _, _, stats, mic_on = MPCore_VoiceState()
    return { talking = talking == true, mic_on = mic_on == true, sent = tonumber(tostring(stats or ""):match("sent (%d+)")) or -1 }
end

local function toggle_check(name, ok, detail)
    toggle_checks.total = toggle_checks.total + 1
    if ok then toggle_checks.passed = toggle_checks.passed + 1 end
    net.log(string.format("Test: toggle check %s %s (%s)", name, ok and "ok" or "FAILED", detail))
end

local function toggle_step(name)
    net.log(string.format("VOICE TOGGLE %s %.3f", name, net.now()))
end

local toggle_sent = {}

local function run_voice_toggle(t, seconds)
    if t < 4 then return end -- the listener settles first
    if once("tg_mode", t > 4) then
        voice.set_mode("toggle")
        toggle_step("mode_toggle")
    end
    if once("tg_quiet", t > 4.6) then
        local s = voice_snapshot()
        toggle_check("starts_off", not s.talking and not s.mic_on, string.format("talking %s, mic %s", tostring(s.talking), tostring(s.mic_on)))
    end
    if once("tg_on_down", t > 5) then MPCore_VoiceKey(true); toggle_step("tap_on") end
    if once("tg_on_up", t > 5.2) then MPCore_VoiceKey(false) end
    if once("tg_on_check", t > 6) then
        local s = voice_snapshot()
        toggle_sent.on = s.sent
        toggle_check("on_after_tap", s.talking and s.mic_on, string.format("talking %s, mic %s, sent %d", tostring(s.talking), tostring(s.mic_on), s.sent))
    end
    if once("tg_on_stays", t > 9) then
        local s = voice_snapshot()
        toggle_check("stays_on", s.talking and s.sent - toggle_sent.on >= 100,
            string.format("talking %s, %d packets sent in 3 s", tostring(s.talking), s.sent - toggle_sent.on))
    end
    if once("tg_off_down", t > 9.5) then MPCore_VoiceKey(true); toggle_step("tap_off") end
    if once("tg_off_up", t > 9.7) then MPCore_VoiceKey(false) end
    if once("tg_off_check", t > 10.5) then
        local s = voice_snapshot()
        toggle_sent.off = s.sent
        toggle_check("off_after_tap", not s.talking and not s.mic_on, string.format("talking %s, mic %s", tostring(s.talking), tostring(s.mic_on)))
    end
    if once("tg_off_stays", t > 13) then
        local s = voice_snapshot()
        toggle_check("stays_off", not s.talking and s.sent == toggle_sent.off,
            string.format("talking %s, %d packets sent in 2.5 s", tostring(s.talking), s.sent - toggle_sent.off))
    end
    if once("tg_hold_mode", t > 13.5) then
        voice.set_mode("hold")
        toggle_step("mode_hold")
    end
    if once("tg_hold_down", t > 14) then MPCore_VoiceKey(true); toggle_step("hold_down") end
    if once("tg_hold_check", t > 15) then
        local s = voice_snapshot()
        toggle_check("hold_talks", s.talking and not s.mic_on, string.format("talking %s, mic %s", tostring(s.talking), tostring(s.mic_on)))
    end
    if once("tg_hold_up", t > 16) then MPCore_VoiceKey(false); toggle_step("hold_up") end
    if once("tg_hold_off", t > 16.5) then
        local s = voice_snapshot()
        toggle_check("hold_release_stops", not s.talking, string.format("talking %s", tostring(s.talking)))
    end
    if once("tg_again", t > 17) then voice.set_mode("toggle"); toggle_step("mode_toggle_again") end
    if once("tg_again_down", t > 17.5) then MPCore_VoiceKey(true); toggle_step("tap_on_again") end
    if once("tg_again_up", t > 17.7) then MPCore_VoiceKey(false) end
    if once("tg_again_check", t > 18.5) then
        local s = voice_snapshot()
        toggle_check("on_again", s.talking and s.mic_on, string.format("talking %s, mic %s", tostring(s.talking), tostring(s.mic_on)))
    end
    if once("tg_switch_hold", t > 19) then voice.set_mode("hold"); toggle_step("mode_hold_while_on") end
    if once("tg_switch_check", t > 19.6) then
        local s = voice_snapshot()
        toggle_check("mode_change_mutes", not s.talking and not s.mic_on, string.format("talking %s, mic %s", tostring(s.talking), tostring(s.mic_on)))
    end
    if once("tg_saved", t > 20) then
        local file = io.open(test.dir .. "\\voice.txt", "r")
        local text = file and file:read("a") or ""
        if file then file:close() end
        toggle_check("saved", text:find("mode=hold", 1, true) ~= nil, (text:gsub("\n", " ")))
    end
    if t > 21 then
        net.log(string.format("Test: toggle checks %d of %d passed", toggle_checks.passed, toggle_checks.total))
        net.log("Test: voice " .. tostring(voice.state and voice.state.stats or "?"))
        go("report", seconds)
    end
end

-- The test block: spawned 3 m ahead, 3 s recorded, then heard from seven places (4 s each) along and across the
-- spawn's facing f (r is its right), the camera at eye height (1.4 m above the block's centre; voice_check.py
-- counts that in the distances).
local block_spots = nil
local block_index = 0

local function run_voice_block(t, seconds)
    if once("block_spawn", t > 1) then
        voice.toggle_block()
        local b = voice.block_position()
        if not b then
            net.log("Test failed: no voice test block")
            go("report", seconds)
            return
        end
        local yaw = controller():GetControlRotation().Yaw
        local f = { math.cos(math.rad(yaw)), math.sin(math.rad(yaw)) }
        local r = { -f[2], f[1] }
        local function at(ahead, right) return { X = b.X + f[1] * ahead + r[1] * right, Y = b.Y + f[2] * ahead + r[2] * right, Z = b.Z + 140 } end
        -- { name, camera, facing }: behind is the first spot turned round, so only the direction changes; the wall spot
        -- is the first of a few nearby places with something between it and the block (the same trace the voice uses).
        local back = { -f[1], -f[2] }
        block_spots = {
            { "ahead_3m", at(-300, 0), f }, { "left_3m", at(0, 300), f }, { "right_3m", at(0, -300), f },
            { "behind_3m", at(-300, 0), back }, { "far_12m", at(-1200, 0), f }, { "beyond_28m", at(-2800, 0), f },
        }
        local system = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        for _, try in ipairs({ { 300, 0 }, { 600, 0 }, { 0, 900 }, { 0, -900 }, { 600, 600 }, { 600, -600 } }) do
            local eye = at(try[1], try[2])
            local hit = false
            pcall(function()
                hit = system:LineTraceSingle(pawn(), eye, { X = b.X, Y = b.Y, Z = b.Z + 40 }, 0, false, {}, 0, {}, true,
                    { R = 0, G = 0, B = 0, A = 0 }, { R = 0, G = 0, B = 0, A = 0 }, 0)
            end)
            if hit == true then
                local metres = math.floor(math.sqrt(try[1] * try[1] + try[2] * try[2]) / 100 + 0.5)
                block_spots[#block_spots + 1] = { "wall_" .. metres .. "m", eye, f }
                break
            end
        end
        net.log(string.format("Test: voice test block at (%.0f, %.0f, %.0f), spawn facing %.0f; %d places to listen from",
            b.X, b.Y, b.Z, yaw, #block_spots))
        local eye = block_spots[1][2]
        set_camera(eye, { X = eye.X + f[1] * 100, Y = eye.Y + f[2] * 100, Z = eye.Z })
    end
    if not block_spots then return end
    if once("block_record", t > 1.5) then
        MPCore_VoiceTalk(true)
        net.log("Test: recording into the block")
    end
    if once("block_play", t > 4.5) then
        MPCore_VoiceTalk(false)
        net.log("Test: block state after recording: " .. tostring(voice.state and voice.state.test))
    end
    if t < 5.5 then return end
    local k = math.floor((t - 5.5) / 4.0) + 1
    if k > #block_spots then
        net.log("Test: voice " .. tostring(voice.state and voice.state.stats or "?"))
        go("report", seconds)
        return
    end
    if k ~= block_index then
        block_index = k
        local eye, facing = block_spots[k][2], block_spots[k][3]
        set_camera(eye, { X = eye.X + facing[1] * 100, Y = eye.Y + facing[2] * 100, Z = eye.Z })
        voice_phase(k, block_spots[k][1])
    end
    if once("block_wall_" .. k, t > 5.5 + (k - 1) * 4.0 + 1.0) then
        net.log(string.format("Test: phase %d %s, the block's wall value %s, state %s", k, block_spots[k][1],
            tostring(voice.occlusion("test-block")), tostring(voice.state and voice.state.test)))
    end
    if k == 1 and once("block_shot", t > 7) then
        screenshot((cfg.name or "player") .. "_voice_block")
    end
    if (k == 1 or k == 2) and once("trace_probe_" .. k, t > 5.5 + (k - 1) * 4.0 + 1.5) then
        voice.trace_probe(net.log)
    end
end

local lineup

-- lineup=1: player bodies in every held pose, side by side across the hall with their pose names as tags, looked at
-- from 5.5 m behind the spawn; one screenshot, and where each body's bones really are in the log.
local function run_lineup(t)
    if not lineup then
        lineup = {}
        local me = pawn()
        local feet = base.Z - (me and me.CapsuleComponent:GetScaledCapsuleHalfHeight() or 90)
        local row_y = base.Y - 220
        for i, pose in ipairs({ "none", "walksout", "fists", "standing" }) do
            local at = { X = base.X + (i - 2.5) * 90, Y = row_y, Z = feet }
            local actor, _, tag = players.figure(at, -90.0, pose, pose)
            -- The camera looks down +Y, so the tags face -Y (a TextRender faces its +X).
            if tag and valid(tag) then tag:K2_SetWorldRotation({ Pitch = 0, Yaw = -90, Roll = 0 }, false, {}, true) end
            lineup[#lineup + 1] = { pose = pose, actor = actor }
        end
        if me then me:SetActorHiddenInGame(true) end
        set_camera({ X = base.X, Y = base.Y - 550, Z = base.Z + 50 }, { X = base.X, Y = row_y, Z = base.Z + 10 })
    elseif t > 2 and not shots_taken.lineup then
        shots_taken.lineup = true
        screenshot((cfg.name or "player") .. "_lineup")
        for _, figure in ipairs(lineup) do
            net.log("Lineup " .. figure.pose .. ": " .. players.describe(figure.actor))
        end
    end
    return t > 4
end

local run_party

local function write_log()
    local file = io.open(test.dir .. "\\test_log.csv", "w")
    if not file then return end
    file:write("kind,t,peer,x,y,z\n")
    for _, row in ipairs(truth) do file:write(string.format("T,%.4f,self,%.1f,%.1f,%.1f\n", row[1], row[2], row[3], row[4])) end
    for _, row in ipairs(shown) do file:write(string.format("P,%.4f,%s,%.1f,%.1f,%.1f\n", row[1], row[2], row[3], row[4], row[5])) end
    file:close()
end

-- Party test ---------------------------------------------------------------------------------------------------------

local party_state = {}

local function describe_character()
    local me = pawn()
    local parts = {}
    pcall(function() parts[#parts + 1] = "money " .. tostring(me.CurrentMoney) end)
    pcall(function() parts[#parts + 1] = "weapons " .. tostring(me.BP_WeaponInventory.AvailableWeapons:GetArrayNum()) end)
    pcall(function() parts[#parts + 1] = "shards " .. tostring(me.BlessedShards) end)
    pcall(function()
        local gi = statics():GetGameInstance(UEHelpers.GetWorld())
        parts[#parts + 1] = "profile " .. gi.CurrentProfileName:ToString()
    end)
    local file = io.open((os.getenv("LOCALAPPDATA") or "") .. "/SinSpire/Saved/SaveGames/Multiplayer.sav", "rb")
    parts[#parts + 1] = "Multiplayer.sav " .. (file and (file:seek("end") .. " bytes") or "missing")
    if file then file:close() end
    return table.concat(parts, ", ")
end

local function hub_portals()
    local list = {}
    for _, door in ipairs(FindAllOf("BP_DoorPortal_C") or {}) do
        if valid(door) and door:GetFullName():find(":PersistentLevel.", 1, true) then
            list[#list + 1] = { door = door, map = door.MapName:ToString() }
        end
    end
    return list
end

run_party = function(t, seconds, level)
    local world = test.world
    if phase == "party_wait" then
        if once("party_char", true) then net.log("Test: character in the hub: " .. describe_character()) end
        local seen = 0
        for _ in pairs(players.displayed()) do seen = seen + 1 end
        if cfg.party_lead == "1" and seen > 0 and t > 5 then
            local maps, chosen = {}, nil
            for _, portal in ipairs(hub_portals()) do
                maps[#maps + 1] = portal.map
                if portal.map == cfg.party then chosen = portal.door end
            end
            -- The Backrooms mod's door is a plain area door, placed a few seconds after the hall opens.
            for _, door in ipairs(FindAllOf("BP_BaseAreaDoor_C") or {}) do
                if valid(door) and door:GetFullName():find(":PersistentLevel.", 1, true) then
                    local map = door.MapName:ToString()
                    if map:find("Backrooms", 1, true) then
                        maps[#maps + 1] = map
                        if cfg.party == "Backrooms" then chosen = door end
                    end
                end
            end
            if not chosen and t < 40 then return end
            net.log("Test: portals in the hub: " .. table.concat(maps, ", "))
            if chosen then
                test.party.start(chosen)
                go("party_run", seconds)
            else
                net.log("Test failed: no portal to " .. tostring(cfg.party))
                go("report", seconds)
            end
        elseif cfg.party_lead ~= "1" and seen > 0 and t > 2 then
            go("party_run", seconds)
        elseif t > 90 then
            net.log("Test failed: never saw the other player in the hub")
            go("report", seconds)
        end
    elseif phase == "party_run" then
        local run = world.run
        if run and level ~= hub.level and once("party_arrived_" .. level, pawn() ~= nil and t > 3) then
            net.log("Test: arrived in " .. level .. " with run seed " .. tostring(run.seed) .. "; character: " .. describe_character())
        end
        if run and run.checked and not party_state.checked_at then
            party_state.checked_at = seconds
            net.log("Test: character after the build: " .. describe_character())
        end
        if party_state.checked_at and once("party_shot", seconds - party_state.checked_at > 3) then
            local me = pawn()
            if me then me.BPC_HealthComponent.ExternalMultiplier = 0 end
            screenshot((cfg.name or "player") .. "_dungeon")
            for peer, actor in pairs(players.puppets()) do
                net.log("Test: in the dungeon the puppet of " .. peer .. ": " .. players.describe(actor))
            end
        end
        if party_state.checked_at and cfg.party_lead == "1" and once("party_take", seconds - party_state.checked_at > 5) then
            -- As if the leader held E on a plain chest: its loot comes from the seed, and the follower's must show open.
            local keys = {}
            for _, line in ipairs(run.items) do
                local key, name = line:match("^(%S+) (%S+)$")
                if name == "BP_BaseChest_C" and run.chests[key] then keys[#keys + 1] = key end
            end
            table.sort(keys)
            local me = pawn()
            if keys[1] and me then
                local chest = run.chests[keys[1]].actor
                net.log("Test: opening the chest at " .. keys[1])
                me.CurrentInteractable = chest
                local ok, problem = pcall(function()
                    chest:BndEvt__BP_BaseChest_BP_InteractableObject_K2Node_ComponentBoundEvent_1_OnHeldInteraction__DelegateSignature()
                end)
                net.log("Test: chest opened " .. tostring(ok) .. " " .. tostring(problem or "") .. ", can interact now "
                    .. tostring(chest.BP_InteractableObject.CanInteract))
            else
                net.log("Test: no chest to open")
            end
        end
        if party_state.checked_at and cfg.party_lead == "1" and seconds - party_state.checked_at > (tonumber(cfg.back_after) or 10) then
            net.log("Test: the leader goes back to the hub")
            test.party.travel(hub.level, nil)
            go("party_back", seconds)
        elseif party_state.checked_at and cfg.party_lead ~= "1" and seconds - party_state.checked_at > 4 then
            go("party_back", seconds)
        elseif t > 300 then
            net.log("Test failed: the dungeon never finished (" .. level .. ")")
            go("report", seconds)
        end
    elseif phase == "party_back" then
        if level == hub.level and pawn() and once("party_home", t > 3 and not test.party.in_run()) then
            net.log("Test: back in the hub; character: " .. describe_character())
            party_state.home_at = seconds
        end
        if party_state.home_at and seconds - party_state.home_at > 4 then
            go("report", seconds)
        elseif t > 150 then
            net.log("Test failed: never got back to the hub (" .. level .. ")")
            go("report", seconds)
        end
    end
end

local AFTER_TRAVEL = { none = "lineup", ["voice-block"] = "voice_block", ["voice-listener"] = "voice_listen",
    ["voice-talker"] = "voice_talk", ["voice-toggle"] = "voice_toggle" }

function test.tick(seconds, level)
    if not test.active then return end
    log_voice_start()
    if phase == "boot" then
        if level == "MenuMap" and controller() and seconds > 4 then
            local ok, why
            if cfg.session == "udp-host" or cfg.session == "voice-listener" then
                ok, why = net.host_udp(tonumber(cfg.port), cfg.name or "Host")
            elseif cfg.session == "udp-join" or cfg.session == "voice-talker" or cfg.session == "voice-toggle" then
                ok, why = net.join_udp(cfg.host or "127.0.0.1", tonumber(cfg.port), tonumber(cfg["local"]), cfg.name or "Guest")
            elseif cfg.session == "none" or cfg.session == "voice-block" then
                hub.go() -- alone: the lineup, or the voice test block
                go("travel", seconds)
                return
            elseif cfg.session == "browser" then
                go("menu", seconds)
                return
            end
            net.log("Test session start: " .. tostring(ok) .. " " .. tostring(why or ""))
            go("connecting", seconds)
        end
    elseif phase == "connecting" then
        if net.in_session() then
            hub.go()
            go("travel", seconds)
        elseif seconds - phase_started > 60 then
            net.log("Test failed: no session (" .. net.state .. ")")
            go("done", seconds)
        end
    elseif phase == "travel" then
        local me = pawn()
        if level == hub.level and me and seconds - phase_started > 2 then
            local at = me:K2_GetActorLocation()
            base = { X = at.X, Y = at.Y, Z = at.Z }
            go(AFTER_TRAVEL[cfg.session] or (cfg.party and "party_wait") or "waiting", seconds)
        end
    elseif phase == "lineup" then
        if run_lineup(seconds - phase_started) then
            go("report", seconds)
        end
    elseif phase == "voice_listen" then
        run_voice_listen(seconds - phase_started, seconds)
    elseif phase == "voice_talk" then
        run_voice_talk(seconds - phase_started, seconds)
    elseif phase == "voice_block" then
        run_voice_block(seconds - phase_started, seconds)
    elseif phase == "voice_toggle" then
        run_voice_toggle(seconds - phase_started, seconds)
    elseif phase == "menu" then
        run_menu(seconds - phase_started, seconds)
    elseif phase == "hub_menu" then
        run_hub_menu(seconds - phase_started, seconds)
    elseif phase == "left" then
        if level == hub.menu_level and not net.in_session() and seconds - phase_started > 2 then
            net.log("Test: left the hub; back in the main menu with the session " .. net.state)
            go("report", seconds)
        elseif seconds - phase_started > 30 then
            net.log("Test failed: never got back to the main menu (" .. level .. ", " .. net.state .. ")")
            go("report", seconds)
        end
    elseif phase == "waiting" then
        local seen = 0
        for _ in pairs(players.displayed()) do seen = seen + 1 end
        if seen > 0 and seconds - phase_started > 3 and cfg.session == "browser" then
            local who = {}
            for id in pairs(players.displayed()) do who[#who + 1] = id end
            net.log("Test: in the hub, showing " .. table.concat(who, ", ") .. "; dialogues started here: "
                .. #(FindAllOf("BP_DialoguePayload_C") or {}))
            screenshot((cfg.name or "player") .. "_hub")
            go("hub_menu", seconds)
        elseif seen > 0 and seconds - phase_started > 3 then
            -- The hall runs along Y; the camera stands 3.5 m behind the other player's circle, at eye height.
            local look = numbers(cfg.look)
            local me = pawn()
            local cx, cy = base.X + (look[1] or 0), base.Y + (look[2] or 0)
            set_camera({ X = cx, Y = cy - 350, Z = base.Z + 50 }, { X = cx, Y = cy, Z = base.Z + 10 })
            net.log("Test: dialogues started in the hub: " .. #(FindAllOf("BP_DialoguePayload_C") or {}))
            if me then me.BPC_HealthComponent.ExternalMultiplier = 0 end
            go("moving", seconds)
        elseif seconds - phase_started > 60 then
            net.log("Test failed: never saw another player")
            go("report", seconds)
        end
    elseif phase == "moving" then
        local me = pawn()
        local c = numbers(cfg.circle)
        local dx, dy, radius, period = c[1] or 0, c[2] or 0, c[3] or 150, c[4] or 8
        local t = seconds - phase_started
        local angle = 2 * math.pi * t / period
        if me then
            -- Log where the game has really put the player (after last frame's movement, so after any push out of
            -- the geometry), which is also what mp_players sent earlier this frame; then move on along the circle.
            local at = me:K2_GetActorLocation()
            local half = me.CapsuleComponent:GetScaledCapsuleHalfHeight()
            local now = net.now()
            truth[#truth + 1] = { now, at.X, at.Y, at.Z - half }
            for peer, where in pairs(players.displayed()) do
                shown[#shown + 1] = { now, peer, where.X, where.Y, where.Z }
            end
            me:K2_SetActorLocation({ X = base.X + dx + radius * math.cos(angle), Y = base.Y + dy + radius * math.sin(angle), Z = base.Z },
                false, {}, true)
        end
        for _, mark in ipairs({ 5, 11 }) do
            if t > mark and not shots_taken[mark] then
                shots_taken[mark] = true
                screenshot((cfg.name or "player") .. "_" .. mark)
                for peer, actor in pairs(players.puppets()) do
                    net.log(string.format("At %ds the puppet of %s: %s", mark, peer, players.describe(actor)))
                end
            end
        end
        if t > (tonumber(cfg.duration) or 20) then
            go("report", seconds)
        end
    elseif phase == "party_wait" or phase == "party_run" or phase == "party_back" then
        run_party(seconds - phase_started, seconds, level)
    elseif phase == "report" then
        if voice then
            voice.unavailable = true -- the recording ends here, and nothing opens it again
            pcall(MPCore_VoiceStop)
        end
        write_log()
        local peers = {}
        for id, p in pairs(net.peers) do peers[#peers + 1] = p.name .. string.format(" (%.1f ms)", p.rtt or -1) end
        net.log(string.format("Test results: %d own positions, %d shown positions, peers: %s", #truth, #shown, table.concat(peers, ", ")))
        net.log("test done")
        go("done", seconds)
    end
end

return test
