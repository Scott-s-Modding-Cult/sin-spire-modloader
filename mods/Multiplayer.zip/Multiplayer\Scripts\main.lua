-- Multiplayer Hub 0.4 (Phase 2). Meet friends in the Starting Hall over Steam and go into dungeons together.
-- The networking is MPCore, this mod's C++ part (dlls\main.dll), which gives this script its MPCore_* functions. Modules:
--   mp_net      sessions, events and text messages
--   mp_players  your position out, everyone else in as puppets with name tags
--   mp_character the multiplayer character: its own save slot, so sessions never touch the campaign's saves
--   mp_hub      hub mode in the Starting Hall, travel, leaving, joining from Steam invites
--   mp_party    the lobby is the party: a hold on a portal takes everyone, and back to the hub together
--   mp_world    the same dungeon for everyone from the run's seed
--   mp_browser  the Extras submenu: host, friends' hubs, and in a hub invite, players and leave
--   mp_voice    proximity voice: positions and walls for MPCore's audio, settings, the voice checks
--   mp_test     a test driver, only when test.txt exists

local UEHelpers = require("UEHelpers")

local MOD_DIR = debug.getinfo(1, "S").source:gsub("^@", ""):gsub("[/\\]Scripts[/\\]main%.lua$", "")

local net = require("mp_net")
if not net.available() then
    print("[Multiplayer] MPCore's functions are missing, so dlls\\main.dll did not load; the mod is off\n")
    return
end
local players = require("mp_players")
local character = require("mp_character")
local hub = require("mp_hub")
local party = require("mp_party")
local world = require("mp_world")
local browser = require("mp_browser")
local voice = require("mp_voice")
local test = require("mp_test")

-- The module inits only register handlers and read files: this chunk runs on UE4SS's thread while the engine starts,
-- so nothing here may touch game objects. That all happens in the game-thread loop below.
players.init(net)
character.init(net)
hub.init(net)
hub.character, hub.party = character, party
party.init(net, hub, world, character)
voice.init(net, players, MOD_DIR)
browser.init(net, hub, voice)
test.init(net, players, hub, MOD_DIR, browser, voice)
world.init(net, MOD_DIR, test.active and test.name or nil)
test.party, test.world = party, world
net.log(MPCore_Version() .. " loaded")

local function level_name()
    local ok, result = pcall(function()
        return StaticFindObject("/Script/Engine.Default__GameplayStatics"):GetCurrentLevelName(UEHelpers.GetWorld(), true):ToString()
    end)
    return ok and result or "?"
end

local STEPS = {
    { "net", function(seconds, level) net.tick(seconds) end },
    { "players", function(seconds, level) players.tick(seconds, level) end },
    { "hub", function(seconds, level) hub.tick(seconds, level) end },
    { "character", function(seconds, level) character.tick(seconds, level) end },
    { "party", function(seconds, level) party.tick(seconds, level) end },
    { "world", function(seconds, level) world.tick(seconds, level) end },
    { "browser", function(seconds, level) browser.tick(seconds, level) end },
    { "voice", function(seconds, level) voice.tick(seconds, level) end },
    { "test", function(seconds, level) test.tick(seconds, level) end },
}
local failures = {}

LoopInGameThreadWithDelay(1, function()
    local seconds = os.clock()
    local level = level_name()
    for _, step in ipairs(STEPS) do
        local ok, problem = pcall(step[2], seconds, level)
        if not ok then
            local name = step[1]
            failures[name] = (failures[name] or 0) + 1
            if failures[name] <= 5 then
                net.log("Error in " .. name .. ": " .. tostring(problem))
            end
        end
    end
    return false
end)
