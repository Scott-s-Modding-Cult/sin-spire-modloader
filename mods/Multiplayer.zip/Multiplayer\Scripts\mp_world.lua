-- Multiplayer Hub: the same dungeon for the whole party. A party run has a run seed, picked by whoever started it and
-- sent with the party's "go" message, and what the game rolls while it builds a dungeon comes out the same on every
-- machine from that seed, so nothing else has to be sent:
--   * the floor builders' seeds, set as the dungeon manager collects the builders, and a fresh seed from the run seed
--     when a build fails its checks (the game would pick a random one);
--   * the builders' door roll and each wall's door roll: their chance is swapped for a marker value, and a hook on
--     RandomBoolWithWeight answers marker rolls from the seed;
--   * other RandomBoolWithWeight rolls while the dungeon builds (locked floor doors and the like), from a stream per
--     weight value, as the rooms load one at a time in the same order everywhere;
--   * item spawn points: started here one by one in the order of their places as the dungeon finishes, before the
--     game would, with their rolls answered from the seed (see roll_items). A share of the story-capable spots is kept
--     for the game's story notes, which follow each player's own story and may differ;
--   * which key stand keeps the key on each floor.
-- First pickup wins: each machine watches the items it spawned from the seed, and when one is gone (picked up), tells
-- the others, who remove their copy of it (TAKE|seed|spot).
-- Chests (most of what the spots make): the loot is rolled when a chest opens (RandomFloatInRange(0, ValueSum) in its
-- GetLoot), while the opening player's CurrentInteractable is that chest, so that roll is answered from the seed and
-- the chest's place: the same loot whoever opens it. First open wins: a chest opened here is announced
-- (OPEN|seed|spot), and the others' copy is shown open and can't be opened, with nothing in it.
-- When the dungeon is finished, a check sum of rooms, doors, walls, locks, key stands and items is logged and sent, and a
-- difference from another player's is logged. In test mode the full list is written to layout_<name>.txt.

local UEHelpers = require("UEHelpers")

local world = { run = nil }
local net

local HOOKS = {
    actors = "/Script/Engine.GameplayStatics:GetAllActorsOfClass",
    roll = "/Script/Engine.KismetMathLibrary:RandomBoolWithWeight",
    span = "/Script/Engine.KismetMathLibrary:RandomFloatInRange",
    coin = "/Script/Engine.KismetMathLibrary:RandomBool",
    reseed = "/Script/Engine.KismetMathLibrary:SeedRandomStream",
    event = "/Script/EasyEventSystem.EasyEventManagerLibrary:CallEvent",
}
local BUILDER = "DungeonBuilder_C"
local SPAWN_POINT = "BP_ActorSpawnPoint_C"
local WALL = "BP_GenericWall_C"
local KEY_STAND = "BP_KeyStand_C"
local KEY_MANAGER = "BP_KeyStandManager_C"
local KEY_FLOOR_CM = 100.0 -- a key manager's stands are those within this height of it, as the game checks
local WINDOW_AFTER_SECONDS = 2.0 -- rolls still answered from the seed this long after FinishedGeneration
local CHECK_AFTER_SECONDS = 4.0 -- the layout check this long after FinishedGeneration
local TAKE_CHECK_SECONDS = 0.2 -- how often the items are checked for pickups and chests for opening
local CHEST_OPEN_ANIM = "/Game/Models/Objects/Chest/Anim_ChestOpen.Anim_ChestOpen"
-- A wall making a door looks for doors in a box 750 cm along it and 125 cm across and up (BP_GenericWall CreateDoor),
-- which a door's own size reaches past, so walls are kept a little further apart than that.
local WALL_BOX_ALONG, WALL_BOX_ACROSS = 950.0, 250.0
-- Marker chances are (MARK_BASE + n) / 2^24: exact in a float and a double, and not a value anyone types.
local MARK_BASE = 1234567
local MARK_SCALE = 16777216
-- Loose pickups other mods place (the Backrooms' ammo), checked in the layout and watched for first pickup wins.
local PICKUP_CLASSES = { "BP_PistolAmmo_Pickup_C", "BP_RifleAmmoPickup_C", "BP_Buckshot_Pickup_C" }
local DOOR_CLASSES = { "BP_OpenableDoor_C", "BP_DoubleDoor_C", "BP_SlidingDoor_C", "BP_LocalTravellingDoor_C",
    "BP_LocalTravellingDoor_Child_C", "BP_BaseAreaDoor_C", "BP_EndAreaDoor_C", "BP_BossDoor_C" }

local hooked = {}
local markers, mark_count = {}, 0

local function valid(object)
    return object ~= nil and object:IsValid()
end

-- A real actor in a level (FindAllOf also returns class defaults and templates), not on its way out.
local function live(actor)
    if not valid(actor) then return false end
    local ok, placed = pcall(function() return actor:GetFullName():find(":PersistentLevel.", 1, true) ~= nil end)
    if not ok or not placed then return false end
    local ok_dying, dying = pcall(function() return actor:IsActorBeingDestroyed() end)
    return ok_dying and not dying
end

local function statics()
    return StaticFindObject("/Script/Engine.Default__GameplayStatics")
end

-- Numbers from the run seed ------------------------------------------------------------------------------------------

local function mix(x)
    x = x + 0x9E3779B97F4A7C15
    x = (x ~ (x >> 30)) * 0xBF58476D1CE4E5B9
    x = (x ~ (x >> 27)) * 0x94D049BB133111EB
    return x ~ (x >> 31)
end

local function hash_text(text)
    local h = 0xcbf29ce484222325
    for i = 1, #text do h = (h ~ text:byte(i)) * 0x100000001b3 end
    return h
end

-- A number in [0, 1) for (seed, key, n), the same on every machine.
local function chance(seed, key, n)
    local h = mix(seed ~ mix(hash_text(key) ~ mix(n or 0)))
    return (h >> 11) * (1.0 / 9007199254740992.0)
end

-- A seed for a builder: a positive 31-bit number.
local function derive(seed, key)
    return (mix(seed ~ hash_text(key)) >> 33) + 1
end
world.derive = derive

local function round(v, step)
    return math.floor(v / step + 0.5)
end

local function spot_key(at)
    return string.format("%d,%d,%d", round(at.X, 10), round(at.Y, 10), round(at.Z, 10))
end

local function actor_key(actor)
    local ok, at = pcall(function() return actor:K2_GetActorLocation() end)
    return ok and spot_key(at) or "?"
end

local function class_name(object)
    local ok, name = pcall(function() return object:GetClass():GetFName():ToString() end)
    return ok and name or "?"
end

local function short_name(class)
    local ok, name = pcall(function() return class:GetFName():ToString() end)
    return ok and name or "?"
end

-- A hook or ForEach parameter's value (some come as parameters with get, some as the value itself).
local function unwrap(x)
    local ok, value = pcall(function() return x:get() end)
    if ok then return value end
    return x
end

local function new_marker(entry)
    mark_count = mark_count + 1
    markers[mark_count] = entry
    return (MARK_BASE + mark_count) / MARK_SCALE
end

local function marker_of(weight)
    local n = weight * MARK_SCALE - MARK_BASE
    if n >= 1 and n == math.floor(n) then return markers[math.floor(n)] end
    return nil
end

-- Builders -----------------------------------------------------------------------------------------------------------

local function set_seed(builder, value)
    builder.UseRandomSeed = false
    builder.Seed.InitialSeed = value
    builder.Seed.Seed = value
    if builder.Seed.InitialSeed ~= value then
        builder.Seed = { InitialSeed = value, Seed = value }
    end
end

local function seed_builders(source)
    local run = world.run
    if not run then return end
    local count = 0
    for _, builder in ipairs(FindAllOf(BUILDER) or {}) do
        if live(builder) then
            local key = actor_key(builder)
            local state = run.builders[key]
            if not state then
                state = { seed = derive(run.seed, "builder " .. key), retries = 0 }
                state.door = { kind = "builder", key = key, chance = builder.DoorChance, rolls = 0 }
                run.builders[key] = state
                builder.DoorChance = new_marker(state.door)
                count = count + 1
                net.log(string.format("World: builder at %s seeded %d (door chance %.2f) from %s", key, state.seed,
                    state.door.chance, source))
            end
            state.builder = builder
            if builder.Seed.InitialSeed ~= state.seed then set_seed(builder, state.seed) end
        end
    end
    if count > 0 and not run.window then
        run.window = true
        net.log("World: rolls follow the run seed from now")
    end
end

-- A build that failed its checks has just been given a random seed: replace it with the next one from the run seed.
local function reseed_failed()
    local run = world.run
    if not run then return end
    for key, state in pairs(run.builders) do
        local builder = state.builder
        if live(builder) and builder.Seed.InitialSeed ~= state.seed then
            state.retries = state.retries + 1
            state.seed = derive(run.seed, "builder " .. key .. " retry " .. state.retries)
            set_seed(builder, state.seed)
            net.log(string.format("World: builder at %s failed a build; retry %d with seed %d", key, state.retries, state.seed))
        end
    end
end

-- Rolls --------------------------------------------------------------------------------------------------------------

local function answer_roll(weight)
    local run = world.run
    if not run then return nil end
    if run.current then
        -- A kind of the item spot this script is starting.
        run.current.rolls = run.current.rolls + 1
        return weight > 0 and weight >= chance(run.seed, "item " .. run.current.key, run.current.rolls)
    end
    local entry = marker_of(weight)
    if entry then
        entry.rolls = entry.rolls + 1
        local result = entry.fixed
        if result == nil then
            result = entry.chance > 0 and entry.chance >= chance(run.seed, entry.kind .. " " .. entry.key, entry.rolls)
        end
        run.counts[entry.kind] = (run.counts[entry.kind] or 0) + 1
        return result
    end
    if run.window and (not run.window_until or os.clock() < run.window_until) and weight > 0 and weight < 1 then
        local bits = string.format("%.9g", weight)
        local n = (run.streams[bits] or 0) + 1
        run.streams[bits] = n
        run.counts.stream = (run.counts.stream or 0) + 1
        return weight >= chance(run.seed, "weight " .. bits, n)
    end
    return nil
end

-- Walls roll a few frames after FinishedDungeon (a random 0 to 30 frames each), each once, and a wall that rolls a door
-- first looks for a door within a 15 m box along itself and makes none if there is one. So which wall of a stretch gets
-- the door depends on which rolls first. Here every wall's answer is decided now, from the seed, and of the walls that
-- would make a door near each other only the first by place keeps its yes, so the order no longer matters.
local function wall_rolls(wall)
    local ok, rolls = pcall(function()
        local point = wall.ConnectionPoint
        return wall["SwitchToDoor?"] == true and point ~= nil and point:IsValid() and point.State == 1
    end)
    return ok and rolls
end

local function within_box(from, to)
    local dx, dy, dz = to.at.X - from.at.X, to.at.Y - from.at.Y, to.at.Z - from.at.Z
    local along = dx * from.fx + dy * from.fy
    local across = -dx * from.fy + dy * from.fx
    return math.abs(along) <= WALL_BOX_ALONG and math.abs(across) <= WALL_BOX_ACROSS and math.abs(dz) <= WALL_BOX_ACROSS
end

local function mark_walls()
    local run = world.run
    local walls = {}
    for _, wall in ipairs(FindAllOf(WALL) or {}) do
        if live(wall) then
            pcall(function()
                local current = wall.DoorChance
                if not marker_of(current) then
                    local forward = wall:GetActorForwardVector()
                    local length = math.sqrt(forward.X * forward.X + forward.Y * forward.Y)
                    if length < 0.001 then length = 1.0 end
                    walls[#walls + 1] = { actor = wall, key = actor_key(wall), chance = current, at = wall:K2_GetActorLocation(),
                        fx = forward.X / length, fy = forward.Y / length, rolls = wall_rolls(wall) }
                end
            end)
        end
    end
    table.sort(walls, function(a, b) return a.key < b.key end)
    local doors, dropped = {}, 0
    for _, wall in ipairs(walls) do
        local yes = wall.rolls and wall.chance > 0 and wall.chance >= chance(run.seed, "wall " .. wall.key, 1)
        if yes then
            for _, door in ipairs(doors) do
                if within_box(door, wall) or within_box(wall, door) then
                    yes = false
                    dropped = dropped + 1
                    break
                end
            end
        end
        if yes then doors[#doors + 1] = wall end
        pcall(function()
            wall.actor.DoorChance = new_marker({ kind = "wall", key = wall.key, chance = wall.chance, rolls = 0, fixed = yes })
        end)
    end
    net.log(string.format("World: %d walls follow the run seed: %d make doors (%d more were too near one)", #walls, #doors, dropped))
end

-- Item spots. UE4SS can't hand a spot's ActorTypesToSpawn (kind -> weight) to Lua (TMap ForEach fails on its class
-- keys), so the game's own BP_ActorSpawnPoint Start does the rolling, but this script starts each spot itself, in the
-- order of the spots' places, as the dungeon finishes and before the game would. While a spot's Start runs, the hooks
-- know which spot it is and answer its rolls from the seed: each kind's RandomBoolWithWeight, and at its RandomBool
-- (spawn anything at all, half the time) the kinds that passed are cut down to one, picked from the seed, so the game's
-- own random pick has one choice. A share of the story-capable spots is kept back for the game's story notes, with
-- nothing left in them for the game to roll when it starts the rest.
local STORY_SHARE = 0.06

local function class_list(array)
    local list = {}
    for i = 1, array:GetArrayNum() do
        list[#list + 1] = unwrap(array[i])
    end
    return list
end

-- Answers RandomBool for the spot being started: keep one of the kinds that passed, spawn or not.
local function answer_spot_bool()
    local run = world.run
    local current = run.current
    current.bools = current.bools + 1
    if current.bools > 1 then return nil end
    local ok, problem = pcall(function()
        local array = current.spot.SpawnableActors
        local kinds = class_list(array)
        if #kinds > 1 then
            table.sort(kinds, function(a, b) return short_name(a) < short_name(b) end)
            local keep = kinds[math.floor(chance(run.seed, "item " .. current.key, 1001) * #kinds) + 1]
            array:Empty()
            array[1] = keep
            kinds = { keep }
        end
        current.kind = kinds[1]
    end)
    if not ok and not run.item_problem then
        run.item_problem = true
        net.log("World: could not cut an item spot's kinds to one: " .. tostring(problem))
    end
    current.spawns = chance(run.seed, "item " .. current.key, 1000) < 0.5
    return current.spawns
end

-- The items the spots have made, found by kind and place, for the layout check and for pickups.
local function find_items(made)
    local run = world.run
    local by_class = {}
    for key, class in pairs(made) do
        local name = short_name(class)
        by_class[name] = by_class[name] or {}
        by_class[name][key] = true
    end
    local found = 0
    for name, keys in pairs(by_class) do
        for _, actor in ipairs(FindAllOf(name) or {}) do
            if live(actor) then
                local key = actor_key(actor)
                if keys[key] and not run.item_actors[key] then
                    run.item_actors[key] = actor
                    run.items[#run.items + 1] = key .. " " .. name
                    found = found + 1
                    if name:lower():find("chest", 1, true) then
                        run.chests[key] = { actor = actor, open = false }
                    end
                end
            end
        end
    end
    return found
end

local function roll_items()
    local run = world.run
    local spots = {}
    for _, spot in ipairs(FindAllOf(SPAWN_POINT) or {}) do
        if live(spot) then
            spots[#spots + 1] = { spot = spot, key = actor_key(spot), story = spot.CanSpawnStoryObject == true }
        end
    end
    table.sort(spots, function(a, b) return a.key < b.key end)
    local started, kept, problems = 0, 0, 0
    local made = {}
    for _, entry in ipairs(spots) do
        if entry.story and chance(run.seed, "story " .. entry.key, 1) < STORY_SHARE then
            -- Kept back for a story note; when the game starts it, it finds nothing to spawn.
            local ok = pcall(function()
                entry.spot.ActorTypesToSpawn:Empty()
                entry.spot.SpawnableActors:Empty()
            end)
            if ok then kept = kept + 1 else problems = problems + 1 end
        else
            run.current = { spot = entry.spot, key = entry.key, rolls = 0, bools = 0 }
            local ok, problem = pcall(function() entry.spot:Start() end)
            local current = run.current
            run.current = nil
            if ok then
                started = started + 1
                if current.spawns and current.kind then made[entry.key] = current.kind end
            else
                problems = problems + 1
                if problems == 1 then net.log("World: an item spot failed to start: " .. tostring(problem)) end
            end
        end
    end
    local found = find_items(made)
    local wanted = 0
    for _ in pairs(made) do wanted = wanted + 1 end
    net.log(string.format("World: %d item spots started from the run seed (%d items made, %d found), %d kept for story notes, %d problems",
        started, wanted, found, kept, problems))
end

-- Of the key stands a key manager would choose from, keep one from the seed and remove the rest, then hand the game the
-- stands that are left, so its own random pick has one choice.
local function settle_key_stands(out_param)
    local run = world.run
    local stands = {}
    for _, stand in ipairs(FindAllOf(KEY_STAND) or {}) do
        if live(stand) then stands[#stands + 1] = { actor = stand, key = actor_key(stand), z = stand:K2_GetActorLocation().Z } end
    end
    table.sort(stands, function(a, b) return a.key < b.key end)
    local removed = 0
    for _, manager in ipairs(FindAllOf(KEY_MANAGER) or {}) do
        if live(manager) then
            local mkey = actor_key(manager)
            local z = manager:K2_GetActorLocation().Z
            local choices = {}
            for _, stand in ipairs(stands) do
                if not stand.gone and math.abs(stand.z - z) <= KEY_FLOOR_CM then choices[#choices + 1] = stand end
            end
            if #choices > 1 then
                local keep = math.floor(chance(run.seed, "key " .. mkey, 1) * #choices) + 1
                for i, stand in ipairs(choices) do
                    if i ~= keep then
                        stand.gone = true
                        stand.actor:K2_DestroyActor()
                        removed = removed + 1
                    end
                end
                if not run.keys[mkey] then
                    run.keys[mkey] = choices[keep].key
                    net.log(string.format("World: key manager at %s keeps the stand at %s of %d", mkey, choices[keep].key, #choices))
                end
            end
        end
    end
    if removed > 0 then
        local array = out_param:get()
        array:Empty()
        local n = 0
        for _, stand in ipairs(stands) do
            if not stand.gone then
                n = n + 1
                array[n] = stand.actor
            end
        end
    end
end

-- The layout check ---------------------------------------------------------------------------------------------------

local function layout_lines()
    local lines = {}
    local function add_all(class, extra)
        local spots = {}
        for _, actor in ipairs(FindAllOf(class) or {}) do
            if live(actor) then
                local line = class .. " " .. actor_key(actor)
                if extra then line = line .. extra(actor) end
                spots[#spots + 1] = line
            end
        end
        table.sort(spots)
        for _, line in ipairs(spots) do lines[#lines + 1] = line end
        return #spots
    end
    local counts = {}
    local rooms = {}
    for _, manager in ipairs(FindAllOf("BP_Sublevel_Manager_C") or {}) do
        local active = false
        pcall(function() active = manager.LevelActive == true end)
        if live(manager) and active then
            pcall(function()
                local t = manager.Transform
                rooms[#rooms + 1] = string.format("room %s %s %d", manager.Name:ToString(), spot_key(t.Translation),
                    round(t.Rotation.Z * 1000, 1))
            end)
        end
    end
    table.sort(rooms)
    for _, line in ipairs(rooms) do lines[#lines + 1] = line end
    counts.rooms = #rooms
    local doors = 0
    for _, class in ipairs(DOOR_CLASSES) do
        doors = doors + add_all(class, function(door)
            local ok, locked = pcall(function() return door.Locked end)
            return (ok and locked == true) and " locked" or ""
        end)
    end
    counts.doors = doors
    counts.walls = add_all(WALL)
    counts.keys = add_all(KEY_STAND)
    counts.spawners = add_all("BP_AISpawner_C")
    counts.pickups = 0
    for _, class in ipairs(PICKUP_CLASSES) do
        counts.pickups = counts.pickups + add_all(class, function(pickup)
            local key = actor_key(pickup)
            if not world.run.item_actors[key] and not world.run.taken[key] then world.run.item_actors[key] = pickup end
            return ""
        end)
    end
    local items = {}
    for _, line in ipairs(world.run.items) do items[#items + 1] = "item " .. line end
    table.sort(items)
    for _, line in ipairs(items) do lines[#lines + 1] = line end
    counts.items = #items
    return lines, counts
end

local function check_layout()
    local run = world.run
    local lines, counts = layout_lines()
    local sum = 0
    for _, line in ipairs(lines) do sum = mix(sum ~ hash_text(line)) end
    run.sum = string.format("%016x", sum)
    net.log(string.format("World: layout %s on %s: %d rooms, %d doors, %d walls, %d key stands, %d spawners, %d items, %d pickups (rolls: %d builder doors, %d walls, %d other)",
        run.sum, run.map, counts.rooms, counts.doors, counts.walls, counts.keys, counts.spawners, counts.items, counts.pickups,
        run.counts.builder or 0, run.counts.wall or 0, run.counts.stream or 0))
    if world.dump_path then
        local file = io.open(world.dump_path, "w")
        if file then
            file:write("seed " .. run.seed .. "\nmap " .. run.map .. "\n" .. table.concat(lines, "\n") .. "\n")
            file:close()
        end
    end
    net.send("*", 2, true, "LAYOUT", run.seed, run.sum, counts.rooms, counts.doors, counts.items)
    for peer, theirs in pairs(run.theirs) do
        world.compare(peer, theirs)
    end
end

function world.compare(peer, theirs)
    local run = world.run
    if not run or not run.sum then return end
    local name = net.peers[peer] and net.peers[peer].name or peer
    if theirs.sum == run.sum then
        net.log("World: same layout as " .. name)
    else
        net.log(string.format("World: layout differs from %s's (theirs %s: %s rooms, %s doors, %s items)", name, theirs.sum,
            theirs.rooms, theirs.doors, theirs.items))
    end
end

-- Hooks --------------------------------------------------------------------------------------------------------------

local answer_chest -- below, with the chests

local function install_hooks()
    local function add(key, pre, post)
        if hooked[key] then return end
        local function guard(fn, label)
            return function(...)
                local ok, result = pcall(fn, ...)
                if not ok then
                    net.log("World hook error (" .. label .. "): " .. tostring(result))
                    return nil
                end
                return result
            end
        end
        local ok, problem
        if post then
            ok, problem = pcall(RegisterHook, HOOKS[key], guard(pre, key), guard(post, key .. " after"))
        else
            ok, problem = pcall(RegisterHook, HOOKS[key], guard(pre, key))
        end
        hooked[key] = ok
        if not ok then net.log("World: could not hook " .. HOOKS[key] .. ": " .. tostring(problem)) end
    end
    add("actors", function(_, _, class)
        if not world.run then return nil end
        if short_name(class:get()) == BUILDER then seed_builders("the dungeon manager") end
        return nil
    end, function(_, _, class, out)
        if not world.run then return nil end
        if short_name(class:get()) == KEY_STAND then settle_key_stands(out) end
        return nil
    end)
    add("roll", function(_, weight)
        if not world.run then return nil end
        return answer_roll(weight:get())
    end)
    add("span", function(_, low, high)
        if not world.run then return nil end
        return answer_chest(tonumber(unwrap(low)) or -1, tonumber(unwrap(high)) or -1)
    end)
    add("coin", function()
        if world.run and world.run.current then return answer_spot_bool() end
        return nil
    end)
    add("reseed", function() return nil end, function()
        if world.run then reseed_failed() end
        return nil
    end)
    add("event", function(_, _, event)
        local run = world.run
        if not run then return nil end
        local name = event:get():ToString()
        if name == "FinishedDungeon" and not run.finished_dungeon then
            run.finished_dungeon = true
            mark_walls()
            roll_items()
        elseif name == "FinishedGeneration" and not run.generated_at then
            run.generated_at = os.clock()
            run.window_until = run.generated_at + WINDOW_AFTER_SECONDS
            net.log("World: the dungeon is built")
        end
        return nil
    end)
end

-- Public -------------------------------------------------------------------------------------------------------------

-- The loot roll of a chest the local player is opening.
answer_chest = function(low, high)
    local run = world.run
    local me = world.me
    if not run or not run.finished_dungeon or low ~= 0 or not valid(me) then return nil end
    local target
    pcall(function() target = me.CurrentInteractable end)
    if not live(target) then return nil end
    local key = actor_key(target)
    local chest = run.chests[key]
    if not chest then return nil end
    local sum
    pcall(function() sum = target.ValueSum end)
    if type(sum) ~= "number" or math.abs(sum - high) > 0.001 then return nil end
    local value = high * chance(run.seed, "chest " .. key, 1)
    net.log(string.format("World: the chest at %s rolls %.2f of %.2f from the run seed", key, value, high))
    return value
end

local function show_open(chest)
    local actor = chest.actor
    pcall(function() actor.BP_InteractableObject.CanInteract = false end)
    pcall(function() actor.BP_InteractableObject:DoUnhighlight() end)
    pcall(function()
        local anim = StaticFindObject(CHEST_OPEN_ANIM)
        if valid(anim) then actor.SkeletalMesh:PlayAnimation(anim, false) end
    end)
    pcall(function() actor.SkeletalMesh:SetCollisionEnabled(0) end)
end

local function check_chests()
    local run = world.run
    for key, chest in pairs(run.chests) do
        if not chest.open then
            local can = true
            pcall(function() can = chest.actor.BP_InteractableObject.CanInteract end)
            if live(chest.actor) and can == false then
                chest.open = true
                net.send("*", 2, true, "OPEN", run.seed, key)
                net.log("World: you opened the chest at " .. key)
            end
        end
    end
end

local function on_open(peer, f)
    local run = world.run
    local key = (f[3] or ""):sub(1, 40)
    if not run or tostring(run.seed) ~= f[2] then return end
    local chest = run.chests[key]
    local name = net.peers[peer] and net.peers[peer].name or peer
    if not chest then
        net.log("World: " .. name .. " opened a chest at " .. key .. " (not here)")
        return
    end
    if chest.open then return end
    chest.open = true
    if live(chest.actor) then show_open(chest) end
    net.log("World: " .. name .. " opened the chest at " .. key .. ", so it is open and empty here")
end

-- True from the moment this game asks for another level (the level's actors may already be going).
local function party_leaving()
    return world.leaving_at ~= nil and os.clock() - world.leaving_at < 30.0
end

-- Items gone from this game (picked up here) are announced; the others remove theirs.
local function check_pickups()
    local run = world.run
    for key, item in pairs(run.item_actors) do
        if not live(item) then
            run.item_actors[key] = nil
            if not run.taken[key] then
                run.taken[key] = true
                net.send("*", 2, true, "TAKE", run.seed, key)
                net.log("World: you took the item at " .. key)
            end
        end
    end
end

local function on_take(peer, f)
    local run = world.run
    local key = (f[3] or ""):sub(1, 40)
    if not run or tostring(run.seed) ~= f[2] or run.taken[key] then return end
    run.taken[key] = true
    local item = run.item_actors[key]
    run.item_actors[key] = nil
    local name = net.peers[peer] and net.peers[peer].name or peer
    if live(item) then
        item:K2_DestroyActor()
        net.log("World: " .. name .. " took the item at " .. key .. ", so it is gone here too")
    else
        net.log("World: " .. name .. " took the item at " .. key .. " (not here)")
    end
end

function world.init(session, mod_dir, test_name)
    net = session
    net.on("msg:TAKE", on_take)
    net.on("msg:OPEN", on_open)
    if test_name then world.dump_path = mod_dir .. "\\layout_" .. test_name .. ".txt" end
    net.on("msg:LAYOUT", function(peer, f)
        local run = world.run
        if not run or tostring(run.seed) ~= f[2] then return end
        local theirs = { sum = (f[3] or ""):sub(1, 32), rooms = f[4], doors = f[5], items = f[6] }
        run.theirs[peer] = theirs
        world.compare(peer, theirs)
    end)
end

-- A party run is starting: from now until the run ends, dungeons follow this seed.
function world.begin_run(seed, map, leader, from_level)
    install_hooks()
    markers, mark_count = {}, 0
    world.run = { seed = seed, map = map, leader = leader, from_level = from_level, builders = {}, streams = {},
        counts = {}, items = {}, keys = {}, theirs = {}, item_actors = {}, taken = {}, chests = {} }
    net.log(string.format("World: run seed %d for %s, led by %s", seed, map, tostring(leader)))
end

function world.end_run(why)
    if world.run then
        net.log("World: run over (" .. tostring(why) .. ")")
    end
    world.run = nil
    markers, mark_count = {}, 0
end

function world.tick(seconds, level)
    local here = UEHelpers.GetWorld()
    local address = valid(here) and here:GetAddress() or 0
    if address ~= world.last_address then
        world.last_address = address
        world.leaving_at = nil -- a new level: whatever was leaving has left
    end
    local run = world.run
    if not run then return end
    local pc = FindFirstOf("PlayerController")
    world.me = (valid(pc) and valid(pc.Pawn)) and pc.Pawn or nil
    if not run.window and level ~= run.from_level and seconds - (run.looked_at or 0) >= 0.25 then
        run.looked_at = seconds
        seed_builders("the loop") -- as soon as builders appear, in case the hook missed them
    end
    if run.finished_dungeon and seconds - (run.take_checked_at or 0) >= TAKE_CHECK_SECONDS then
        run.take_checked_at = seconds
        -- Only in the world the items were made in: when it closes, its items go with it, and that is no pickup.
        if not run.world_address then
            run.world_address = address
            local n = 0
            for _ in pairs(run.item_actors) do n = n + 1 end
            net.log(string.format("World: watching %d items for pickups", n))
        end
        if address == run.world_address and not party_leaving() then
            check_pickups()
            check_chests()
        elseif not run.take_skip_logged then
            run.take_skip_logged = true
            net.log(string.format("World: not watching pickups (world %s, leaving %s)", tostring(address == run.world_address),
                tostring(party_leaving())))
        end
    end
    if run.generated_at and not run.checked and os.clock() - run.generated_at >= CHECK_AFTER_SECONDS then
        run.checked = true
        local ok, problem = pcall(check_layout)
        if not ok then net.log("World: layout check failed: " .. tostring(problem)) end
    end
end

return world
