-- Multiplayer Hub: the party. Everyone in the hub is the party. When anyone holds E on a portal (or the Backrooms door),
-- everyone in the hub goes, led by whoever held it: a "go" message carries the map, the door, a new run seed and a
-- departure time on the session clock, and at that time every machine travels the same way. If two people start a run
-- at once, the earlier departure wins (then the lower player id), and every machine picks the same one.
-- The run seed makes the dungeon the same for everyone (mp_world), and the Backrooms mod reads it from the shared
-- variable Multiplayer_RunSeed. Each player keeps their own enemies until shared enemies exist (Phase 3).
-- Back to the hub: when the leader comes back to the hub, everyone still in the run follows; if the leader leaves the
-- session, the run is over and the others go back to the hub. In a session, the hall's other version
-- (StartingHall_Destroyed, where the game's exits lead after its opening) is swapped for the hub as it opens.
-- If the session ends while you are in a level (the host left), you go back to the main menu, where the multiplayer
-- character is put away.
-- Messages: GO|map|door|seed|departure|leader   BACK|seed

local UEHelpers = require("UEHelpers")

local party = {}
local net, hub, world, character

local DEPART_DELAY = 2.5
local MENU_DELAY = 4.0
local SEED_VARIABLE = "Multiplayer_RunSeed"
local HALL_VERSIONS = { StartingHall_Destroyed = true }
local COMMON_LIBRARY = "/Game/Blueprints/BPFL_CommonFunctions.Default__BPFL_CommonFunctions_C"
local MESSAGE_COLOUR = { R = 0.95, G = 0.85, B = 1.0, A = 1.0 }
local OPEN_LEVEL_HOOK = "/Script/Engine.GameplayStatics:OpenLevel"

local pending = nil -- the chosen "go", until its departure
local run = nil -- the run we are in: { seed, map, leader, level }
local was_in_session = false
local menu_at = nil
local level_hooked = false
local back_pending = nil -- why the party goes back, done on the next tick rather than inside a message handler
-- Shown once back in the hub: a HUD message in the same frame as a level change was the one difference on the path that
-- crashed twice in four off-screen runs (the game itself shows its "Autosaving..." seconds before it travels).
local arrival_note = nil
local NOTE_AFTER_SECONDS = 1.5

local function valid(object)
    return object ~= nil and object:IsValid()
end

local function fname(text)
    return FName(text, EFindName.FNAME_Add)
end

local function statics()
    return StaticFindObject("/Script/Engine.Default__GameplayStatics")
end

local function game_instance()
    local ok, gi = pcall(function() return statics():GetGameInstance(UEHelpers.GetWorld()) end)
    if ok and valid(gi) then return gi end
    return nil
end

local function player()
    local pc = FindFirstOf("PlayerController")
    if valid(pc) and valid(pc.Pawn) and valid(pc.Pawn.CapsuleComponent) then return pc.Pawn end
    return nil
end

local function say(text)
    net.log("Party: " .. text)
    local me = player()
    if me then
        pcall(function() StaticFindObject(COMMON_LIBRARY):ShowHudMessage(FText(text), MESSAGE_COLOUR, me) end)
    end
end

local function name_of(peer)
    if peer == net.self_id then return "you" end
    local p = net.peers[peer]
    return p and p.name or "another player"
end

-- "LustDungeon" -> "Lust Dungeon", "/Game/Mods/Backrooms/Backrooms" -> "Backrooms".
local function title(map)
    local last = tostring(map):match("([^/%.]+)$") or tostring(map)
    return (last:gsub("(%l)(%u)", "%1 %2"):gsub("_", " "))
end

local function share_seed(seed)
    pcall(function() ModRef:SetSharedVariable(SEED_VARIABLE, seed or 0) end)
end

-- Every level change in a session goes through here, so the character's state goes along: into a dungeon by the door
-- the leader used (the game puts the player at that door and loads the state), anywhere else by loading the state on
-- arrival as a loaded game does. fresh: the character was loaded just now, so the player here is not it.
function party.travel(map, door, fresh)
    local gi = game_instance()
    local me = not fresh and player() or nil
    if gi and me then
        pcall(function() gi:SavePlayerState(me) end)
        if character.active then pcall(function() gi:SaveProfileProgress(me) end) end
    end
    if gi then
        if door and door ~= "" and door ~= "None" then
            gi.CurrentDoorID = fname(door)
            gi.LoadingThroughDoor = true
            gi.LoadingFromSave = false
        else
            gi.LoadingThroughDoor = false
            gi.LoadingFromSave = me ~= nil or fresh == true or gi.LoadingFromSave
        end
    end
    statics():OpenLevel(UEHelpers.GetWorld(), fname(map), true, "")
end

local function better(a, b)
    if not b then return true end
    if a.depart ~= b.depart then return a.depart < b.depart end
    return tostring(a.leader) < tostring(b.leader)
end

local function accept(go, level)
    if level ~= hub.level then
        net.log(string.format("Party: %s is starting a run to %s, but you are not in the hub", name_of(go.leader), title(go.map)))
        return
    end
    if not better(go, pending) then return end
    pending = go
    local count = net.peer_count() + 1
    say(string.format("%s %s: everyone goes to %s (%d %s)", go.leader == net.self_id and "You lead" or (name_of(go.leader) .. " leads"),
        "the party", title(go.map), count, count == 1 and "player" or "players"))
end

-- A hold on a portal or the Backrooms door in the hub: lead the whole lobby there.
function party.start(door_actor)
    local gi = game_instance()
    local map, door
    local ok, problem = pcall(function()
        map = door_actor.MapName:ToString()
        if gi and gi.UsesClassicDungeons and door_actor.HasClassicMap then
            local classic = door_actor.ClassicMapName:ToString()
            if classic ~= "" and classic ~= "None" then map = classic end
        end
        door = door_actor.DoorID:ToString()
    end)
    if not ok or not map or map == "" or map == "None" then
        net.log("Party: that door has no map (" .. tostring(problem) .. ")")
        return
    end
    local go = { map = map, door = door or "", seed = math.random(1, 2147483646), depart = net.now() + DEPART_DELAY,
        leader = net.self_id }
    net.send("*", 2, true, "GO", go.map, go.door, go.seed, string.format("%.3f", go.depart), go.leader)
    accept(go, hub.level)
end

local function on_go(peer, f)
    local depart, seed = tonumber(f[5]), tonumber(f[4])
    local map, door = (f[2] or ""):sub(1, 200), (f[3] or ""):sub(1, 100)
    if not depart or not seed or map == "" or map:find("[^%w_/%.%-]") or door:find("[^%w_%-]") then
        net.log("Party: ignored a bad go message")
        return
    end
    accept({ map = map, door = door, seed = math.floor(seed), depart = depart, leader = peer }, party.level or "")
end

local function back_to_hub(why)
    if run then world.end_run(why) end
    run = nil
    share_seed(0)
    net.log("Party: " .. why)
    arrival_note = { text = why }
    party.travel(hub.level, nil)
end

local function on_back(peer, f)
    if run and tostring(run.seed) == f[2] and party.level ~= hub.level then
        back_pending = name_of(peer) .. " went back to the hub, so the party goes too"
    end
end

-- The hall's other version is swapped for the hub as it opens, with the state loaded on arrival.
local function hook_open_level()
    if level_hooked then return end
    local ok = pcall(RegisterHook, OPEN_LEVEL_HOOK, function(_, _, level_name)
        local ok_call, problem = pcall(function()
            if not net.in_session() then return end
            world.leaving_at = os.clock() -- this level's items are about to go, which is no pickup
            local name = level_name:get():ToString()
            if HALL_VERSIONS[name] then
                level_name:set(fname(hub.level))
                local gi = game_instance()
                if gi then
                    gi.LoadingThroughDoor = false
                    gi.LoadingFromSave = true
                end
                net.log("Party: " .. name .. " opens as the hub")
            end
        end)
        if not ok_call then net.log("Party hook error: " .. tostring(problem)) end
    end)
    level_hooked = ok
end

function party.init(session, hub_module, world_module, character_module)
    net, hub, world, character = session, hub_module, world_module, character_module
    net.on("msg:GO", on_go)
    net.on("msg:BACK", on_back)
    net.on("leave", function(peer)
        if run and run.leader == peer and party.level ~= hub.level and net.in_session() then
            back_pending = name_of(peer) .. " left, so the run is over"
        end
    end)
end

function party.in_run()
    return run ~= nil
end

function party.tick(seconds, level)
    party.level = level
    hook_open_level()
    local in_session = net.in_session()
    if in_session then
        was_in_session = true
        menu_at = nil
    elseif was_in_session then
        was_in_session = false
        pending = nil
        if run then world.end_run("the session ended") end
        run = nil
        share_seed(0)
        if level ~= "MenuMap" and not hub.leaving then
            say("The hub has closed. Back to the main menu.")
            menu_at = seconds + MENU_DELAY
        end
    end
    if menu_at and seconds >= menu_at then
        menu_at = nil
        if level ~= "MenuMap" then hub.go_menu() end
    end
    if arrival_note and level == hub.level and player() then
        arrival_note.at = arrival_note.at or seconds
        if seconds - arrival_note.at >= NOTE_AFTER_SECONDS then
            say(arrival_note.text)
            arrival_note = nil
        end
    end
    if not in_session then return end
    if back_pending then
        local why = back_pending
        back_pending = nil
        if run and level ~= hub.level then back_to_hub(why) end
        return
    end
    if pending and net.now() >= pending.depart then
        local go = pending
        pending = nil
        run = { seed = go.seed, map = go.map, leader = go.leader }
        world.begin_run(go.seed, go.map, go.leader, hub.level)
        share_seed(go.seed)
        net.log(string.format("Party: leaving for %s (door %s, seed %d)", go.map, go.door, go.seed))
        party.travel(go.map, go.door)
        return
    end
    if run and level == hub.level and run.left then
        -- Back in the hub after the run.
        if run.leader == net.self_id then net.send("*", 2, true, "BACK", run.seed) end
        world.end_run("back in the hub")
        run = nil
        share_seed(0)
    elseif run and level ~= hub.level and level ~= "MenuMap" then
        run.left = true
    end
end

return party
