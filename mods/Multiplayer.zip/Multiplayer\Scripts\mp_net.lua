-- Multiplayer Hub: the session wrapper over MPCore (the mod's C++ part in dlls\main.dll). It starts and ends hubs, pumps
-- MPCore's events once a frame, and sends and receives messages as text: "<type>|field|field...".
-- Channels: 0 control, 1 positions (unreliable), 2 chat and other reliable things.

local net = {
    peers = {},  -- id -> { id, name, rtt, host }
    state = "idle",
    role = "",
    self_id = "",
    self_name = "",
    hub = "",
}

local handlers = {}
local SEPARATOR = "|"
local last_refresh = 0

local function log(message)
    print("[Multiplayer] " .. tostring(message) .. "\n")
end
net.log = log

function net.available()
    return type(MPCore_Tick) == "function"
end

-- net.on("join"|"leave"|"state", fn) or net.on("msg:<type>", fn(peer, fields, channel))
function net.on(kind, fn)
    handlers[kind] = handlers[kind] or {}
    table.insert(handlers[kind], fn)
end

local function emit(kind, ...)
    for _, fn in ipairs(handlers[kind] or {}) do
        local ok, problem = pcall(fn, ...)
        if not ok then
            log("Error in a " .. kind .. " handler: " .. tostring(problem))
        end
    end
end

function net.host_udp(port, name, bind_ip)
    return MPCore_HostUdp(port, name, bind_ip or "127.0.0.1")
end

function net.join_udp(host_ip, host_port, local_port, name, bind_ip)
    return MPCore_JoinUdp(host_ip, host_port, local_port, name, bind_ip or "127.0.0.1")
end

function net.host_steam(max_members, hub_name)
    return MPCore_HostSteam(max_members or 8, hub_name or "Multiplayer Hub")
end

function net.join_steam(lobby)
    return MPCore_JoinSteam(tostring(lobby))
end

function net.leave()
    MPCore_Leave()
end

-- Fields are turned into text; "|" inside a field would split it, so callers keep it out (chat replaces it).
function net.send(target, channel, reliable, kind, ...)
    local parts = { kind, ... }
    for i = 2, #parts do
        parts[i] = tostring(parts[i])
    end
    return MPCore_Send(target or "*", channel, reliable and true or false, table.concat(parts, SEPARATOR))
end

local function split(text)
    local fields = {}
    for field in (text .. SEPARATOR):gmatch("(.-)|") do
        fields[#fields + 1] = field
    end
    return fields
end

function net.refresh_peers()
    for i = 1, MPCore_PeerCount() do
        local id, name, rtt, is_host = MPCore_Peer(i)
        local peer = id and net.peers[id]
        if peer then
            peer.name, peer.rtt, peer.host = name, rtt, is_host
        end
    end
end

function net.tick(seconds)
    MPCore_Tick()
    for _ = 1, 2000 do
        local kind, peer, channel, data = MPCore_Poll()
        if not kind then
            break
        end
        if kind == "msg" then
            local fields = split(data)
            emit("msg:" .. (fields[1] or ""), peer, fields, channel)
        elseif kind == "join" then
            net.peers[peer] = { id = peer, name = data, rtt = -1, host = false }
            log("Joined: " .. data .. " (" .. peer .. ")")
            emit("join", peer, data)
        elseif kind == "leave" then
            local who = net.peers[peer]
            net.peers[peer] = nil
            log("Left: " .. (who and who.name or peer))
            emit("leave", peer)
        elseif kind == "state" then
            net.state = data -- before the handlers run, so net.in_session() is current for them
            log("Session: " .. data)
            emit("state", data)
        end
    end
    net.state, net.role, net.self_id, net.self_name, net.hub = MPCore_State()
    if seconds - last_refresh > 1.0 then
        last_refresh = seconds
        net.refresh_peers()
    end
end

-- Seconds on the session clock (the host's), the same on every machine.
function net.now()
    return MPCore_Now() / 1000000.0
end

function net.in_session()
    return net.state == "hosting" or net.state == "joined"
end

function net.peer_count()
    local n = 0
    for _ in pairs(net.peers) do
        n = n + 1
    end
    return n
end

return net
