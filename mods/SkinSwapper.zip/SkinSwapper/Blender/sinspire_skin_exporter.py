"""Sin Spire Skin Exporter: checks a model made on the Sin Spire player rig and exports it for the Unreal 5.3 Skin Kit.

Install: Edit > Preferences > Add-ons > Install from Disk, pick this file, tick it.
Use: 3D View > Sidebar (N) > Sin Spire. Pick the armature, the body (optional; a body in several meshes: the person
icon on each), tick the pieces, press Check, then Export. The export folder holds skin.json, one .glb per piece, the textures as PNG and the rig (see FORMAT.md).

The add-on never changes the scene: everything is exported from temporary copies that are removed afterwards.
"""

bl_info = {
    "name": "Sin Spire Skin Exporter",
    "author": "Scott's Modding Cult",
    "version": (0, 3, 1),
    "blender": (4, 2, 0),
    "location": "3D View > Sidebar > Sin Spire",
    "description": "Check and export outfits and bodies made on the Sin Spire player rig for the Skin Kit",
    "category": "Import-Export",
}

import colorsys
import hashlib
import json
import os
import re
import subprocess

import bmesh
import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, IntProperty, PointerProperty, StringProperty
from mathutils import Matrix, Quaternion, Vector

FORMAT = 1

# The game's player body (SK_PlayerCharacter) bind pose: bone, parent, head in metres and rotation (w, x, y, z) in Blender
# armature space, the rig standing at the origin facing -Y, Z up. Numbers only. Used to check a rig, and the export rig's
# bones are set to exactly these, because clothes follow the game body's bones by their bind pose: a bone turned another
# way (Blender's importers turn every bone to point along its Y axis) would twist whatever it carries.
PLAYER_BONES = (
    ("root", None, (0.00000, 0.00000, 0.00000), (0.707107, 0.707107, 0.000000, 0.000000)),
    ("pelvis", "root", (0.00000, -0.01225, 0.98289), (0.499090, 0.500908, -0.500908, 0.499090)),
    ("penis_01", "pelvis", (0.00000, -0.11127, 0.89456), (0.707107, 0.707107, 0.000000, 0.000000)),
    ("penis_02", "penis_01", (0.00000, -0.15577, 0.89600), (0.699919, -0.714223, 0.000000, 0.000000)),
    ("penis_03", "penis_02", (0.00000, -0.18609, 0.89609), (0.699919, -0.714223, 0.000000, 0.000000)),
    ("penis_04", "penis_03", (0.00000, -0.21763, 0.89653), (0.699919, -0.714223, 0.000000, 0.000000)),
    ("penis_05", "penis_04", (0.00000, -0.24907, 0.89683), (0.699919, -0.714223, 0.000000, 0.000000)),
    ("penis_06", "penis_05", (0.00000, -0.28360, 0.89641), (0.699919, -0.714223, 0.000000, 0.000000)),
    ("penis_07", "penis_06", (0.00000, -0.31611, 0.89672), (0.699919, -0.714223, 0.000000, 0.000000)),
    ("spine_01", "pelvis", (0.00000, 0.00090, 1.05552), (0.466867, 0.531070, -0.531070, 0.466867)),
    ("spine_02", "spine_01", (0.00000, -0.00530, 1.13770), (0.528369, 0.469922, -0.469922, 0.528369)),
    ("spine_03", "spine_02", (0.00000, 0.00122, 1.21912), (0.539610, 0.456969, -0.456969, 0.539610)),
    ("clavicle_l", "spine_03", (0.04103, 0.04728, 1.46755), (0.717528, 0.696530, -0.000000, 0.000000)),
    ("upperarm_l", "clavicle_l", (0.18190, 0.05600, 1.46239), (0.655352, 0.622949, 0.305071, -0.298966)),
    ("lowerarm_l", "upperarm_l", (0.35278, 0.04934, 1.26083), (0.717725, 0.563599, 0.217396, -0.346362)),
    ("hand_l", "lowerarm_l", (0.54707, -0.02022, 1.06686), (0.915550, -0.066310, 0.393806, -0.047827)),
    ("index_01_l", "hand_l", (0.60645, -0.05746, 1.00721), (0.914643, -0.028856, 0.396124, -0.075372)),
    ("index_02_l", "index_01_l", (0.63305, -0.06501, 0.97609), (0.889955, -0.011715, 0.453247, -0.049095)),
    ("index_03_l", "index_02_l", (0.64657, -0.06828, 0.95860), (0.888108, -0.008536, 0.457557, -0.042818)),
    ("middle_01_l", "hand_l", (0.61155, -0.03468, 1.00468), (0.912137, -0.019817, 0.407394, -0.040529)),
    ("middle_02_l", "middle_01_l", (0.64346, -0.03848, 0.97100), (0.905593, -0.017068, 0.423743, -0.007160)),
    ("middle_03_l", "middle_02_l", (0.65851, -0.04125, 0.94865), (0.904649, 0.000420, 0.426142, 0.003561)),
    ("pinky_01_l", "hand_l", (0.60015, 0.00889, 1.00620), (0.924520, -0.041738, 0.375221, 0.052250)),
    ("pinky_02_l", "pinky_01_l", (0.62002, 0.01136, 0.98291), (0.924675, -0.038154, 0.375421, 0.050795)),
    ("pinky_03_l", "pinky_02_l", (0.63124, 0.01244, 0.96857), (0.870151, -0.040494, 0.488060, 0.054732)),
    ("ring_01_l", "hand_l", (0.60808, -0.01251, 1.00678), (0.896500, -0.034173, 0.440265, 0.035866)),
    ("ring_02_l", "ring_01_l", (0.63662, -0.01289, 0.97378), (0.896500, -0.034173, 0.440265, 0.035866)),
    ("ring_03_l", "ring_02_l", (0.65124, -0.01321, 0.95469), (0.885694, -0.035023, 0.461619, 0.035037)),
    ("thumb_01_l", "hand_l", (0.55256, -0.03785, 1.04967), (0.779547, 0.229687, 0.236680, -0.532478)),
    ("thumb_02_l", "thumb_01_l", (0.56182, -0.07363, 1.02536), (0.747198, 0.310296, 0.308831, -0.500034)),
    ("thumb_03_l", "thumb_02_l", (0.57080, -0.09356, 1.00089), (0.713947, 0.349708, 0.357166, -0.490322)),
    ("weaponbone_l", "hand_l", (0.54707, -0.02022, 1.06686), (0.066310, 0.915550, -0.047827, -0.393806)),
    ("lowerarm_twist_01_l", "lowerarm_l", (0.44329, 0.01633, 1.17110), (0.717725, 0.563599, 0.217396, -0.346362)),
    ("upperarm_twist_01_l", "upperarm_l", (0.26560, 0.05330, 1.36792), (0.655352, 0.622949, 0.305071, -0.298966)),
    ("clavicle_r", "spine_03", (-0.04103, 0.04728, 1.46756), (0.696530, -0.717528, -0.000000, 0.000000)),
    ("upperarm_r", "clavicle_r", (-0.18190, 0.05600, 1.46239), (0.622949, -0.655352, -0.298966, -0.305071)),
    ("lowerarm_r", "upperarm_r", (-0.35278, 0.04934, 1.26083), (0.563599, -0.717725, -0.346362, -0.217396)),
    ("hand_r", "lowerarm_r", (-0.54707, -0.02022, 1.06686), (0.066310, 0.915550, 0.047827, 0.393806)),
    ("index_01_r", "hand_r", (-0.60645, -0.05746, 1.00721), (0.028856, 0.914643, 0.075372, 0.396124)),
    ("index_02_r", "index_01_r", (-0.63305, -0.06501, 0.97609), (0.011715, 0.889955, 0.049095, 0.453247)),
    ("index_03_r", "index_02_r", (-0.64657, -0.06828, 0.95860), (0.008536, 0.888108, 0.042818, 0.457557)),
    ("middle_01_r", "hand_r", (-0.61154, -0.03468, 1.00468), (0.019817, 0.912137, 0.040529, 0.407394)),
    ("middle_02_r", "middle_01_r", (-0.64346, -0.03848, 0.97100), (0.017068, 0.905593, 0.007160, 0.423743)),
    ("middle_03_r", "middle_02_r", (-0.65851, -0.04125, 0.94864), (-0.000420, 0.904649, -0.003561, 0.426142)),
    ("pinky_01_r", "hand_r", (-0.60015, 0.00889, 1.00620), (0.041738, 0.924520, -0.052250, 0.375221)),
    ("pinky_02_r", "pinky_01_r", (-0.62002, 0.01136, 0.98291), (0.038154, 0.924675, -0.050795, 0.375421)),
    ("pinky_03_r", "pinky_02_r", (-0.63124, 0.01244, 0.96857), (0.040494, 0.870151, -0.054732, 0.488060)),
    ("ring_01_r", "hand_r", (-0.60808, -0.01251, 1.00678), (0.034173, 0.896500, -0.035866, 0.440265)),
    ("ring_02_r", "ring_01_r", (-0.63662, -0.01289, 0.97378), (0.034173, 0.896500, -0.035866, 0.440265)),
    ("ring_03_r", "ring_02_r", (-0.65124, -0.01321, 0.95469), (0.035023, 0.885694, -0.035037, 0.461619)),
    ("thumb_01_r", "hand_r", (-0.55256, -0.03785, 1.04967), (-0.229687, 0.779547, 0.532478, 0.236680)),
    ("thumb_02_r", "thumb_01_r", (-0.56182, -0.07363, 1.02536), (-0.310296, 0.747198, 0.500034, 0.308831)),
    ("thumb_03_r", "thumb_02_r", (-0.57080, -0.09356, 1.00089), (-0.349708, 0.713947, 0.490322, 0.357166)),
    ("weaponbone_r", "hand_r", (-0.54707, -0.02022, 1.06686), (0.066310, 0.915550, 0.047827, 0.393806)),
    ("lowerarm_twist_01_r", "lowerarm_r", (-0.44330, 0.01633, 1.17110), (0.563599, -0.717725, -0.346362, -0.217396)),
    ("upperarm_twist_01_r", "upperarm_r", (-0.26560, 0.05330, 1.36792), (0.622949, -0.655352, -0.298966, -0.305071)),
    ("neck_01", "spine_03", (0.00000, 0.04417, 1.54526), (0.435206, 0.557311, -0.557311, 0.435206)),
    ("head", "neck_01", (0.00000, 0.01842, 1.63188), (0.505732, 0.494201, -0.494201, 0.505732)),
    ("cameralocator", "head", (-0.00000, -0.09998, 1.70230), (0.000000, 0.000000, 0.999934, -0.011531)),
    ("testicles", "pelvis", (0.00000, -0.10204, 0.87935), (0.707107, 0.707107, 0.000000, 0.000000)),
    ("thigh_l", "pelvis", (0.07791, -0.00558, 0.96599), (0.450182, 0.476195, -0.520932, 0.546996)),
    ("calf_l", "thigh_l", (0.14144, 0.01676, 0.50904), (-0.415237, -0.517606, 0.548745, -0.508469)),
    ("foot_l", "calf_l", (0.19354, 0.04476, 0.08418), (0.398669, 0.520085, -0.461740, 0.597805)),
    ("ball_l", "foot_l", (0.22468, -0.03382, 0.01092), (-0.044593, 0.790520, -0.608333, 0.054961)),
    ("thigh_twist_01_l", "thigh_l", (0.10691, -0.00557, 0.75906), (0.450182, 0.476195, -0.520932, 0.546996)),
    ("thigh_r", "pelvis", (-0.07791, -0.00558, 0.96599), (0.476195, -0.450182, 0.546996, 0.520932)),
    ("calf_r", "thigh_r", (-0.14144, 0.01676, 0.50904), (0.517606, -0.415237, 0.508469, 0.548745)),
    ("foot_r", "calf_r", (-0.19354, 0.04476, 0.08418), (0.520085, -0.398669, 0.597805, 0.461740)),
    ("ball_r", "foot_r", (-0.22468, -0.03382, 0.01092), (0.790520, 0.044593, 0.054961, 0.608333)),
    ("thigh_twist_01_r", "thigh_r", (-0.10691, -0.00557, 0.75906), (0.476195, -0.450182, 0.546996, 0.520932)),
)

TARGETS = {"player": {"label": "Player", "bones": PLAYER_BONES, "rig_mesh": "SK_Player", "body_tris": 2298}}

REST_TOLERANCE_M = 0.002  # a bone further than this from the game's rest pose is an error
MAX_INFLUENCES = 4  # bones per vertex that reach the game; the rest are dropped and the weights renormalised
PIECE_TRIS_WARN = 20000
TOTAL_TRIS_WARN = 60000
TOTAL_TRIS_ERROR = 300000
PLACEHOLDER_SIZE = 64
TEMP_COLLECTION = "SinSpireSkinExport_tmp"

ID_PATTERN = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,39}$")


# ----------------------------------------------------------------------------------------------------------- helpers

def clean_name(text, fallback="Piece"):
    """Letters, digits and _ only, starting with a letter, and never _<digits> at the end: Unreal would read that as a
    name number (Belt_2 becomes Belt + 2) and the game could not find the asset by name."""
    name = re.sub(r"[^A-Za-z0-9]+", "_", text or "").strip("_")
    name = re.sub(r"_+(\d+)$", r"\1", name)
    if not name:
        name = fallback
    if not name[0].isalpha():
        name = fallback + name
    return name[:40]


def deform_armature(obj):
    """The armature that deforms a mesh object, through its Armature modifier or an armature parent."""
    for mod in obj.modifiers:
        if mod.type == "ARMATURE" and mod.object is not None:
            return mod.object
    if obj.parent is not None and obj.parent.type == "ARMATURE" and obj.parent_type == "ARMATURE":
        return obj.parent
    return None


def skinned_meshes(scene, armature):
    if armature is None:
        return []
    return [o for o in scene.objects if o.type == "MESH" and deform_armature(o) == armature]


def body_parts(scene, settings):
    """The meshes that make up the body: the Body object plus every mesh on the rig marked as a body part. A body made
    of several meshes (head, torso, hands...) is exported joined, as one body."""
    parts = []
    body = settings.body_object
    if body is not None and body.type == "MESH" and body.name in scene.objects:
        parts.append(body)
    for obj in skinned_meshes(scene, settings.armature):
        if obj.sinspire_piece.is_body and obj not in parts:
            parts.append(obj)
    return parts


def is_body_part(obj, settings):
    return obj == settings.body_object or obj.sinspire_piece.is_body


def pieces_of(scene, settings):
    # Body parts are never pieces, whatever the body mode: as pieces they would hang a second body on the player.
    return [o for o in skinned_meshes(scene, settings.armature)
            if not is_body_part(o, settings) and o.sinspire_piece.include]


def auto_armature(scene):
    names = {b[0] for b in PLAYER_BONES}
    best, score = None, 0
    for obj in scene.objects:
        if obj.type == "ARMATURE":
            hits = sum(1 for b in obj.data.bones if b.name in names)
            if hits > score:
                best, score = obj, hits
    return best


def linear_to_srgb(c):
    c = max(0.0, min(1.0, c))
    return c * 12.92 if c <= 0.0031308 else 1.055 * (c ** (1 / 2.4)) - 0.055


# --------------------------------------------------------------------------------------------------- material reading

def principled_of(material):
    tree = material.node_tree if material else None
    if tree is None:
        return None
    for node in tree.nodes:
        if node.type == "OUTPUT_MATERIAL" and node.is_active_output and node.inputs["Surface"].is_linked:
            found = _find_upstream(node.inputs["Surface"], {"BSDF_PRINCIPLED"}, set())
            if found:
                return found
    for node in tree.nodes:
        if node.type == "BSDF_PRINCIPLED":
            return node
    return None


def _find_upstream(socket, types, seen):
    for link in socket.links:
        node = link.from_node
        if node in seen:
            continue
        seen.add(node)
        if node.type in types:
            return node
        for inp in node.inputs:
            if inp.is_linked:
                found = _find_upstream(inp, types, seen)
                if found:
                    return found
    return None


def _all_upstream(socket, types):
    found, seen, stack = [], set(), [socket]
    while stack:
        current = stack.pop()
        for link in current.links:
            node = link.from_node
            if node in seen:
                continue
            seen.add(node)
            if node.type in types:
                found.append(node)
            stack.extend(i for i in node.inputs if i.is_linked)
    return found


def _colour_score(image):
    """How much an image looks like a colour map rather than a data map (an albedo multiplied by its AO, say)."""
    name = (bpy.path.basename(image.filepath) + " " + image.name).lower()
    score = 0
    for word in ("albedo", "basecolor", "base_color", "diffuse", "color", "colour", "_col", "_d."):
        if word in name:
            score += 2
    for word in ("orm", "_ao", "occlusion", "rough", "metal", "normal", "_nrm", "mask", "height", "spec"):
        if word in name:
            score -= 3
    if image.colorspace_settings.name in ("Non-Color", "Linear", "Raw"):
        score -= 2
    return score


def image_feeding(socket):
    """(image node, channel) feeding a socket through colour/math nodes; channel is R, G, B or None for the colour."""
    if socket is None or not socket.is_linked:
        return None, None
    link = socket.links[0]
    node = link.from_node
    channel = None
    if node.type in {"SEPARATE_COLOR", "SEPRGB", "SEPARATE_RGB"}:
        channel = {"Red": "R", "R": "R", "Green": "G", "G": "G", "Blue": "B", "B": "B"}.get(link.from_socket.name)
    if node.type == "TEX_IMAGE":
        return node, None
    if node.type == "NORMAL_MAP":
        return image_feeding(node.inputs.get("Color"))
    found = _find_upstream(socket, {"TEX_IMAGE"}, set())
    return found, channel


def read_material(material):
    """What a material's surface uses: base colour image or colour, normal, roughness and metallic images."""
    info = {"material": material, "base_image": None, "base_color": (0.8, 0.8, 0.8, 1.0), "normal_image": None,
            "roughness_image": None, "roughness_channel": None, "metallic_image": None, "metallic_channel": None}
    if material is None:
        return info
    info["base_color"] = tuple(material.diffuse_color)
    bsdf = principled_of(material)
    if bsdf is None:
        return info
    base = bsdf.inputs.get("Base Color")
    if base is not None:
        candidates = [n for n in _all_upstream(base, {"TEX_IMAGE"}) if n.image is not None]
        if candidates:
            info["base_image"] = max(candidates, key=lambda n: _colour_score(n.image)).image
        else:
            info["base_color"] = tuple(base.default_value)
    node, _ = image_feeding(bsdf.inputs.get("Normal"))
    info["normal_image"] = node.image if node is not None else None
    node, channel = image_feeding(bsdf.inputs.get("Roughness"))
    info["roughness_image"], info["roughness_channel"] = (node.image if node else None), channel
    node, channel = image_feeding(bsdf.inputs.get("Metallic"))
    info["metallic_image"], info["metallic_channel"] = (node.image if node else None), channel
    return info


def image_missing(image):
    if image is None:
        return True
    if image.packed_file is not None or image.source == "GENERATED":
        return False
    try:
        return image.size[0] == 0 or image.size[1] == 0
    except Exception:
        return True


# ------------------------------------------------------------------------------------------------- mesh evaluation

def evaluated_copy(context, obj, subdivision):
    """A new mesh datablock: the object with its modifiers applied (Subdivision capped, Armature left out), in world
    space, rest pose. The caller removes it."""
    saved = []
    try:
        for mod in obj.modifiers:
            if mod.type == "ARMATURE":
                saved.append((mod, "show_viewport", mod.show_viewport))
                mod.show_viewport = False
            elif mod.type == "SUBSURF":
                saved.append((mod, "levels", mod.levels))
                mod.levels = min(mod.levels, subdivision)
        context.view_layer.update()
        depsgraph = context.evaluated_depsgraph_get()
        evaluated = obj.evaluated_get(depsgraph)
        mesh = bpy.data.meshes.new_from_object(evaluated, preserve_all_data_layers=True, depsgraph=depsgraph)
    finally:
        for mod, attribute, value in saved:
            setattr(mod, attribute, value)
        context.view_layer.update()
    mesh.transform(obj.matrix_world)
    if obj.matrix_world.determinant() < 0:
        mesh.flip_normals()
    return mesh


def weight_stats(obj, mesh, bone_names):
    names = [g.name for g in obj.vertex_groups]
    deform = {i for i, n in enumerate(names) if n in bone_names}
    unweighted = over = 0
    for v in mesh.vertices:
        count = sum(1 for g in v.groups if g.group in deform and g.weight > 1e-4)
        if count == 0:
            unweighted += 1
        elif count > MAX_INFLUENCES:
            over += 1
    return unweighted, over


def open_edges(*meshes):
    """Edges with only one face: holes, such as a body cut away under its clothes. Seams are not holes here, nor are
    the joins between body parts that meet edge to edge (their vertices are merged first)."""
    bm = bmesh.new()
    try:
        for mesh in meshes:
            bm.from_mesh(mesh)
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)
        return sum(1 for edge in bm.edges if edge.is_boundary)
    finally:
        bm.free()


def triangles(mesh):
    return sum(len(p.vertices) - 2 for p in mesh.polygons)


# ------------------------------------------------------------------------------------------------------------ checks

class Report:
    def __init__(self):
        self.lines = []

    def add(self, level, text):
        self.lines.append((level, text))

    def error(self, text):
        self.add("ERROR", text)

    def warn(self, text):
        self.add("WARNING", text)

    def info(self, text):
        self.add("INFO", text)

    @property
    def errors(self):
        return [t for lvl, t in self.lines if lvl == "ERROR"]


def check_rig(armature, target, report):
    bones = TARGETS[target]["bones"]
    wanted = {name: (parent, Vector(head)) for name, parent, head, _ in bones}
    have = {b.name: b for b in armature.data.bones}
    missing = [n for n in wanted if n not in have]
    extra = [n for n in have if n not in wanted]
    if missing:
        report.error(f"Rig is missing {len(missing)} game bones: {', '.join(missing[:8])}{'...' if len(missing) > 8 else ''}")
    if extra:
        report.warn(f"Rig has {len(extra)} bones the game does not have; they are dropped and anything weighted to "
                    f"them will not move: {', '.join(extra[:8])}")
    world = armature.matrix_world
    worst, worst_name, wrong_parent = 0.0, None, []
    for name, (parent, head) in wanted.items():
        bone = have.get(name)
        if bone is None:
            continue
        if (bone.parent.name if bone.parent else None) != parent:
            wrong_parent.append(name)
        offset = ((world @ bone.head_local) - head).length
        if offset > worst:
            worst, worst_name = offset, name
    if wrong_parent:
        report.error(f"Bones with a different parent than in the game: {', '.join(wrong_parent[:8])}")
    if worst > REST_TOLERANCE_M:
        report.error(f"Rest pose differs from the game's: {worst_name} is {worst * 100:.1f} cm away. Keep the rig's "
                     f"rest pose as it came from the game (pose the model, not the rest pose).")
    elif not missing:
        report.info(f"Rig matches the game's player skeleton ({len(wanted)} bones, rest pose within "
                    f"{REST_TOLERANCE_M * 1000:.0f} mm).")


def check_material_textures(obj, report, allow_missing, label):
    for slot_index, slot in enumerate(obj.material_slots):
        material = slot.material
        if material is None:
            report.error(f"{label}: material slot {slot_index + 1} is empty.")
            continue
        info = read_material(material)
        image = info["base_image"]
        if image is not None and image_missing(image):
            text = (f"{label}: texture '{image.name}' of material '{material.name}' is not packed and not found at "
                    f"{bpy.path.abspath(image.filepath)}. Pack it (File > External Data > Pack Resources) or relink it.")
            if allow_missing:
                report.warn(text + " A stand-in checker is exported.")
            else:
                report.error(text)
    if not obj.material_slots:
        report.error(f"{label}: has no material.")


def run_checks(context, settings, measure=True):
    """Checks everything the export needs. With measure, also evaluates every piece for triangle and weight counts."""
    report = Report()
    scene = context.scene
    target = settings.target
    armature = settings.armature
    if not ID_PATTERN.match(settings.skin_id or ""):
        report.error("Skin name must start with a letter and use only letters, digits and _ (max 40).")
    if armature is None or armature.type != "ARMATURE":
        report.error("Pick the armature (the game's player rig).")
        return report
    check_rig(armature, target, report)
    bone_names = {b[0] for b in TARGETS[target]["bones"]}

    parts = body_parts(scene, settings)
    if settings.body_mode in {"texture", "mesh"}:
        if not parts:
            report.error("Body is set to use your texture or mesh: pick the body object, or mark the body parts "
                         "(person icon in the Meshes list).")
        for part in parts:
            if settings.body_mode == "mesh" and deform_armature(part) != armature:
                report.error(f"Body part '{part.name}' is not deformed by '{armature.name}' (needs an Armature "
                             f"modifier).")
            if settings.body_mode == "mesh" or part == parts[0]:
                check_material_textures(part, report, settings.allow_missing, f"Body part '{part.name}'")
        if settings.body_mode == "texture" and parts and (len(parts) > 1 or len(parts[0].material_slots) > 1):
            report.warn(f"'Game body, my texture' uses only the base colour texture of '{parts[0].name}' (its first "
                        f"material). For a body of several meshes or materials, use 'My body mesh'.")
        if settings.body_mode == "mesh" and len(parts) > 1:
            report.info(f"Body: {len(parts)} meshes, joined into one on export ({', '.join(p.name for p in parts[:5])}"
                        f"{'...' if len(parts) > 5 else ''}).")

    pieces = pieces_of(scene, settings)
    if not pieces and settings.body_mode == "none":
        report.error("Nothing to export: tick at least one piece or set the body.")
    names = {}
    for obj in pieces:
        name = clean_name(obj.name)
        if name.lower() == "body":
            name = "BodyPiece"
        if name in names:
            report.error(f"'{obj.name}' and '{names[name]}' both become '{name}'; rename one.")
        names[name] = obj.name
        check_material_textures(obj, report, settings.allow_missing, f"'{obj.name}'")
        if any(k for k in ([obj.data.shape_keys] if obj.data.shape_keys else [])):
            report.warn(f"'{obj.name}': shape keys are not exported (the base shape is).")

    if not measure:
        return report
    total = 0
    measured = list(pieces)
    body_meshes = []
    if settings.body_mode == "mesh":
        measured.extend(o for o in parts if o.type == "MESH")
    try:
        for obj in measured:
            mesh = evaluated_copy(context, obj, settings.subdivision)
            if obj in parts:
                body_meshes.append(mesh)  # the holes are counted on the whole body, below
            try:
                tris = triangles(mesh)
                unweighted, over = weight_stats(obj, mesh, bone_names)
            finally:
                if obj not in parts:
                    bpy.data.meshes.remove(mesh)
            obj.sinspire_piece.triangles = tris
            total += tris
            if tris == 0:
                report.error(f"'{obj.name}' has no faces after its modifiers (is it hidden or disabled in the "
                             f"viewport?).")
            if unweighted:
                report.error(f"'{obj.name}': {unweighted} vertices have no weight on any game bone; they would stay "
                             f"at the feet. Weight them (Weight Paint) or remove them.")
            if over:
                report.warn(f"'{obj.name}': {over} vertices use more than {MAX_INFLUENCES} bones; the game keeps the "
                            f"{MAX_INFLUENCES} strongest.")
            if tris > PIECE_TRIS_WARN:
                report.warn(f"'{obj.name}': {tris:,} triangles. The game's whole body is "
                            f"{TARGETS[target]['body_tris']:,}; try a lower Subdivision or a decimated copy.")
        holes = open_edges(*body_meshes) if body_meshes else 0
    finally:
        for mesh in body_meshes:
            bpy.data.meshes.remove(mesh)
    off = [p.name for p in pieces if not p.sinspire_piece.in_scenes]
    if holes and off:
        report.warn(f"The body has {holes} open edges (cut away under the clothes, or parts that do not meet?). In "
                    f"sex scenes, where {', '.join(off[:4])}{'...' if len(off) > 4 else ''} come off, the game's own "
                    f"full body is shown instead, with your body texture. To avoid that, keep the body whole, or use "
                    f"'Game body, my texture'.")
    report.info(f"{len(pieces)} pieces, {total:,} triangles at subdivision {settings.subdivision}.")
    if total > TOTAL_TRIS_ERROR:
        report.error(f"{total:,} triangles in total is far too heavy for the game (limit {TOTAL_TRIS_ERROR:,}).")
    elif total > TOTAL_TRIS_WARN:
        report.warn(f"{total:,} triangles in total; aim for under {TOTAL_TRIS_WARN:,}.")
    return report


# ------------------------------------------------------------------------------------------------------------ export

def export_options(**wanted):
    """Only the glTF exporter options this Blender version knows."""
    known = set(bpy.ops.export_scene.gltf.get_rna_type().properties.keys())
    return {k: v for k, v in wanted.items() if k in known}


def export_glb(context, path, objects):
    for obj in context.view_layer.objects:
        obj.select_set(False)
    for obj in objects:
        obj.select_set(True)
    context.view_layer.objects.active = objects[-1]
    options = export_options(
        filepath=path, export_format="GLB", use_selection=True, export_apply=False, export_yup=True,
        export_skins=True, export_def_bones=False, export_all_influences=False, export_rest_position_armature=True,
        export_armature_object_remove=True, export_hierarchy_flatten_bones=False, export_leaf_bone=False,
        export_animations=False, export_morph=False, export_materials="EXPORT", export_image_format="NONE",
        export_cameras=False, export_lights=False, export_extras=False, export_texcoords=True, export_normals=True,
        export_tangents=False, export_attributes=False, will_save_settings=False)
    result = bpy.ops.export_scene.gltf(**options)
    if "FINISHED" not in result or not os.path.exists(path):
        raise RuntimeError(f"glTF export failed for {path}")


def make_export_rig(context, armature, collection, target):
    rig = armature.copy()
    rig.data = armature.data.copy()
    rig.animation_data_clear()
    rig.data.animation_data_clear() if rig.data.animation_data else None
    collection.objects.link(rig)
    rig.parent = None
    rig.matrix_world = armature.matrix_world.copy()
    for bone in rig.pose.bones:
        for constraint in list(bone.constraints):
            bone.constraints.remove(constraint)
        bone.location = (0, 0, 0)
        bone.rotation_quaternion = (1, 0, 0, 0)
        bone.rotation_euler = (0, 0, 0)
        bone.scale = (1, 1, 1)
    rig.data.pose_position = "REST"
    rig.name = "SinSpireExportRig"
    rig.hide_set(False)
    rig.hide_viewport = False
    with context.temp_override(active_object=rig, object=rig, selected_objects=[rig], selected_editable_objects=[rig]):
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    set_game_bind_pose(context, rig, target)
    return rig


def set_game_bind_pose(context, rig, target):
    """Turns every bone of the (temporary) export rig to the game's bind pose. The meshes are bound at rest, so they do
    not move; only the bind frames written to the glb change, to the ones the game's body uses."""
    table = {name: (Vector(head), Quaternion(rotation)) for name, _, head, rotation in TARGETS[target]["bones"]}
    # mode_set works on the view layer's active object (a context override does not change that).
    if context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    context.view_layer.objects.active = rig
    rig.select_set(True)
    bpy.ops.object.mode_set(mode="EDIT")
    if context.mode != "EDIT_ARMATURE":
        raise RuntimeError(f"Could not edit the export rig (mode {context.mode})")
    try:
        bones = rig.data.edit_bones
        for bone in bones:
            bone.use_connect = False
        for bone in bones:
            entry = table.get(bone.name)
            if entry is None:
                continue
            length = max(bone.length, 0.005)
            bone.matrix = Matrix.LocRotScale(entry[0], entry[1], None)
            bone.length = length
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")


def make_export_mesh(context, obj, name, rig, collection, subdivision):
    mesh = evaluated_copy(context, obj, subdivision)
    mesh.name = name
    new = bpy.data.objects.new(name, mesh)
    collection.objects.link(new)
    # Vertex group names live on the mesh since Blender 3.0; older data may need them made on the object.
    if len(new.vertex_groups) == 0:
        for group in obj.vertex_groups:
            new.vertex_groups.new(name=group.name)
    new.parent = rig
    modifier = new.modifiers.new("Armature", "ARMATURE")
    modifier.object = rig
    return new


def join_meshes(context, objects, name):
    """Joins temporary export meshes into the first one (vertex groups matched by name, materials merged)."""
    first = objects[0]
    if len(objects) > 1:
        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        for obj in context.view_layer.objects:
            obj.select_set(False)
        for obj in objects:
            obj.select_set(True)
        context.view_layer.objects.active = first
        with context.temp_override(active_object=first, object=first, selected_objects=objects,
                                   selected_editable_objects=objects):
            result = bpy.ops.object.join()
        if "FINISHED" not in result:
            raise RuntimeError("Could not join the body parts")
    first.name = name
    first.data.name = name
    return first


def write_png(pixels, width, height, path):
    image = bpy.data.images.new("SinSpireSkinExport_tmp_image", width, height, alpha=True)
    try:
        image.pixels.foreach_set(pixels)
        image.filepath_raw = path
        image.file_format = "PNG"
        image.save()
    finally:
        bpy.data.images.remove(image)


def copy_image(image, path, max_size):
    width, height = image.size
    temp = bpy.data.images.new("SinSpireSkinExport_tmp_copy", width, height, alpha=True)
    try:
        pixels = [0.0] * (width * height * 4)
        image.pixels.foreach_get(pixels)
        temp.pixels.foreach_set(pixels)
        if max(width, height) > max_size:
            scale = max_size / max(width, height)
            temp.scale(max(1, int(width * scale)), max(1, int(height * scale)))
        temp.filepath_raw = path
        temp.file_format = "PNG"
        temp.save()
    finally:
        bpy.data.images.remove(temp)


def flat_png(color, path):
    rgba = [linear_to_srgb(color[0]), linear_to_srgb(color[1]), linear_to_srgb(color[2]), color[3] if len(color) > 3 else 1.0]
    write_png(rgba * 16, 4, 4, path)


def checker_png(seed, path):
    digest = hashlib.md5(seed.encode()).digest()
    r, g, b = colorsys.hsv_to_rgb(digest[0] / 255.0, 0.65, 0.95)
    dark = (r * 0.35, g * 0.35, b * 0.35)
    pixels = []
    for y in range(PLACEHOLDER_SIZE):
        for x in range(PLACEHOLDER_SIZE):
            c = (r, g, b) if ((x // 8) + (y // 8)) % 2 == 0 else dark
            pixels.extend((c[0], c[1], c[2], 1.0))
    write_png(pixels, PLACEHOLDER_SIZE, PLACEHOLDER_SIZE, path)


class TextureWriter:
    """Writes each image once into textures\\ and remembers the file it became."""

    def __init__(self, folder, max_size, allow_missing):
        self.folder = folder
        self.max_size = max_size
        self.allow_missing = allow_missing
        self.done = {}
        self.used = set()

    def _file(self, stem):
        base = clean_name(stem, "Tex")
        name = base
        n = 1
        while name.lower() in self.used:
            n += 1
            name = f"{base}v{n}"
        self.used.add(name.lower())
        return name + ".png"

    def image(self, image, seed):
        """Returns (relative path, placeholder) for an image, or (None, False) when there is none."""
        if image is None:
            return None, False
        key = ("image", image.name)
        if key in self.done:
            return self.done[key]
        stem = os.path.splitext(bpy.path.basename(image.filepath) or image.name)[0] or image.name
        filename = self._file(stem)
        path = os.path.join(self.folder, filename)
        if image_missing(image):
            if not self.allow_missing:
                raise RuntimeError(f"Texture {image.name} is missing")
            checker_png(seed, path)
            result = ("textures/" + filename, True)
        else:
            copy_image(image, path, self.max_size)
            result = ("textures/" + filename, False)
        self.done[key] = result
        return result

    def color(self, color, seed):
        key = ("color", tuple(round(c, 4) for c in color))
        if key in self.done:
            return self.done[key]
        filename = self._file(seed + "_color")
        flat_png(color, os.path.join(self.folder, filename))
        self.done[key] = ("textures/" + filename, False)
        return self.done[key]


def material_entry(material, writer):
    info = read_material(material)
    seed = material.name if material else "none"
    if info["base_image"] is not None:
        base, placeholder = writer.image(info["base_image"], seed)
    else:
        base, placeholder = writer.color(info["base_color"], seed)
    entry = {"slot": material.name if material else "None", "base_color": base, "placeholder": placeholder}
    for kind in ("normal", "roughness", "metallic"):
        image = info[f"{kind}_image"]
        path = None
        if image is not None and not image_missing(image):
            path, _ = writer.image(image, seed + kind)
        entry[kind] = path
    if entry["normal"]:
        lowered = (info["normal_image"].filepath + info["normal_image"].name).lower()
        entry["normal_directx"] = "directx" in lowered or "_dx" in lowered
    entry["roughness_channel"] = info["roughness_channel"]
    entry["metallic_channel"] = info["metallic_channel"]
    return entry


def export_skin(context, settings):
    """Exports the skin. Returns (report, folder). Raises nothing for check failures: they are in the report."""
    report = run_checks(context, settings, measure=True)
    if report.errors:
        return report, None
    if context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    target = settings.target
    root = bpy.path.abspath(settings.output_dir or "//SinSpireSkins")
    folder = os.path.join(root, settings.skin_id)
    for sub in ("meshes", "textures", "rig"):
        os.makedirs(os.path.join(folder, sub), exist_ok=True)
    for sub in ("meshes", "textures", "rig"):
        for old in os.listdir(os.path.join(folder, sub)):
            if old.lower().endswith((".glb", ".png")):
                os.remove(os.path.join(folder, sub, old))

    scene = context.scene
    collection = bpy.data.collections.new(TEMP_COLLECTION)
    scene.collection.children.link(collection)
    created = []
    writer = TextureWriter(os.path.join(folder, "textures"), int(settings.texture_size), settings.allow_missing)
    manifest = {"format": FORMAT, "id": settings.skin_id, "title": settings.title or settings.skin_id,
                "author": settings.author, "target": target, "exporter": ".".join(map(str, bl_info["version"])),
                "blender": bpy.app.version_string, "body": {"mode": settings.body_mode}, "pieces": []}
    selection = [o for o in context.view_layer.objects if o.select_get()]
    active = context.view_layer.objects.active
    try:
        rig = make_export_rig(context, settings.armature, collection, target)
        created.append(rig)

        # The rig with a one-triangle mesh: the Unreal kit makes its stand-in player skeleton from it.
        stub_mesh = bpy.data.meshes.new(TARGETS[target]["rig_mesh"])
        pelvis = rig.data.bones["pelvis"].head_local
        stub_mesh.from_pydata([pelvis + Vector((0, 0, 0.01)), pelvis + Vector((0.01, 0, 0)), pelvis + Vector((0, 0.01, 0))],
                              [], [(0, 1, 2)])
        stub = bpy.data.objects.new(TARGETS[target]["rig_mesh"], stub_mesh)
        collection.objects.link(stub)
        group = stub.vertex_groups.new(name="pelvis")
        group.add([0, 1, 2], 1.0, "REPLACE")
        stub.parent = rig
        stub.modifiers.new("Armature", "ARMATURE").object = rig
        created.append(stub)
        export_glb(context, os.path.join(folder, "rig", TARGETS[target]["rig_mesh"] + ".glb"), [rig, stub])

        parts = body_parts(scene, settings)
        if settings.body_mode == "texture":
            manifest["body"]["materials"] = [material_entry(parts[0].material_slots[0].material, writer)]
            manifest["body"]["sources"] = [parts[0].name]
        elif settings.body_mode == "mesh":
            copies = []
            for index, part in enumerate(parts):
                copy = make_export_mesh(context, part, "Body" if index == 0 else f"BodyPart{index}", rig, collection,
                                        settings.subdivision)
                created.append(copy)
                copies.append(copy)
            new = join_meshes(context, copies, "Body")
            for gone in copies[1:]:
                created.remove(gone)  # join removed them
            export_glb(context, os.path.join(folder, "meshes", "Body.glb"), [rig, new])
            manifest["body"]["mesh"] = "meshes/Body.glb"
            manifest["body"]["sources"] = [p.name for p in parts]
            manifest["body"]["triangles"] = triangles(new.data)
            manifest["body"]["open_edges"] = open_edges(new.data)
            manifest["body"]["materials"] = [material_entry(s.material, writer) for s in new.material_slots]

        for obj in pieces_of(scene, settings):
            name = clean_name(obj.name)
            if name.lower() == "body":
                name = "BodyPiece"
            new = make_export_mesh(context, obj, name, rig, collection, settings.subdivision)
            created.append(new)
            path = os.path.join(folder, "meshes", name + ".glb")
            export_glb(context, path, [rig, new])
            manifest["pieces"].append({
                "name": name, "source": obj.name, "mesh": f"meshes/{name}.glb",
                "first_person": obj.sinspire_piece.first_person, "in_scenes": obj.sinspire_piece.in_scenes,
                "triangles": triangles(new.data),
                "materials": [material_entry(s.material, writer) for s in obj.material_slots],
            })
            report.info(f"Exported {name} ({manifest['pieces'][-1]['triangles']:,} triangles)")
    finally:
        for obj in reversed(created):
            data = obj.data
            bpy.data.objects.remove(obj)
            if isinstance(data, bpy.types.Mesh) and data.users == 0:
                bpy.data.meshes.remove(data)
            elif isinstance(data, bpy.types.Armature) and data.users == 0:
                bpy.data.armatures.remove(data)
        bpy.data.collections.remove(collection)
        context.view_layer.update()
        keep = {o.name for o in selection}
        for obj in context.view_layer.objects:
            if obj is not None:
                obj.select_set(obj.name in keep)
        if active is not None and active.name in context.view_layer.objects:
            context.view_layer.objects.active = active

    placeholders = sorted({m["base_color"] for p in manifest["pieces"] for m in p["materials"] if m["placeholder"]} |
                          {m["base_color"] for m in manifest["body"].get("materials", []) if m["placeholder"]})
    if placeholders:
        report.warn(f"{len(placeholders)} textures were missing and exported as stand-in checkers.")
    with open(os.path.join(folder, "skin.json"), "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)
    report.info(f"Skin written to {folder}")
    return report, folder


# ------------------------------------------------------------------------------------------------- send to the game

DEFAULT_KIT = ""  # set the Kit folder in the add-on's preferences
LIVE_POLL_SECONDS = 1.0
_live = {"process": None, "status_file": None, "log": None}


def kit_folder(context):
    try:
        prefs = context.preferences.addons[__name__].preferences
        return bpy.path.abspath(prefs.kit_folder)
    except (KeyError, AttributeError):
        return DEFAULT_KIT


def live_busy():
    process = _live["process"]
    return process is not None and process.poll() is None


def _set_live(state, message):
    wm = bpy.context.window_manager
    wm.sinspire_live_state = state
    wm.sinspire_live_message = message
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _poll_live():
    """Timer: copies the build's status.json into the panel until the build ends."""
    data = {}
    try:
        with open(_live["status_file"], encoding="utf-8-sig") as handle:
            data = json.load(handle)
    except (OSError, ValueError, TypeError):
        pass
    state = data.get("state")
    if state:
        _set_live(state, f"{data.get('message', '')} ({data.get('time', '')})")
    process = _live["process"]
    if process is None or process.poll() is not None:
        if state not in ("sent", "failed"):
            code = process.returncode if process else "?"
            _set_live("failed", f"The build stopped (exit {code}) before saying why. Press Open build log.")
        _live["process"] = None
        return None
    return LIVE_POLL_SECONDS


def send_to_game(context, folder, skin_id):
    """Starts build_skin.ps1 -Live for an export folder, without a console window; returns an error text or None."""
    kit = kit_folder(context)
    script = os.path.join(kit, "build_skin.ps1")
    if not os.path.isfile(script):
        return f"No build_skin.ps1 in the Skin Kit folder '{kit}' (set it in the add-on's preferences)"
    if live_busy():
        return "Still sending the last export to the game; export again when it is done"
    status_file = os.path.join(kit, "build", f"{skin_id}-live", "status.json")
    try:
        os.remove(status_file)
    except OSError:
        pass
    command = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script,
               "-Export", folder, "-Live"]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    _live["process"] = subprocess.Popen(command, cwd=kit, creationflags=flags, stdout=subprocess.DEVNULL,
                                        stderr=subprocess.DEVNULL)
    _live["status_file"] = status_file
    _live["log"] = os.path.join(kit, "build", f"{skin_id}-live", "build.log")
    _set_live("starting", "Starting the Unreal build")
    if not bpy.app.timers.is_registered(_poll_live):
        bpy.app.timers.register(_poll_live, first_interval=LIVE_POLL_SECONDS)
    return None


# ---------------------------------------------------------------------------------------------------------- UI glue

def store_report(context, report):
    lines = context.window_manager.sinspire_report
    lines.clear()
    for level, text in report.lines:
        item = lines.add()
        item.level = level
        item.text = text


def _path_options():
    """Blender 4.5+ only keeps a '//' (next to the .blend) path in a property flagged for it; older ones have no flag."""
    try:
        bpy.props.StringProperty(options={"PATH_SUPPORTS_BLEND_RELATIVE"})
        return {"PATH_SUPPORTS_BLEND_RELATIVE"}
    except TypeError:
        return set()


PATH_OPTIONS = _path_options()


class SINSPIRE_ReportLine(bpy.types.PropertyGroup):
    level: StringProperty()
    text: StringProperty()


class SINSPIRE_PieceSettings(bpy.types.PropertyGroup):
    include: BoolProperty(name="Export", default=True, description="Export this piece")
    is_body: BoolProperty(name="Body part", default=False,
                          description="Part of the body, not clothing: all body parts are joined into one body on "
                                      "export (used with 'My body mesh'; never exported as a piece)")
    first_person: BoolProperty(name="First person", default=True,
                               description="Also wear it on the first-person body (arms and hands are what you see)")
    in_scenes: BoolProperty(name="In scenes", default=False,
                            description="Keep it on during sex scenes (off: the game's nude body shows)")
    triangles: IntProperty(name="Triangles", default=-1)


class SINSPIRE_SkinSettings(bpy.types.PropertyGroup):
    skin_id: StringProperty(name="Skin name", default="MySkin",
                            description="Letters, digits and _: becomes the mod folder and pak name")
    title: StringProperty(name="Title", description="Shown in the game's skin list")
    author: StringProperty(name="Author")
    target: EnumProperty(name="Target", items=[("player", "Player", "The player character")], default="player")
    armature: PointerProperty(name="Armature", type=bpy.types.Object,
                              poll=lambda self, obj: obj.type == "ARMATURE")
    body_object: PointerProperty(name="Body", type=bpy.types.Object, poll=lambda self, obj: obj.type == "MESH",
                                 description="Your body mesh (optional)")
    body_mode: EnumProperty(name="Body", default="none", items=[
        ("none", "Game body", "Keep the game's body and texture"),
        ("texture", "Game body, my texture", "Keep the game's body mesh, use the body object's texture"),
        ("mesh", "My body mesh", "Replace the body with the body object (and its texture)"),
    ])
    subdivision: IntProperty(name="Subdivision", default=0, min=0, max=3,
                             description="Highest Subdivision level used on export (each level is 4x the triangles)")
    texture_size: EnumProperty(name="Texture size", default="2048", items=[
        ("512", "512", ""), ("1024", "1024", ""), ("2048", "2048", ""), ("4096", "4096", "")])
    output_dir: StringProperty(name="Folder", default="//SinSpireSkins", subtype="DIR_PATH", options=PATH_OPTIONS)
    send_to_game: BoolProperty(name="Send to game", default=True,
                               description="After exporting, build it with the Skin Kit and put it on in the running "
                                           "game as Live preview (PC; needs the Skin Kit and Unreal 5.3)")
    allow_missing: BoolProperty(name="Stand-ins for missing textures", default=False,
                                description="Export a checker for textures that cannot be found, instead of stopping")


class SINSPIRE_Preferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    kit_folder: StringProperty(name="Skin Kit folder", subtype="DIR_PATH", default=DEFAULT_KIT,
                               description="The folder with build_skin.ps1 (the Unreal 5.3 side of the Skin Kit)")

    def draw(self, context):
        self.layout.prop(self, "kit_folder")


class SINSPIRE_OT_check(bpy.types.Operator):
    bl_idname = "sinspire.check_skin"
    bl_label = "Check"
    bl_description = "Check the rig, pieces, weights, triangles and textures"

    def execute(self, context):
        settings = context.scene.sinspire_skin
        if settings.armature is None:
            settings.armature = auto_armature(context.scene)
        report = run_checks(context, settings, measure=True)
        store_report(context, report)
        self.report({"ERROR"} if report.errors else {"INFO"},
                    f"{len(report.errors)} problems" if report.errors else "Ready to export")
        return {"FINISHED"}


class SINSPIRE_OT_export(bpy.types.Operator):
    bl_idname = "sinspire.export_skin"
    bl_label = "Export Skin"
    bl_description = "Check, then export the skin folder for the Unreal Skin Kit"

    def execute(self, context):
        settings = context.scene.sinspire_skin
        if settings.armature is None:
            settings.armature = auto_armature(context.scene)
        try:
            report, folder = export_skin(context, settings)
        except Exception as error:  # keep Blender usable and say what failed
            report = Report()
            report.error(f"Export failed: {error}")
            folder = None
        if folder is not None and settings.send_to_game:
            problem = send_to_game(context, folder, settings.skin_id)
            if problem:
                report.warn(f"Not sent to the game: {problem}")
            else:
                report.info("Sending to the game: the Unreal build takes a minute or two; the game can stay open, "
                            "and the Skin Swapper puts it on as Live preview.")
        store_report(context, report)
        if folder is None:
            self.report({"ERROR"}, "Not exported: see the Sin Spire panel")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Exported to {folder}")
        return {"FINISHED"}


class SINSPIRE_OT_open_build_log(bpy.types.Operator):
    bl_idname = "sinspire.open_build_log"
    bl_label = "Open build log"
    bl_description = "Open the log of the last build sent to the game (what failed, and where Unreal and the game were found)"

    def execute(self, context):
        settings = context.scene.sinspire_skin
        path = _live["log"] or os.path.join(kit_folder(context), "build", f"{settings.skin_id}-live", "build.log")
        if not os.path.isfile(path):
            self.report({"ERROR"}, f"No build log yet ({path})")
            return {"CANCELLED"}
        bpy.ops.wm.path_open(filepath=path)
        return {"FINISHED"}


class SINSPIRE_OT_open_folder(bpy.types.Operator):
    bl_idname = "sinspire.open_export_folder"
    bl_label = "Open Folder"

    def execute(self, context):
        settings = context.scene.sinspire_skin
        path = os.path.join(bpy.path.abspath(settings.output_dir), settings.skin_id)
        if os.path.isdir(path):
            bpy.ops.wm.path_open(filepath=path)
        return {"FINISHED"}


class SINSPIRE_PT_panel(bpy.types.Panel):
    bl_label = "Sin Spire Skin"
    bl_idname = "SINSPIRE_PT_skin"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Sin Spire"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.sinspire_skin

        box = layout.box()
        box.label(text="Skin", icon="OUTLINER_OB_ARMATURE")
        box.prop(settings, "skin_id")
        box.prop(settings, "title")
        box.prop(settings, "author")

        box = layout.box()
        box.label(text="Rig and body", icon="ARMATURE_DATA")
        box.prop(settings, "target")
        box.prop(settings, "armature")
        box.prop(settings, "body_mode")
        box.prop(settings, "body_object", text="Body object")
        armature = settings.armature or auto_armature(context.scene)
        parts = [o for o in skinned_meshes(context.scene, armature) if is_body_part(o, settings)]
        if settings.body_object is not None and settings.body_object not in parts:
            parts.insert(0, settings.body_object)
        if len(parts) > 1:
            box.label(text=f"Body: {len(parts)} meshes, joined on export", icon="USER")
        else:
            box.label(text="Body in several meshes: tick the person icon on each", icon="INFO")

        box = layout.box()
        box.label(text="Meshes on the rig", icon="MOD_CLOTH")
        meshes = skinned_meshes(context.scene, armature)
        if not meshes:
            box.label(text="No meshes deformed by the armature")
        heart = "HEART" if "HEART" in _ICONS else "FUND"
        for obj in meshes:
            row = box.row(align=True)
            body = is_body_part(obj, settings)
            if obj == settings.body_object:
                row.label(text="", icon="USER")  # the Body object field makes it a body part
            else:
                row.prop(obj.sinspire_piece, "is_body", text="", icon="USER")
            inc = row.row(align=True)
            inc.enabled = not body
            inc.prop(obj.sinspire_piece, "include", text="")
            row.label(text=obj.name + ("  (body)" if body else ""))
            sub = row.row(align=True)
            sub.enabled = obj.sinspire_piece.include and not body
            sub.prop(obj.sinspire_piece, "first_person", text="", icon="HIDE_OFF")
            sub.prop(obj.sinspire_piece, "in_scenes", text="", icon=heart)
            tris = obj.sinspire_piece.triangles
            row.label(text=f"{tris:,}" if tris >= 0 else "-")
        box.label(text="Person: body part   Tick: export as clothing", icon="INFO")
        box.label(text="Eye: first person   Heart: on in sex scenes", icon="BLANK1")

        box = layout.box()
        box.label(text="Export", icon="EXPORT")
        box.prop(settings, "subdivision")
        box.prop(settings, "texture_size")
        box.prop(settings, "output_dir")
        box.prop(settings, "allow_missing")
        box.prop(settings, "send_to_game")
        row = box.row(align=True)
        row.operator("sinspire.check_skin", icon="CHECKMARK")
        row.operator("sinspire.export_skin", icon="EXPORT")
        box.operator("sinspire.open_export_folder", icon="FILE_FOLDER")
        wm = context.window_manager
        if wm.sinspire_live_state:
            icon = {"sent": "CHECKMARK", "failed": "ERROR"}.get(wm.sinspire_live_state, "TIME")
            col = box.column(align=True)
            col.alert = wm.sinspire_live_state == "failed"
            col.label(text="Game: " + wm.sinspire_live_state, icon=icon)
            for line in wrap(wm.sinspire_live_message, 48):
                col.label(text=line)
            if wm.sinspire_live_state == "failed":
                box.operator("sinspire.open_build_log", icon="TEXT")

        lines = context.window_manager.sinspire_report
        if len(lines):
            box = layout.box()
            box.label(text="Report", icon="TEXT")
            icons = {"ERROR": "ERROR", "WARNING": "ERROR", "INFO": "INFO"}
            for item in lines:
                col = box.column(align=True)
                col.alert = item.level == "ERROR"
                words = item.text.split()
                line, first = "", True
                for word in words:
                    if len(line) + len(word) > 48:
                        col.label(text=line, icon=icons[item.level] if first else "BLANK1")
                        line, first = word, False
                    else:
                        line = (line + " " + word).strip()
                if line:
                    col.label(text=line, icon=icons[item.level] if first else "BLANK1")


def wrap(text, width):
    lines, line = [], ""
    for word in text.split():
        if line and len(line) + len(word) + 1 > width:
            lines.append(line)
            line = word
        else:
            line = (line + " " + word).strip()
    if line:
        lines.append(line)
    return lines


_ICONS = set(bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.keys())

CLASSES = (SINSPIRE_ReportLine, SINSPIRE_PieceSettings, SINSPIRE_SkinSettings, SINSPIRE_Preferences,
           SINSPIRE_OT_check, SINSPIRE_OT_export, SINSPIRE_OT_open_build_log, SINSPIRE_OT_open_folder,
           SINSPIRE_PT_panel)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.sinspire_skin = PointerProperty(type=SINSPIRE_SkinSettings)
    bpy.types.Object.sinspire_piece = PointerProperty(type=SINSPIRE_PieceSettings)
    bpy.types.WindowManager.sinspire_report = CollectionProperty(type=SINSPIRE_ReportLine)
    bpy.types.WindowManager.sinspire_live_state = StringProperty()
    bpy.types.WindowManager.sinspire_live_message = StringProperty()


def unregister():
    if bpy.app.timers.is_registered(_poll_live):
        bpy.app.timers.unregister(_poll_live)
    del bpy.types.WindowManager.sinspire_live_message
    del bpy.types.WindowManager.sinspire_live_state
    del bpy.types.WindowManager.sinspire_report
    del bpy.types.Object.sinspire_piece
    del bpy.types.Scene.sinspire_skin
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
