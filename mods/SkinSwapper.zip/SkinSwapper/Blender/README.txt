Sin Spire Skin Exporter (Blender 4.2 or newer)

Install: Blender > Edit > Preferences > Add-ons > the arrow at the top right > Install from Disk > pick
sinspire_skin_exporter.py from this folder, then tick "Sin Spire Skin Exporter".

Use: 3D View, press N, open the "Sin Spire" tab. Pick the game's player armature, set the body (one body mesh, or tick
the person icon on each mesh of a body in several parts), tick the clothing pieces, press Check, then Export.

Turning an export into something the game loads needs Unreal Engine 5.3 and the Skin Kit's build scripts (shared
separately): set the add-on's "Skin Kit folder" preference to that kit's Kit folder, and with "Send to game" ticked an
Export shows up on your character in the running game as "Live preview" (Admin Panel > Skins).
