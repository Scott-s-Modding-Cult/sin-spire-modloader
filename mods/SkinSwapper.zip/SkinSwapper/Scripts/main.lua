-- Skin Swapper: puts a skin mod (made with the Skin Kit) on the player.
--
-- A skin mod is a folder in Mods with a skin.json and a pak (see SkinKit\FORMAT.md). The Admin Panel's "Skins" tab lists
-- every loaded skin mod; the choice is saved in Mods\SkinSwapper\skin.txt.
--
-- What a skin can do:
--   body texture  the body's material becomes a copy of the game's own M_PlayerFull with the skin's texture as BaseTex
--   body mesh     the body mesh is swapped (the game's physics asset is kept) and textured the same way
--   pieces        each piece (shirt, gloves...) is its own mesh following the body's bones (leader pose), as the game
--                 dresses its NPCs in BPC_OutfitComponent. Every slot gets the player material with the piece's texture.
-- The player has two bodies: "FP Viewport Mesh", the first-person body under the camera, and "Mesh", the third-person
-- body. In play Mesh is hidden from the player's own camera (owner no see) and casts the shadow; scenes
-- (StartInteraction) let the player see it, and death hides it with M_NoDraw. Pieces go on Mesh always (kept on in
-- scenes only if the skin says so) and on the first-person body if the skin says so. Mesh is shown and hidden without
-- its children, so each piece copies its body's visibility, owner-see and shadow flags every tick.
-- Respawn puts M_PlayerFull back on Mesh; the tick puts the skin's material back on.
-- Not covered: cutscenes that place their own copy of the player (intro, neutral ending).

local UEHelpers = require("UEHelpers")
local AdminTabs = require("AdminTabs")
local json = require("skin_json")

local NAME = "SkinSwapper"
local MODS_DIR = "..\\..\\..\\Mods\\" -- the game runs from SinSpire\Binaries\Win64
local LOADED_FILE = MODS_DIR .. ".modloader\\loaded.txt"
local CHOICE_FILE = "ue4ss\\Mods\\SkinSwapper\\skin.txt" -- beside mod.json, so a rebuild keeps it
local TICK_MS = 250
local REFIND_TICKS = 8 -- look for a new player actor every 2 s even while the old one is valid
local PLAYER_CLASS = "BP_PlayerCharacter_C"
local PLAYER_MATERIAL = "/Game/Models/Characters/Human/Player/M_PlayerFull"
local TEXTURE_PARAMETER = "BaseTex"
local NO_DRAW = "M_NoDraw"
local GAME_MATERIAL = "M_PlayerFull"
local EMPTY_MATERIALS = { None = true, WorldGridMaterial = true, DefaultMaterial = true } -- a swapped body before it is textured
local SNAP = 2 -- EAttachmentRule::SnapToTarget
local NO_COLLISION = 0
local IDENTITY = {
    Rotation = { X = 0, Y = 0, Z = 0, W = 1 },
    Translation = { X = 0, Y = 0, Z = 0 },
    Scale3D = { X = 1, Y = 1, Z = 1 },
}
local STATE_VARIABLE = "SkinSwapper_State" -- for tests: "<skin id or none>|<pieces worn>|<player address>"
-- Live previews (build_skin.ps1 -Live): cooked builds in the game's PersistentDownloadDir, each with a BuildPatchServices
-- manifest, mounted while the game runs by the game's own UMobilePatchingLibrary (GetInstalledContent, then Mount, which
-- mounts the .pak and its IoStore container and registers its packages).
local LIVE_ROOT = (os.getenv("LOCALAPPDATA") or "") .. "\\SinSpire\\Saved\\PersistentDownloadDir\\SkinKitLive\\"
local LIVE_LATEST = LIVE_ROOT .. "latest.json"
local LIVE_CHOICE = "live"
local LIVE_POLL_TICKS = 4 -- look for a new live build every second
local PATCHING_LIBRARY = "/Script/MobilePatchingUtils.Default__MobilePatchingLibrary"
local LIVE_PAK_ORDER = 1000
local LIVE_MOUNT_POINT = "../../../" -- the mount point retoc writes into our paks
-- Set by the Model Studio: "worn" shows every piece even while the player can see the third-person body (the studio
-- shows it outside scenes), "scene" shows the body as a sex scene would; anything else, the game's own state decides.
local STUDIO_VIEW_VARIABLE = "ModelStudio_View"

local function log(message)
    print("[" .. NAME .. "] " .. tostring(message) .. "\n")
end

local function valid(object)
    return object ~= nil and object:IsValid()
end

local function fname(text)
    return UEHelpers.FindOrAddFName(text)
end

local function object_name(object)
    if not valid(object) then return "None" end
    local ok, name = pcall(function() return object:GetFName():ToString() end)
    return ok and name or "?"
end

local function read_file(path)
    local file = io.open(path, "r")
    if not file then return nil end
    local text = file:read("*a")
    file:close()
    return text
end

local function one_line(text)
    return (tostring(text):gsub("[\r\n\t|]+", " "))
end

-- ----------------------------------------------------------------------------------------------------- skin list

-- A skin.json read into a skin, or nil and why not.
local function read_skin(text, source)
    local ok, data = pcall(json.decode, text)
    if not ok then return nil, tostring(data) end
    if type(data) ~= "table" or data.format ~= 1 or data.target ~= "player" or type(data.id) ~= "string" then
        return nil, "not a format 1 player skin"
    end
    data.mod = source
    data.title = one_line(data.title or data.id)
    data.pieces = data.pieces or {}
    data.body = data.body or { mode = "none" }
    return data
end

local function discover()
    local found = {}
    local loaded = read_file(LOADED_FILE)
    if not loaded then
        log("No " .. LOADED_FILE .. "; is the mod loader installed?")
        return found
    end
    for line in loaded:gmatch("[^\r\n]+") do
        local mod_name = line:match("^([^=]+)=")
        local text = mod_name and read_file(MODS_DIR .. mod_name .. "\\skin.json")
        if text then
            local skin, problem = read_skin(text, mod_name)
            if skin then
                found[#found + 1] = skin
            else
                log("Skipped " .. mod_name .. ": " .. problem)
            end
        end
    end
    table.sort(found, function(a, b) return a.title:lower() < b.title:lower() end)
    return found
end

local skins = discover()
local LIVE_INDEX = #skins + 1 -- "Live preview", the last option of the row
local current = nil -- the chosen skin, nil for the game's own look
local live = { seen = nil, skin = nil, mounted = {}, wanted = false } -- wanted: Live preview is the choice

local function choose_by_id(id)
    current = nil
    live.wanted = id == LIVE_CHOICE
    for _, skin in ipairs(skins) do
        if skin.id == id then current = skin end
    end
end

local saved = read_file(CHOICE_FILE)
if saved then choose_by_id(saved:match("^%s*(.-)%s*$")) end

local function save_choice()
    local file = io.open(CHOICE_FILE, "w")
    if file then
        file:write(live.wanted and LIVE_CHOICE or (current and current.id) or "none")
        file:close()
    end
end

-- -------------------------------------------------------------------------------------------------------- assets

local function load_asset(path)
    local asset_name = path:match("([^/]+)$")
    local helpers = StaticFindObject("/Script/AssetRegistry.Default__AssetRegistryHelpers")
    if not valid(helpers) then return nil end
    local ok, asset = pcall(function()
        return helpers:GetAsset({ PackageName = fname(path), AssetName = fname(asset_name) })
    end)
    if ok and valid(asset) then return asset end
    return nil
end

-- Loads everything a skin needs, or returns nil and the first thing that failed (nothing is put on half-loaded).
local function load_skin(skin)
    local assets = { material = load_asset(PLAYER_MATERIAL), textures = {}, pieces = {} }
    if not assets.material then return nil, PLAYER_MATERIAL end
    local function texture(path)
        if assets.textures[path] == nil then assets.textures[path] = load_asset(path) or false end
        return assets.textures[path]
    end
    for _, slot in ipairs(skin.body.slots or {}) do
        if not texture(slot.texture) then return nil, slot.texture end
    end
    if skin.body.mode == "mesh" then
        assets.body = load_asset(skin.body.mesh)
        if not assets.body then return nil, skin.body.mesh end
    end
    for _, piece in ipairs(skin.pieces) do
        local mesh = load_asset(piece.mesh)
        if not mesh then return nil, piece.mesh end
        assets.pieces[piece.name] = mesh
        for _, slot in ipairs(piece.slots or {}) do
            if not texture(slot.texture) then return nil, slot.texture end
        end
    end
    return assets
end

-- --------------------------------------------------------------------------------------------------------- player

local function find_player()
    local player = FindFirstOf(PLAYER_CLASS)
    if valid(player) then return player end
    return nil
end

local function bodies(player)
    local list = {}
    local ok_tp, tp = pcall(function() return player.Mesh end)
    if ok_tp and valid(tp) then list[#list + 1] = { kind = "tp", component = tp } end
    local ok_fp, fp = pcall(function() return player["FP Viewport Mesh"] end)
    if not (ok_fp and valid(fp)) then
        ok_fp, fp = pcall(function() return player:GetPropertyValue("FP Viewport Mesh") end)
    end
    if ok_fp and valid(fp) then list[#list + 1] = { kind = "fp", component = fp } end
    return list
end

-- What is on the player now, so it can be taken off again.
local worn = {
    player = nil,        -- the player actor (UObject)
    address = nil,       -- its address
    skin = nil,          -- the skin put on
    assets = nil,
    pieces = {},         -- { component, leader, kind, piece, shown }
    swapped = {},        -- { mesh, physics } the body mesh and physics asset the game had, by body kind
    mids = {},           -- [body kind][slot index] = address of the material this mod put there
}

local function textured_material(component, index, assets, texture_path)
    local mid = component:CreateDynamicMaterialInstance(index, assets.material, fname("None"))
    if valid(mid) then
        mid:SetTextureParameterValue(fname(TEXTURE_PARAMETER), assets.textures[texture_path])
    end
    return mid
end

local function material_name(component, index)
    local ok, material = pcall(function() return component:GetMaterial(index) end)
    return ok and object_name(material) or "None"
end

-- Puts the skin's body material back on wherever the game has its own M_PlayerFull (or nothing) there.
local function sync_body(body)
    local skin, assets = worn.skin, worn.assets
    if not skin or not skin.body.slots then return end
    local swapped = worn.swapped[body.kind] ~= nil
    for _, slot in ipairs(skin.body.slots) do
        local name = material_name(body.component, slot.index)
        if name == GAME_MATERIAL or (swapped and EMPTY_MATERIALS[name]) then
            local mid = textured_material(body.component, slot.index, assets, slot.texture)
            if valid(mid) then
                worn.mids[body.kind] = worn.mids[body.kind] or {}
                worn.mids[body.kind][slot.index] = mid:GetAddress()
            end
        end
    end
end

local function swap_mesh(component, mesh)
    if not pcall(function() component:SetSkinnedAssetAndUpdate(mesh, false) end) then
        component:SetSkeletalMeshAsset(mesh)
    end
end

local function take_off()
    for _, worn_piece in ipairs(worn.pieces) do
        if valid(worn_piece.component) then
            pcall(function() worn_piece.component:K2_DestroyComponent(worn_piece.component) end)
        end
    end
    worn.pieces = {}
    if valid(worn.player) then
        for _, body in ipairs(bodies(worn.player)) do
            local original = worn.swapped[body.kind]
            if original and valid(original.mesh) then
                pcall(swap_mesh, body.component, original.mesh)
                if valid(original.physics) then
                    pcall(function() body.component:SetPhysicsAsset(original.physics, false) end)
                end
            end
            -- A slot still showing this mod's material goes back to the game's (other mods' materials are left alone).
            local game_material = load_asset(PLAYER_MATERIAL)
            for index, address in pairs(worn.mids[body.kind] or {}) do
                local ok, material = pcall(function() return body.component:GetMaterial(index) end)
                if ok and valid(material) and material:GetAddress() == address and game_material then
                    pcall(function() body.component:SetMaterial(index, game_material) end)
                end
            end
        end
    end
    worn.swapped, worn.mids = {}, {}
    worn.skin, worn.assets = nil, nil
end

local function put_on(player, skin)
    local assets, missing = load_skin(skin)
    if not assets then
        log("Cannot put on " .. skin.title .. ": could not load " .. tostring(missing) .. " (is " .. skin.mod .. "'s pak installed?)")
        return false
    end
    worn.skin, worn.assets = skin, assets
    local list = bodies(player)
    if #list == 0 then
        log("The player has no body meshes yet")
        return false
    end
    local mesh_class = StaticFindObject("/Script/Engine.SkeletalMeshComponent")
    for _, body in ipairs(list) do
        if assets.body then
            local ok, original = pcall(function() return body.component.SkeletalMeshAsset end)
            local physics = nil
            if ok and valid(original) then
                pcall(function() physics = original:GetPhysicsAsset() end)
            end
            worn.swapped[body.kind] = { mesh = ok and original or nil, physics = physics }
            swap_mesh(body.component, assets.body)
            if valid(physics) then
                pcall(function() body.component:SetPhysicsAsset(physics, false) end)
            end
        end
        sync_body(body)
        for _, piece in ipairs(skin.pieces) do
            if body.kind == "tp" or piece.first_person then
                local component = player:AddComponentByClass(mesh_class, false, IDENTITY, false)
                if valid(component) then
                    swap_mesh(component, assets.pieces[piece.name])
                    component:K2_AttachToComponent(body.component, fname("None"), SNAP, SNAP, SNAP, true)
                    component:SetLeaderPoseComponent(body.component, false, false)
                    pcall(function() component.bUseBoundsFromLeaderPoseComponent = true end)
                    pcall(function() component:SetCollisionEnabled(NO_COLLISION) end)
                    pcall(function() component:SetGenerateOverlapEvents(false) end)
                    for _, slot in ipairs(piece.slots or {}) do
                        textured_material(component, slot.index, assets, slot.texture)
                    end
                    worn.pieces[#worn.pieces + 1] = { component = component, leader = body.component, kind = body.kind,
                        piece = piece, shown = nil }
                else
                    log("Could not add a component for " .. piece.name)
                end
            end
        end
    end
    log(("Put on %s (%s): body %s, %d piece components on %d bodies"):format(skin.title, skin.mod, skin.body.mode,
        #worn.pieces, #list))
    return true
end

-- Each piece copies its body: shown while the body is shown and not hidden by M_NoDraw, with the body's owner-see and
-- shadow flags. In play the third-person body is shown but hidden from the player's own camera (owner no see), so it
-- only casts the shadow; a scene is when the player can see it (StartInteraction turns owner no see off). There a piece
-- stays on only if the skin keeps it on in scenes. The state is checked against the piece itself every tick, because
-- the game's SetVisibility on the first-person body reaches the pieces under it too.
local function is_scene(component, visible)
    local view = ModRef:GetSharedVariable(STUDIO_VIEW_VARIABLE)
    if view == "worn" then return false end
    if view == "scene" then return visible end
    return visible and not component.bOwnerNoSee
end

local function sync_pieces()
    for _, entry in ipairs(worn.pieces) do
        local component, leader = entry.component, entry.leader
        if valid(component) and valid(leader) then
            pcall(function()
                local leader_visible = leader:IsVisible()
                local owner_no_see, only_owner_see, cast_shadow = leader.bOwnerNoSee, leader.bOnlyOwnerSee, leader.CastShadow
                local no_draw = material_name(leader, 0) == NO_DRAW
                local scene = entry.kind == "tp" and is_scene(leader, leader_visible)
                local worn_now = not no_draw and (entry.piece.in_scenes or not scene)
                local show = leader_visible and worn_now
                local hidden_shadow = leader.bCastHiddenShadow and worn_now
                local key = table.concat({ tostring(show), tostring(hidden_shadow), tostring(owner_no_see),
                    tostring(only_owner_see), tostring(cast_shadow) }, ",")
                if key ~= entry.shown or component:IsVisible() ~= show then
                    component:SetVisibility(show, false)
                    component:SetCastHiddenShadow(hidden_shadow)
                    component:SetOwnerNoSee(owner_no_see)
                    component:SetOnlyOwnerSee(only_owner_see)
                    component:SetCastShadow(cast_shadow)
                    entry.shown = key
                end
            end)
        end
    end
end

-- A body cut away under its clothes (the skin's body.holes): in a scene where some pieces come off, the third-person body
-- becomes the game's own full body, still with the skin's texture (made on the game's UVs), and goes back afterwards.
local function sync_scene_body(body)
    local skin, assets = worn.skin, worn.assets
    if body.kind ~= "tp" or not skin or not (assets and assets.body) or not skin.body.holes then return end
    local original = worn.swapped.tp
    if not (original and valid(original.mesh)) then return end
    local any_off = false
    for _, piece in ipairs(skin.pieces) do
        if not piece.in_scenes then any_off = true end
    end
    local component = body.component
    local scene = is_scene(component, component:IsVisible())
    local want = (scene and any_off) and original.mesh or assets.body
    local ok, now = pcall(function() return component.SkeletalMeshAsset end)
    if ok and valid(now) and valid(want) and now:GetAddress() ~= want:GetAddress() then
        swap_mesh(component, want)
        log(want == original.mesh and "Scene: the game's full body under the pieces that come off"
            or "Out of the scene: the skin's body again")
    end
end

local function pieces_intact()
    for _, entry in ipairs(worn.pieces) do
        if not valid(entry.component) then return false end
    end
    return true
end

local function publish_state()
    local text = (worn.skin and worn.skin.id or "none") .. "|" .. #worn.pieces .. "|" ..
        tostring(worn.address or "none")
    ModRef:SetSharedVariable(STATE_VARIABLE, text)
end

-- ----------------------------------------------------------------------------------------------------- live builds

local dirty = true -- the choice changed: take off and put on again

local function mount_live(dir)
    local library = StaticFindObject(PATCHING_LIBRARY)
    if not valid(library) then return false, "the game has no MobilePatchingLibrary" end
    local content = library:GetInstalledContent(dir)
    if not valid(content) then return false, "no manifest found for " .. dir end
    if not content:Mount(LIVE_PAK_ORDER, LIVE_MOUNT_POINT) then return false, "Mount said no" end
    return true
end

-- Looks at latest.json; a build not seen before is mounted and becomes the Live preview. The first look (at start) only
-- puts it on if Live preview was the saved choice; a new build while playing switches to it.
local function check_live(first)
    local text = read_file(LIVE_LATEST)
    if not text or text == live.seen then return end
    live.seen = text
    local ok, latest = pcall(json.decode, text)
    if not ok or type(latest) ~= "table" or type(latest.dir) ~= "string" or type(latest.skin) ~= "string" then
        log("Live: unreadable latest.json")
        return
    end
    if not live.mounted[latest.dir] then
        local mounted, problem = mount_live(latest.dir)
        if not mounted then
            log("Live: could not mount " .. latest.dir .. ": " .. tostring(problem))
            return
        end
        live.mounted[latest.dir] = true
        log("Live: mounted " .. latest.dir)
    end
    local skin_text = read_file(latest.skin)
    local skin, problem = skin_text and read_skin(skin_text, "live " .. tostring(latest.build))
    if not skin then
        log("Live: could not read " .. latest.skin .. ": " .. tostring(problem or "missing"))
        return
    end
    skin.title = skin.title .. " (live)"
    live.skin = skin
    if not first then
        live.wanted = true
        AdminTabs.SetChoice("SkinSwapper", 1, LIVE_INDEX)
        save_choice()
    end
    if live.wanted then
        current = skin
        dirty = true
        log("Live: putting on " .. skin.title .. " " .. tostring(latest.build))
    end
end

-- ----------------------------------------------------------------------------------------------------------- tick

local ticks = 0

local function tick()
    ticks = ticks + 1
    if ticks == 1 or ticks % LIVE_POLL_TICKS == 0 then
        check_live(ticks == 1)
    end
    local player = worn.player
    if not valid(player) or ticks % REFIND_TICKS == 0 then
        player = find_player()
    end
    local address = valid(player) and player:GetAddress() or nil
    if address ~= worn.address then
        -- A new player actor (level change, respawn as a new actor): the old pieces went with the old one.
        worn.pieces, worn.swapped, worn.mids, worn.skin, worn.assets = {}, {}, {}, nil, nil
        worn.player, worn.address = player, address
        dirty = true
    end
    if not valid(player) then return end
    if dirty or (worn.skin and not pieces_intact()) then
        dirty = false
        take_off()
        if current then put_on(player, current) end
        publish_state()
    end
    if worn.skin then
        for _, body in ipairs(bodies(player)) do
            sync_scene_body(body)
            sync_body(body)
        end
        sync_pieces()
    end
end

local options = { "Game default" }
local chosen_index = 0
for index, skin in ipairs(skins) do
    options[#options + 1] = skin.title
    if current and skin.id == current.id then chosen_index = index end
end
options[LIVE_INDEX + 1] = "Live preview"
if live.wanted then chosen_index = LIVE_INDEX end
local tab = AdminTabs.AddTab({ id = "SkinSwapper", title = "Skins" })
tab:AddChoice("Player skin", options, chosen_index, function(index)
    live.wanted = index == LIVE_INDEX
    if live.wanted then
        current = live.skin
    else
        current = skins[index] -- index 0 (Game default) gives nil
    end
    save_choice()
    dirty = true
    if live.wanted and not current then
        log("Chose Live preview, but no live build has been sent yet (Export in Blender with Send to game)")
    else
        log("Chose " .. (current and current.title or "the game's own look"))
    end
end)
tab:AddButton("Put the skin on again", function() dirty = true end)

local errors = 0
LoopInGameThreadWithDelay(TICK_MS, function()
    local ok, problem = pcall(tick)
    if not ok then
        errors = errors + 1
        if errors <= 5 then log("Error: " .. tostring(problem)) end
    end
    AdminTabs.Poll()
end)

local names = {}
for _, skin in ipairs(skins) do names[#names + 1] = skin.title .. " (" .. skin.mod .. ")" end
log(("Started: %d skins [%s], chosen: %s"):format(#skins, table.concat(names, ", "),
    live.wanted and "Live preview" or (current and current.title) or "game default"))
