-- A small JSON reader for skin.json files: objects, arrays, strings (with \u escapes), numbers, true, false, null.
-- skin_json.decode(text) returns the value or raises an error naming the position.

local M = {}

local escapes = { ['"'] = '"', ["\\"] = "\\", ["/"] = "/", b = "\b", f = "\f", n = "\n", r = "\r", t = "\t" }

local function utf8_char(code)
    if code < 0x80 then return string.char(code) end
    if code < 0x800 then return string.char(0xC0 | (code >> 6), 0x80 | (code & 0x3F)) end
    return string.char(0xE0 | (code >> 12), 0x80 | ((code >> 6) & 0x3F), 0x80 | (code & 0x3F))
end

function M.decode(text)
    local pos = 1
    if text:sub(1, 3) == "\239\187\191" then pos = 4 end -- UTF-8 byte order mark

    local function fail(what)
        error(("skin.json: %s at character %d"):format(what, pos), 0)
    end

    local function skip()
        pos = text:find("[^ \t\r\n]", pos) or (#text + 1)
    end

    local value

    local function str()
        pos = pos + 1
        local parts = {}
        while true do
            local c = text:sub(pos, pos)
            if c == "" then fail("unfinished string") end
            if c == '"' then pos = pos + 1; break end
            if c == "\\" then
                local e = text:sub(pos + 1, pos + 1)
                if e == "u" then
                    local hex = text:sub(pos + 2, pos + 5)
                    if not hex:match("^%x%x%x%x$") then fail("bad \\u escape") end
                    parts[#parts + 1] = utf8_char(tonumber(hex, 16))
                    pos = pos + 6
                elseif escapes[e] then
                    parts[#parts + 1] = escapes[e]
                    pos = pos + 2
                else
                    fail("bad escape")
                end
            else
                local stop = text:find('["\\]', pos) or (#text + 1)
                parts[#parts + 1] = text:sub(pos, stop - 1)
                pos = stop
            end
        end
        return table.concat(parts)
    end

    function value()
        skip()
        local c = text:sub(pos, pos)
        if c == "{" then
            pos = pos + 1
            local out = {}
            skip()
            if text:sub(pos, pos) == "}" then pos = pos + 1; return out end
            while true do
                skip()
                if text:sub(pos, pos) ~= '"' then fail("expected a key") end
                local key = str()
                skip()
                if text:sub(pos, pos) ~= ":" then fail("expected ':'") end
                pos = pos + 1
                out[key] = value()
                skip()
                local d = text:sub(pos, pos)
                pos = pos + 1
                if d == "}" then return out end
                if d ~= "," then fail("expected ',' or '}'") end
            end
        elseif c == "[" then
            pos = pos + 1
            local out, count = {}, 0
            skip()
            if text:sub(pos, pos) == "]" then pos = pos + 1; return out end
            while true do
                count = count + 1
                out[count] = value() -- by count, so a null keeps its place
                skip()
                local d = text:sub(pos, pos)
                pos = pos + 1
                if d == "]" then return out end
                if d ~= "," then fail("expected ',' or ']'") end
            end
        elseif c == '"' then
            return str()
        elseif text:sub(pos, pos + 3) == "true" then
            pos = pos + 4; return true
        elseif text:sub(pos, pos + 4) == "false" then
            pos = pos + 5; return false
        elseif text:sub(pos, pos + 3) == "null" then
            pos = pos + 4; return nil
        else
            local number = text:match("^-?%d+%.?%d*[eE]?[-+]?%d*", pos)
            if not number or number == "" then fail("unexpected '" .. c .. "'") end
            pos = pos + #number
            return tonumber(number)
        end
    end

    local result = value()
    skip()
    if pos <= #text then fail("text after the end") end
    return result
end

return M
