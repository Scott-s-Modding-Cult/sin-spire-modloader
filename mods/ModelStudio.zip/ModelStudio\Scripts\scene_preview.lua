-- Model Studio's sex scene previewer: a Free Mode partner in the studio with that character's own Free Mode scene list.
--
-- start(index) spawns the partner (the class Free Mode places) in front of the plinth, stops its AI and movement as Free
-- Mode's characters stand, then spawns a BP_SelectableSceneActor with the Scenes of the character's Free Mode dialogue
-- (DE_StartSceneSelector in /Game/Blueprints/AI/Enemies/FreemodeInfo/DIS_*), as that dialogue does. From there the game
-- runs it as in Free Mode: W/S stages, D the next scene, the climax and purification (the list ends the scene after it).
-- Only the game's own scenes (the user's choice): rows mods add to the lists (AnimationsPlus, NurseTouch's kiss, Ghost
-- Kiss's neck, Crawling Arm's stroke) are left out by name, and each list's rows are noted the moment the studio first
-- loads it, in the same step, before any mod's own loop can append to it. stop() calls the list's own EndAnyScene, which ends
-- the scene and puts both back. Once the list is gone the partner is removed.
-- Nothing is kept between ticks but addresses: objects are found again each time (a stale object can crash the game).

local UEHelpers = require("UEHelpers")

local M = {}

local ENEMIES = "/Game/Blueprints/AI/Enemies/"
-- Free Mode's characters: the name its level shows, the class it places there, and its scene list's dialogue.
M.PARTNERS = {
    { "Automaid", "BP_Automaid", "DIS_Automaid" },
    { "Banshee", "BP_Banshee", "DIS_Banshee" },
    { "Bound", "BP_SplitFace", "DIS_Bound" },
    { "Butcherette", "BP_Butcherette", "DIS_Butcher" },
    { "Leg Amalgam", "BP_Mannequin", "DIS_LegAmalgam" },
    { "Lost Soul", "BP_LostSoul", "DIS_Lost" },
    { "Smiler", "BP_Smiler", "DIS_Smiler" },
    { "Stone Virgin", "BP_StoneVirgin", "DIS_Stone" },
    { "Twisted", "BP_Twisted", "DIS_Twisted" },
    { "Twisted Nurse", "BP_TwistedNurse", "DIS_Twisted1" },
    { "Witness", "BP_Witness", "DIS_Witness" },
    { "Wraith", "BP_Wraith", "DIS_Wraith" },
    { "Creeper", "Stalkers/BP_CaveStalker", "DIS_BossCreeper" },
    { "Duchess", "Stalkers/BP_DuchessStalker", "DIS_BossDuchess" },
    { "Girlfriend", "Stalkers/BP_GirlfriendStalker", "DIS_BossGirlfriend" },
    { "Mangler", "Stalkers/BP_ManglerBoss", "DIS_BossMangler" },
    { "Slacker", "Stalkers/BP_SlackerBoss", "DIS_BossSlacker" },
    { "Witch", "Stalkers/BP_WitchBoss", "DIS_BossWitch" },
}
local LIST_CLASS = { "/Game/Blueprints/Player/Interactions/BP_SelectableSceneActor", "BP_SelectableSceneActor_C" }
local SPAWN_AHEAD_CM = 160.0
local CALM_SECONDS = 1.2 -- the partner lands and gets its controller before it is stilled and the list starts
local START_TIMEOUT = 8.0 -- the list must have started a scene by then
local MOD_ROW_PREFIXES = { "AP_" } -- Gooner DLC's AnimationsPlus player scenes
local MOD_ROWS = { NurseTouchKissBehind = true, GhostKissNeck = true, CrawlingArmStroke = true, CrawlingArmStrokeBehind = true }
local LEFTOVER_SECONDS = 3.0 -- after the scene ends, a list still there is removed
local SPAWN_POINT = { "/Game/Blueprints/Player/BP_PlayerSpawn", "BP_PlayerSpawn_C" }
local log = function() end

local run = nil -- { partner = address, partner_class, list = address, phase, since, name }
local originals = {} -- dialogue name -> { { DataTable = object, RowName = text }, ... }: the game's own rows

local function valid(object) return object ~= nil and object:IsValid() end
local function fname(text) return FName(text, EFindName.FNAME_Add) end
local function statics() return StaticFindObject("/Script/Engine.Default__GameplayStatics") end

local function load_asset(package, name)
    local found = StaticFindObject(package .. "." .. name)
    if valid(found) then return found end
    local ok, asset = pcall(function()
        return StaticFindObject("/Script/AssetRegistry.Default__AssetRegistryHelpers"):GetAsset({
            PackageName = fname(package), AssetName = fname(name) })
    end)
    if ok and valid(asset) then return asset end
    return nil
end

local function class_of(entry)
    local short = entry[2]:match("([^/]+)$")
    return load_asset(ENEMIES .. entry[2], short .. "_C"), short .. "_C"
end

local function selector_of(entry)
    load_asset(ENEMIES .. "FreemodeInfo/" .. entry[3], entry[3])
    local key = "/" .. entry[3] .. "." .. entry[3] .. ":"
    for _, de in ipairs(FindAllOf("DE_StartSceneSelector_C") or {}) do
        if valid(de) and de:GetFullName():find(key, 1, true) then return de end
    end
    return nil
end

local function is_mod_row(row_name)
    if MOD_ROWS[row_name] then return true end
    for _, prefix in ipairs(MOD_ROW_PREFIXES) do
        if row_name:sub(1, #prefix) == prefix then return true end
    end
    return false
end

-- The game's own rows of a character's list, noted the first time it is seen.
local function game_rows(entry)
    if originals[entry[3]] then return originals[entry[3]] end
    local de = selector_of(entry)
    if not de then return nil end
    local rows = {}
    for i = 1, de.Scenes:GetArrayNum() do
        local handle = de.Scenes[i]
        local row_name = handle.RowName:ToString()
        if not is_mod_row(row_name) then rows[#rows + 1] = { DataTable = handle.DataTable, RowName = row_name } end
    end
    originals[entry[3]] = rows
    return rows
end

local function find(class_name, address)
    if not address then return nil end
    for _, object in ipairs(FindAllOf(class_name) or {}) do
        if valid(object) and object:GetAddress() == address then return object end
    end
    return nil
end

local function partner() return run and find(run.partner_class, run.partner) end
local function list() return run and find(LIST_CLASS[2], run.list) end

-- Some scenes end in the player's Respawn. With no BP_PlayerSpawn in the level it saves and travels to the Starting
-- Hall (BP_PlayerCharacter.Respawn); with one, it puts the player back in place, as in Free Mode. So the studio gets one
-- where the player stands on arrival (the plinth).
function M.place_spawn_point(player)
    for _, existing in ipairs(FindAllOf(SPAWN_POINT[2]) or {}) do
        if valid(existing) then return true end
    end
    local class = load_asset(SPAWN_POINT[1], SPAWN_POINT[2])
    if not class then log("No BP_PlayerSpawn class") return false end
    local spot = UEHelpers.GetWorld():SpawnActor(class, player:K2_GetActorLocation(), player:K2_GetActorRotation())
    log(valid(spot) and "Placed a player spawn point on the plinth" or "Could not place a player spawn point")
    return valid(spot)
end

-- Loads the Free Mode dialogues, so their lists exist (and Gooner DLC can add its AnimationsPlus rows to them).
function M.preload()
    for _, entry in ipairs(M.PARTNERS) do
        pcall(game_rows, entry)
    end
end

function M.init(log_fn) log = log_fn end
function M.running() return run ~= nil end
function M.name() return run and run.name or nil end

-- Where the orbit camera looks during a scene: between the two.
function M.focus(player)
    local p = partner()
    if not (p and valid(player)) then return nil end
    local a, b = player:K2_GetActorLocation(), p:K2_GetActorLocation()
    return { X = (a.X + b.X) / 2, Y = (a.Y + b.Y) / 2, Z = (a.Z + b.Z) / 2 }
end

local function remove_partner()
    local p = partner()
    if p then pcall(function() p:K2_DestroyActor() end) end
end

function M.start(index, player)
    local entry = M.PARTNERS[index]
    if not entry then return false, "no such partner" end
    if run then return false, "a preview is already running" end
    local rows = game_rows(entry)
    if not rows or #rows == 0 then return false, "no Free Mode scene list for " .. entry[1] end
    local class, class_name = class_of(entry)
    if not class then return false, "could not load " .. entry[2] end
    local at, rot = player:K2_GetActorLocation(), player:K2_GetActorRotation()
    local yaw = math.rad(rot.Yaw)
    local spot = { X = at.X + math.cos(yaw) * SPAWN_AHEAD_CM, Y = at.Y + math.sin(yaw) * SPAWN_AHEAD_CM, Z = at.Z + 10.0 }
    local p = UEHelpers.GetWorld():SpawnActor(class, spot, { Pitch = 0.0, Yaw = rot.Yaw + 180.0, Roll = 0.0 })
    if not valid(p) then return false, "could not spawn " .. entry[1] end
    pcall(function() if not valid(p.Controller) then p:SpawnDefaultController() end end)
    run = { partner = p:GetAddress(), partner_class = class_name, phase = "calm", since = os.clock(), name = entry[1],
            entry = entry }
    log("Scene preview: " .. entry[1] .. " is here")
    return true
end

function M.stop()
    if not run then return end
    local l = list()
    if l then
        pcall(function() l:EndAnyScene() end)
        log("Scene preview: ending the scene")
        run.phase = "ending"
        run.since = os.clock()
    else
        remove_partner()
        run = nil
        log("Scene preview: stopped")
    end
end

-- From the mod's loop. Returns true while a preview runs.
function M.tick(player)
    if not run then return false end
    local p = partner()
    if run.phase == "calm" then
        if not p then log("Scene preview: the partner is gone") run = nil return false end
        if os.clock() - run.since < CALM_SECONDS then return true end
        pcall(function() p.Controller.BrainComponent:StopLogic("Model Studio") end)
        pcall(function() p.CharacterMovement:DisableMovement() end)
        local rows = game_rows(run.entry)
        local class = load_asset(LIST_CLASS[1], LIST_CLASS[2])
        if not (rows and class) then
            log("Scene preview: no scene list")
            remove_partner()
            run = nil
            return false
        end
        local transform = p:GetTransform()
        local l = statics():BeginDeferredActorSpawnFromClass(p, class, transform, 1, nil, 1)
        local count = 0
        for _, row in ipairs(rows) do
            if valid(row.DataTable) then
                count = count + 1
                l.Scenes[count] = { DataTable = row.DataTable, RowName = fname(row.RowName) }
            end
        end
        l.Actor = p
        statics():FinishSpawningActor(l, transform, 1)
        run.list = l:GetAddress()
        run.phase = "starting"
        run.since = os.clock()
        log(("Scene preview: %s, %d of the game's scenes (D next, W/S stages)"):format(run.name, count))
    elseif run.phase == "starting" then
        if valid(player) and player.InInteraction then
            run.phase = "playing"
        elseif os.clock() - run.since > START_TIMEOUT then
            log("Scene preview: the scene did not start")
            M.stop()
        end
    elseif run.phase == "playing" or run.phase == "ending" then
        -- The list ends the scene after Purification (and on stop) and usually removes itself (SetLifeSpan 2), but not
        -- always: once the scene has been over for a moment, whatever is left of it goes, then the partner.
        local l = list()
        local in_scene = valid(player) and player.InInteraction
        if in_scene then
            run.over_at = nil
        else
            run.over_at = run.over_at or os.clock()
            if not l or os.clock() - run.over_at > LEFTOVER_SECONDS then
                if l then pcall(function() l:K2_DestroyActor() end) end
                remove_partner()
                log("Scene preview: over")
                run = nil
                return false
            end
        end
    end
    return true
end

return M
