-- Model Studio: a solo room for looking at your player (and a Skin Kit skin) from every side. PC: keyboard and mouse.
--
-- Main menu > Extras > Model Studio, or Admin Panel > Model Studio > "Enter the Model Studio", opens the studio map (/Game/Mods/ModelStudio/L_ModelStudio, a
-- round grey photo studio with a plinth); "Leave the Model Studio" goes back to the main menu. In the studio:
--   F5 or middle mouse   view: First person > Orbit > Freecam (it starts in Orbit, in front of you)
--   Orbit                mouse turns round the player, wheel zooms, W/S raise and lower the view, A/D turn round
--   Freecam              WASD and mouse, Space/E up, Ctrl/Q down, Shift faster, Alt slower, wheel changes the speed
--   F6                   pose: Game idle / Rest pose (the bind pose skins are made in)
--   F7                   turntable on / off
--   F8                   skin: Auto (as the game shows it) / as worn / as in a sex scene (Skin Swapper)
--   F9                   sex scene preview: start with the partner chosen in the tab, or stop
-- The same settings are rows of the Admin Panel tab, with the scene partner (Free Mode's characters).
-- A scene preview (scene_preview.lua) is the partner's own Free Mode scene list: the game runs the scene (W/S stages,
-- D next scene, climax, purification). Meanwhile the studio leaves the bodies to the scene: Orbit circles both, and
-- pose and turntable wait until it is over.
--
-- How: Orbit and Freecam look through a camera actor of this mod (the view target), turned by the game's own control
-- rotation, so the game's mouse sensitivity and Invert Y apply. Meanwhile the body stays put: its movement is switched
-- off (MOVE_None) and it no longer turns with the control rotation (bUseControllerRotationYaw). The third-person body is
-- shown in play anyway, hidden only from the player's own camera (owner no see), so from this camera it is seen as it
-- is; the first-person body is hidden. First person puts everything back. The Skin Swapper reads ModelStudio_View.

local UEHelpers = require("UEHelpers")
local AdminTabs = require("AdminTabs")
local extras_row = require("extras_row")
local scenes = require("scene_preview")

local NAME = "ModelStudio"
local MAP_PATH = "/Game/Mods/ModelStudio/L_ModelStudio"
local MAP_NAME = "L_ModelStudio"
local MENU_MAP = "/Game/MenuMap" -- the map the game starts in
local PLAYER_CLASS = "/Game/Blueprints/Player/BP_PlayerCharacter.BP_PlayerCharacter_C"
local COMMON_LIBRARY = "/Game/Blueprints/BPFL_CommonFunctions.Default__BPFL_CommonFunctions_C"
local VIEW_VARIABLE = "ModelStudio_View" -- "worn" / "scene" for the Skin Swapper, "" for the game's own state
local STATE_VARIABLE = "ModelStudio_State" -- for tests
local LOOP_MS = 100
local SETTLE_SECONDS = 0.6 -- after the studio map loads, before the studio takes over the view

local VIEWS = { "First person", "Orbit", "Freecam" }
local FIRST_PERSON, ORBIT, FREECAM = 0, 1, 2
local POSES = { "Game idle", "Rest pose" }
local GAME_IDLE, REST_POSE = 0, 1
local SHOWS = { "Auto", "As worn", "As in a sex scene" }
local AUTO, AS_WORN, AS_SCENE = 0, 1, 2
local ANIMATION_BLUEPRINT, SINGLE_NODE = 0, 1 -- EAnimationMode
local MOVE_WALKING = 1

local FOV = 60.0
local ORBIT_START = { distance = 330.0, height = 0.0, pitch = -4.0 } -- the whole body in view
local ORBIT_DISTANCE = { 80.0, 650.0 }
local ORBIT_HEIGHT = { -95.0, 95.0 }
local ORBIT_HEIGHT_SPEED = 90.0 -- cm/s with W/S
local ORBIT_TURN_SPEED = 90.0 -- degrees/s with A/D
local FREE_SPEED = { start = 250.0, min = 40.0, max = 1500.0 }
local FAST, SLOW = 3.0, 0.3
local TURNTABLE_DEGREES = 30.0 -- per second
local MESSAGE_COLOUR = { R = 0.99, G = 0.99, B = 0.99, A = 1.0 }

local function log(message) print("[" .. NAME .. "] " .. tostring(message) .. "\n") end
local function valid(object) return object ~= nil and object:IsValid() end

local names = {}
local function fname(text)
    local made = names[text]
    if not made then
        made = UEHelpers.FindOrAddFName(text)
        names[text] = made
    end
    return made
end

local keys = {}
local function key(text)
    local struct = keys[text]
    if not struct then
        struct = { KeyName = fname(text) }
        keys[text] = struct
    end
    return struct
end
local function down(pc, k) local ok, v = pcall(function() return pc:IsInputKeyDown(key(k)) end) return ok and v == true end
local function pressed(pc, k) local ok, v = pcall(function() return pc:WasInputKeyJustPressed(key(k)) end) return ok and v == true end

-- The game's own movement axes (so a rebinding in its Controls menu carries over), with W/S/A/D as a fallback.
local RAW = { MoveForward = { { "W", 1.0 }, { "S", -1.0 } }, MoveRight = { { "D", 1.0 }, { "A", -1.0 } } }
local function axis(pc, axis_name)
    local ok, value = pcall(function() return pc:GetInputAxisValue(fname(axis_name)) end)
    value = ok and tonumber(value) or 0.0
    if value ~= 0.0 then return value end
    for _, entry in ipairs(RAW[axis_name]) do
        if down(pc, entry[1]) then value = value + entry[2] end
    end
    return value
end

local function statics() return StaticFindObject("/Script/Engine.Default__GameplayStatics") end
local function level_name()
    local ok, name = pcall(function() return statics():GetCurrentLevelName(UEHelpers.GetWorld(), true):ToString() end)
    return ok and name or ""
end
local function paused()
    local ok, yes = pcall(function() return statics():IsGamePaused(UEHelpers.GetWorld()) end)
    return ok and yes == true
end
local function find_player()
    local player = FindFirstOf("BP_PlayerCharacter_C")
    if valid(player) then return player end
end
local function clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end
local function signed(angle) angle = angle % 360 if angle > 180 then angle = angle - 360 end return angle end

local function message(player, text)
    pcall(function() StaticFindObject(COMMON_LIBRARY):ShowHudMessage(FText(text), MESSAGE_COLOUR, player) end)
end

-- ------------------------------------------------------------------------------------------------------------- state

local settings = { view = ORBIT, pose = GAME_IDLE, turntable = false, show = AUTO, partner = 10 } -- Twisted Nurse
local studio = {
    active = false,      -- the studio map is loaded and the studio has taken over
    player = nil,
    since = nil,         -- when the studio map and its player were first seen
    camera = nil,
    orbit = nil,         -- { distance, height }
    free = nil,          -- { location, speed }
    saved = nil,         -- what first person puts back: { use_yaw, fp_visible }
    view = FIRST_PERSON, -- the view in effect
    pose = GAME_IDLE,
}
local pending = nil -- "enter" / "leave" / "scene" / "stop", done once the game is running again (the Admin Panel pauses it)

local function publish()
    local view = ""
    if studio.active and settings.show == AS_WORN then view = "worn" end
    if studio.active and settings.show == AS_SCENE then view = "scene" end
    ModRef:SetSharedVariable(VIEW_VARIABLE, view)
    ModRef:SetSharedVariable(STATE_VARIABLE, table.concat({ tostring(studio.active), VIEWS[studio.view + 1],
        POSES[studio.pose + 1], tostring(settings.turntable), SHOWS[settings.show + 1], scenes.name() or "no scene" }, "|"))
end

local function hint(player)
    local text
    if studio.view == ORBIT then
        text = "Model Studio, Orbit: mouse turns, wheel zooms, W/S height, A/D turn. F5 view, F6 pose, F7 turntable, F8 skin"
    elseif studio.view == FREECAM then
        text = "Model Studio, Freecam: WASD and mouse, Space/E up, Ctrl/Q down, Shift faster, wheel speed. F5 view"
    else
        text = "Model Studio, first person. F5 or middle mouse: Orbit and Freecam"
    end
    message(player, text)
end

-- ----------------------------------------------------------------------------------------------------------- camera

local function control_rotation(pc)
    local r = pc:GetControlRotation()
    return { Pitch = signed(r.Pitch), Yaw = r.Yaw, Roll = 0.0 }
end

local function forward_of(rotation)
    local p, y = math.rad(rotation.Pitch), math.rad(rotation.Yaw)
    return { X = math.cos(p) * math.cos(y), Y = math.cos(p) * math.sin(y), Z = math.sin(p) }
end

local function orbit_transform(player, pc)
    local rotation = control_rotation(pc)
    rotation.Pitch = clamp(rotation.Pitch, -70.0, 70.0)
    local at = (player.InInteraction and scenes.focus(player)) or player:K2_GetActorLocation()
    local f = forward_of(rotation)
    local target = { X = at.X, Y = at.Y, Z = at.Z + studio.orbit.height }
    local d = studio.orbit.distance
    return { X = target.X - f.X * d, Y = target.Y - f.Y * d, Z = target.Z - f.Z * d }, rotation
end

local function place_camera(location, rotation)
    if valid(studio.camera) then
        pcall(function() studio.camera:K2_SetActorLocationAndRotation(location, rotation, false, {}, false) end)
    end
end

local function ensure_camera(pc, location, rotation)
    if not valid(studio.camera) then
        studio.camera = UEHelpers.GetWorld():SpawnActor(StaticFindObject("/Script/Engine.CameraActor"), location, rotation)
        pcall(function() studio.camera.CameraComponent.FieldOfView = FOV end)
        pcall(function() studio.camera.CameraComponent.bConstrainAspectRatio = false end)
        -- The player camera's own post-process (exposure and the game's look), so both views match.
        pcall(function()
            local fp_camera = studio.player["FP Camera"]
            studio.camera.CameraComponent.PostProcessSettings = fp_camera.PostProcessSettings
            studio.camera.CameraComponent.PostProcessBlendWeight = fp_camera.PostProcessBlendWeight
        end)
    end
    place_camera(location, rotation)
    pc:SetViewTargetWithBlend(studio.camera, 0.25, 0, 0.0, false)
end

-- Holds the body still and hides the first-person body, keeping what first person puts back.
local function hold_body(player)
    if studio.saved or player.InInteraction then return end
    local fp_visible = true
    pcall(function() fp_visible = player["FP Viewport Mesh"]:IsVisible() end)
    studio.saved = { use_yaw = player.bUseControllerRotationYaw, fp_visible = fp_visible }
    player.bUseControllerRotationYaw = false
    pcall(function() player.CharacterMovement:DisableMovement() end)
    pcall(function() player["FP Viewport Mesh"]:SetVisibility(false, true) end)
end

local function release_body(player, pc)
    if not studio.saved then return end
    if valid(player) then
        player.bUseControllerRotationYaw = studio.saved.use_yaw
        pcall(function() player.CharacterMovement:SetMovementMode(MOVE_WALKING, 0) end)
        pcall(function() player["FP Viewport Mesh"]:SetVisibility(studio.saved.fp_visible, true) end)
        -- First person looks the way the body faces, as it did before.
        if valid(pc) then
            local yaw = player:K2_GetActorRotation().Yaw
            pc:SetControlRotation({ Pitch = 0.0, Yaw = yaw, Roll = 0.0 })
        end
    end
    studio.saved = nil
end

local function set_view(view)
    local player = studio.player
    local pc = valid(player) and player.Controller or nil
    if not studio.active or not valid(pc) then return end
    local before = studio.view
    studio.view = view
    if view == FIRST_PERSON then
        if valid(studio.camera) then
            pc:SetViewTargetWithBlend(player, 0.25, 0, 0.0, false)
        end
        release_body(player, pc)
    else
        hold_body(player)
        if view == ORBIT then
            if before ~= ORBIT then
                studio.orbit = studio.orbit or { distance = ORBIT_START.distance, height = ORBIT_START.height }
                if before == FIRST_PERSON then
                    -- In front of the player, looking at them.
                    local yaw = player:K2_GetActorRotation().Yaw + 180.0
                    pc:SetControlRotation({ Pitch = ORBIT_START.pitch, Yaw = yaw, Roll = 0.0 })
                end
            end
            local location, rotation = orbit_transform(player, pc)
            ensure_camera(pc, location, rotation)
        else
            local location
            if valid(studio.camera) then
                location = studio.camera:K2_GetActorLocation()
            else
                location, _ = orbit_transform(player, pc)
            end
            studio.free = { location = location, speed = (studio.free and studio.free.speed) or FREE_SPEED.start }
            ensure_camera(pc, location, control_rotation(pc))
        end
    end
    settings.view = view
    AdminTabs.SetChoice(NAME, 1, view)
    publish()
    hint(player)
    log("View: " .. VIEWS[view + 1])
end

local function set_pose(pose)
    local player = studio.player
    settings.pose = pose
    AdminTabs.SetChoice(NAME, 2, pose)
    if not studio.active or not valid(player) then return end
    if player.InInteraction then return end -- the scene drives the body
    local mesh = player.Mesh
    if pose == REST_POSE then
        pcall(function() mesh:SetAnimationMode(SINGLE_NODE, true) end)
    else
        pcall(function() mesh:SetAnimationMode(ANIMATION_BLUEPRINT, true) end)
    end
    studio.pose = pose
    publish()
    log("Pose: " .. POSES[pose + 1])
end

local function set_turntable(on)
    settings.turntable = on
    AdminTabs.SetChoice(NAME, 3, on and 1 or 0)
    publish()
    log("Turntable: " .. (on and "on" or "off"))
end

local function set_show(show)
    settings.show = show
    AdminTabs.SetChoice(NAME, 4, show)
    publish()
    log("Skin shown " .. SHOWS[show + 1]:lower())
end

-- --------------------------------------------------------------------------------------------- the studio, per frame

local function frame(player, dt)
    if not studio.active or not valid(player) or player:GetAddress() ~= (studio.player and studio.player:GetAddress()) then
        return
    end
    local pc = player.Controller
    if not valid(pc) then return end
    -- In a scene the middle mouse is the game's own perspective switch, so only F5 changes the studio's view there.
    if pressed(pc, "F5") or (not player.InInteraction and pressed(pc, "MiddleMouseButton")) then set_view((studio.view + 1) % #VIEWS) end
    if pressed(pc, "F9") then pending = scenes.running() and "stop" or "scene" end
    if pressed(pc, "F6") then set_pose((studio.pose + 1) % #POSES) end
    if pressed(pc, "F7") then set_turntable(not settings.turntable) end
    if pressed(pc, "F8") then set_show((settings.show + 1) % #SHOWS) end

    if studio.view == ORBIT then
        local o = studio.orbit
        if pressed(pc, "MouseScrollUp") then o.distance = clamp(o.distance * 0.88, ORBIT_DISTANCE[1], ORBIT_DISTANCE[2]) end
        if pressed(pc, "MouseScrollDown") then o.distance = clamp(o.distance / 0.88, ORBIT_DISTANCE[1], ORBIT_DISTANCE[2]) end
        o.height = clamp(o.height + axis(pc, "MoveForward") * ORBIT_HEIGHT_SPEED * dt, ORBIT_HEIGHT[1], ORBIT_HEIGHT[2])
        local turn = axis(pc, "MoveRight")
        if turn ~= 0.0 then
            local r = control_rotation(pc)
            pc:SetControlRotation({ Pitch = r.Pitch, Yaw = r.Yaw - turn * ORBIT_TURN_SPEED * dt, Roll = 0.0 })
        end
        place_camera(orbit_transform(player, pc))
    elseif studio.view == FREECAM then
        local free = studio.free
        if pressed(pc, "MouseScrollUp") then free.speed = clamp(free.speed * 1.25, FREE_SPEED.min, FREE_SPEED.max) end
        if pressed(pc, "MouseScrollDown") then free.speed = clamp(free.speed / 1.25, FREE_SPEED.min, FREE_SPEED.max) end
        local rotation = control_rotation(pc)
        local f = forward_of(rotation)
        local yaw = math.rad(rotation.Yaw)
        local right = { X = -math.sin(yaw), Y = math.cos(yaw) }
        local fwd, side = axis(pc, "MoveForward"), axis(pc, "MoveRight")
        local up = ((down(pc, "SpaceBar") or down(pc, "E")) and 1.0 or 0.0) - ((down(pc, "LeftControl") or down(pc, "Q")) and 1.0 or 0.0)
        local speed = free.speed * (down(pc, "LeftShift") and FAST or 1.0) * (down(pc, "LeftAlt") and SLOW or 1.0) * dt
        local l = free.location
        free.location = { X = l.X + (f.X * fwd + right.X * side) * speed, Y = l.Y + (f.Y * fwd + right.Y * side) * speed,
                          Z = l.Z + (f.Z * fwd + up) * speed }
        place_camera(free.location, rotation)
    end

    if settings.turntable and studio.view ~= FIRST_PERSON and not player.InInteraction then
        local r = player:K2_GetActorRotation()
        pcall(function() player:K2_SetActorRotation({ Pitch = 0.0, Yaw = r.Yaw + TURNTABLE_DEGREES * dt, Roll = 0.0 }, false) end)
    end
end

local hooked = false
local function hook_frame()
    if hooked then return end
    local ok = pcall(RegisterHook, PLAYER_CLASS .. ":ReceiveTick", function(context, delta)
        local ok_frame, problem = pcall(frame, context:get(), delta:get())
        if not ok_frame then log("Frame error: " .. tostring(problem)) end
    end)
    hooked = ok
    if ok then log("Hooked the player's tick") end
end

-- --------------------------------------------------------------------------------------------------- level changes

local function enter_studio(player)
    studio.active, studio.player = true, player
    studio.view, studio.pose, studio.saved, studio.camera, studio.orbit, studio.free = FIRST_PERSON, GAME_IDLE, nil, nil, nil, nil
    log("In the studio")
    scenes.place_spawn_point(player)
    scenes.preload()
    set_pose(settings.pose)
    set_view(settings.view)
    publish()
end

local function leave_studio()
    if studio.active then log("Out of the studio") end
    if scenes.running() then scenes.stop() end
    studio.active, studio.player, studio.camera, studio.saved, studio.since = false, nil, nil, nil, nil
    studio.view = FIRST_PERSON
    publish()
end

local function start_scene()
    local player = studio.player
    if not studio.active or not valid(player) then log("Scene preview: enter the Model Studio first") return end
    -- The scene places and moves the body, so the studio lets go of it (the view stays).
    if studio.pose ~= GAME_IDLE then set_pose(GAME_IDLE) end
    release_body(player, player.Controller)
    local ok, problem = scenes.start(settings.partner + 1, player)
    if not ok then
        log("Scene preview: " .. tostring(problem))
        if studio.view ~= FIRST_PERSON then hold_body(player) end
    else
        message(player, "Scene preview: " .. scenes.name() .. ". W/S stages, D next scene, F9 or Stop to end, F5 views")
    end
end

local function open(map)
    local ok, problem = pcall(function() statics():OpenLevel(UEHelpers.GetWorld(), fname(map), true, "") end)
    log((ok and "Opening " or "Could not open ") .. map .. (ok and "" or (": " .. tostring(problem))))
end

local main_menu_checks = 0

local function tick()
    AdminTabs.Poll()
    -- The Extras row: in the main menu only (it is where the list is), every half second.
    main_menu_checks = main_menu_checks + 1
    if main_menu_checks % 5 == 0 and level_name():lower():find("menu") then extras_row.tick() end
    if pending and not paused() then
        local what = pending
        pending = nil
        if what == "scene" then start_scene()
        elseif what == "stop" then scenes.stop()
        else open(what == "enter" and MAP_PATH or MENU_MAP) end
        return
    end
    local in_map = level_name() == MAP_NAME
    local player = in_map and find_player() or nil
    if studio.active and (not in_map or not valid(studio.player) or (player and player:GetAddress() ~= studio.player:GetAddress())) then
        leave_studio()
    end
    if studio.active then
        publish() -- the scene's name and the studio's state, for tests
        local was = scenes.running()
        local running = scenes.tick(studio.player)
        if was and not running and valid(studio.player) and not studio.player.InInteraction and studio.view ~= FIRST_PERSON then
            hold_body(studio.player) -- the scene is over: back to holding the body for Orbit and Freecam
        end
    end
    if in_map and player and not studio.active then
        hook_frame()
        studio.since = studio.since or os.clock()
        if os.clock() - studio.since >= SETTLE_SECONDS and valid(player.Controller) then
            enter_studio(player)
        end
    end
end

-- ------------------------------------------------------------------------------------------------------- admin tab

local tab = AdminTabs.AddTab({ id = NAME, title = "Model Studio" })
tab:AddChoice("View", VIEWS, settings.view, function(index) if studio.active then set_view(index) else settings.view = index end end)
tab:AddChoice("Pose", POSES, settings.pose, function(index) set_pose(index) end)
tab:AddChoice("Turntable", { "Off", "On" }, 0, function(index) set_turntable(index == 1) end)
tab:AddChoice("Show skin", SHOWS, settings.show, function(index) set_show(index) end)
local partner_names = {}
for i, entry in ipairs(scenes.PARTNERS) do partner_names[i] = entry[1] end
tab:AddChoice("Scene partner", partner_names, settings.partner, function(index) settings.partner = index end)
tab:AddButton("Enter the Model Studio", function()
    if level_name() == MAP_NAME then log("Already in the studio") return end
    pending = "enter"
end)
tab:AddButton("Leave the Model Studio", function()
    if level_name() ~= MAP_NAME then log("Not in the studio") return end
    pending = "leave"
end)
tab:AddButton("Start scene preview", function() pending = "scene" end)
tab:AddButton("Stop scene preview", function() pending = "stop" end)

scenes.init(log)
extras_row.init(log, function()
    if level_name() == MAP_NAME then return end
    pending = "enter"
end)
publish()
local errors = 0
LoopInGameThreadWithDelay(LOOP_MS, function()
    local ok, problem = pcall(tick)
    if not ok then
        errors = errors + 1
        if errors <= 5 then log("Error: " .. tostring(problem)) end
    end
end)
log("Loaded: main menu > Extras > Model Studio, or Admin Panel > Model Studio > Enter the Model Studio")
