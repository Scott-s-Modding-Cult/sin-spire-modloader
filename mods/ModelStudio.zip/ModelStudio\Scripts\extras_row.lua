-- Model Studio's row in the main menu's Extras list, made the way the Multiplayer Hub makes its row (mp_browser.lua):
-- a row added to the game's own Extras table (DT_ExtraStuff, copied from its Free Mode row, so it has the game's look),
-- whose button fires the event ModelStudio through the game's event manager. Menus built after the row exists list it
-- themselves; the main menu is built before any mod runs, so its button is added by hand and that menu is told to
-- listen for the event. Pressing it calls on_press (the studio opens once the game runs).

local UEHelpers = require("UEHelpers")

local M = {}

local EVENT = "ModelStudio"
local ROW = "ModelStudio"
local EXTRAS_TABLE = "/Game/Blueprints/UI/Menu/ExtraMenu/DT_ExtraStuff"
local EXTRAS_MENU_CLASS = "/Game/Blueprints/UI/Menu/ExtraMenu/BPW_ExtrasMenu.BPW_ExtrasMenu_C"
local EXTRAS_BUTTON_CLASS = "/Game/Blueprints/UI/Menu/ExtraMenu/BPW_ExtrasButton.BPW_ExtrasButton_C"
local F = { -- struct_ExtraSubInfo, the Extras table's row
    title = "Title_2_EDCEDE2244B5AF528CE50EB5F62A689A",
    description = "Description_4_B5CA21FF462981C8D219CC9A73D2C779",
    unlocked = "UnlockStatus_10_0803761C40DC8DAD8944BFAC236B2FF9",
    soon = "ComingSoon_14_A26FDD4E41EDFC1F43DFABB8835FAD5B",
    event = "EventToFire_17_028E7FA0494A842EF633D5AD5696555D",
    message = "MessageForEvent_19_243A5F2545F6E2FDFE53F18A66376D8B",
    reqs = "UnlockReqs_22_039CC82148B39083771A91A1ADE0F9D6",
    submenu = "SubmenuName_28_2BAF52C94BBFD05333A157B3F5E53691",
    req_info = "UnlockRequirementInfo_30_7AA24CA34D795707E771639122A12DC5",
    stat = "TrackedMetaStat_36_8D3C4DD34877DDC5FDA495ABAA9B997B",
    stat_text = "StatText_39_E92EFD61456400EA8C92ADA97FE81339",
}
local ENTRY = {
    title = "Model Studio",
    body = "A grey studio room on your own: look at your player from every side, and preview the game's sex scenes.",
    message = "enter",
}
local COLLAPSED = 1 -- ESlateVisibility
local ACTIVE_TINT = { R = 1.0, G = 1.0, B = 1.0, A = 1.0 }
local SAME_PRESS_SECONDS = 0.4 -- every Extras menu listening hears one press

local log = function() end
local on_press = function() end
local row_added, hooked = false, false
local last_press = -1

local function valid(object) return object ~= nil and object:IsValid() end
local function fname(text) return FName(text, EFindName.FNAME_Add) end
local function widget_library() return StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end

local function load_object(package, name)
    local found = StaticFindObject(package .. "." .. name)
    if valid(found) then return found end
    local ok, loaded = pcall(function()
        return StaticFindObject("/Script/AssetRegistry.Default__AssetRegistryHelpers"):GetAsset({
            PackageName = fname(package), AssetName = fname(name) })
    end)
    if ok and valid(loaded) then return loaded end
    return nil
end

local function extras_table() return load_object(EXTRAS_TABLE, "DT_ExtraStuff") end

local function fill(entry_struct)
    entry_struct[F.title] = FText(ENTRY.title)
    entry_struct[F.description] = FText(ENTRY.body)
    entry_struct[F.unlocked] = true
    entry_struct[F.soon] = false
    entry_struct[F.event] = EVENT
    entry_struct[F.message] = ENTRY.message
    entry_struct[F.reqs] = FText("")
    entry_struct[F.submenu] = ""
    entry_struct[F.req_info] = ""
    entry_struct[F.stat] = ""
    entry_struct[F.stat_text] = FText("")
end

local function ensure_table_row()
    if row_added then return end
    local dt = extras_table()
    if not dt then return end
    if not dt:FindRow(ROW) then
        local source = dt:FindRow("FreeMode")
        if not source then return end
        dt:AddRow(ROW, source)
    end
    fill(dt:FindRow(ROW))
    row_added = true
    log("Extras row added")
end

local function is_ours(button)
    local ok, event = pcall(function() return button.AssociatedEntry[F.event]:ToString() end)
    return ok and event == EVENT
end

-- The main menu's Extras list, built before the row existed: our button at the end of it, and the menu listening.
local function ensure_main_row(extras)
    local start = extras.StartingMenu
    for i = 0, start:GetChildrenCount() - 1 do
        if is_ours(start:GetChildAt(i)) then return end
    end
    local class = StaticFindObject(EXTRAS_BUTTON_CLASS)
    if not valid(class) then
        load_object("/Game/Blueprints/UI/Menu/ExtraMenu/BPW_ExtrasButton", "BPW_ExtrasButton_C")
        class = StaticFindObject(EXTRAS_BUTTON_CLASS)
    end
    if not valid(class) then return end
    local button = widget_library():Create(extras, class, nil)
    if not valid(button) then return end
    local template = extras_table() and extras_table():FindRow(ROW)
    if template then button.AssociatedEntry = template end
    fill(button.AssociatedEntry)
    start:AddChild(button)
    -- The button's Construct copies its texts only once, so they are set here.
    pcall(function() button.Title:SetText(FText(ENTRY.title)) end)
    pcall(function() button.Body:SetText(FText(ENTRY.body)) end)
    pcall(function() button.Requirements:SetVisibility(COLLAPSED) end)
    pcall(function() button.Status:SetVisibility(COLLAPSED) end)
    pcall(function() button.Button_68:SetColorAndOpacity(ACTIVE_TINT) end)
    StaticFindObject("/Script/EasyEventSystem.Default__EasyEventManagerLibrary"):BindEvent(UEHelpers.GetWorld(), fname(EVENT), extras)
    log("Added the Model Studio row to the main menu's Extras")
end

local function hook()
    if hooked then return end
    hooked = pcall(RegisterHook, EXTRAS_MENU_CLASS .. ":OnEventCalled", function(_, event, message)
        local ok, problem = pcall(function()
            if event:get():ToString() ~= EVENT then return end
            if message:get():ToString() ~= ENTRY.message then return end
            if os.clock() - last_press < SAME_PRESS_SECONDS then return end
            last_press = os.clock()
            log("Extras > Model Studio pressed")
            on_press()
        end)
        if not ok then log("Extras row error: " .. tostring(problem)) end
    end)
end

function M.init(log_fn, press_fn)
    log, on_press = log_fn, press_fn
end

-- From the mod's game-thread loop.
function M.tick()
    pcall(ensure_table_row)
    hook()
    for _, pause in ipairs(FindAllOf("BPW_PauseMenu_C") or {}) do
        if valid(pause) and pause.IsStartMenu then
            local ok, extras = pcall(function() return pause.BPW_ExtrasMenu end)
            if ok and valid(extras) and valid(extras.StartingMenu) then pcall(ensure_main_row, extras) end
        end
    end
end

return M
