-- Scene picker: during a scene from one of Free Mode's scene lists, Tab (the game's Inventory key; Y on a controller)
-- opens a panel listing every scene in that list. Clicking one (or A on it) switches to it, so there is no need to step
-- through the list with A/D. Tab, Esc, B, or a click outside the panel closes it.
--
-- How it sits on the game: the list is a BP_SelectableSceneActor (its Scenes are data table rows, CurrentIndex is the one
-- playing) with a BPW_SelectableSexMenu along the bottom of the screen. A/D call the menu's IncreaseIndexToNewScene,
-- which steps CurrentIndex by one and calls the list's StartNewScene (fade out, the next scene, fade in) and moves its
-- label. To jump straight to a scene, the picker puts CurrentIndex next to it and lets IncreaseIndexToNewScene take that
-- one step, so the game's own switch, transition guard and label all run as they do for A/D. (The list sets CurrentIndex
-- itself once the new scene starts.)
-- During a sex scene the HUD is on its scene page, where Tab does nothing in the game, so the key is free there. It is
-- caught with a hook on the controller's Inventory input, which also answers to the controller's Y.
--
-- While the panel is open the controller and the player take no input (as the Admin Panel does), so a click on the panel
-- does not also reach the scene, whose left click is its special action, and W/S/A/D step nothing. The scene keeps
-- playing behind it. The panel is hosted in a game menu button whose contents are replaced (UserWidget itself cannot be
-- made from Lua), as the Admin Panel does. Nothing keeps a game object between ticks.
--
-- It looks like the scene list's own box at the top right of the screen (values read from BPW_SelectableSexMenu in the
-- running game): a 25% black fill under the shop's 9-slice frame (ShopItemFrame), the game's VTC Switchblade Romance font
-- in white at 18 (15 for the "Scenes:" label) with no outline or shadow, and key badges from the game's input prompt
-- textures, with the HUD prompts' glow (M_UIGlow) under the hint box. Each scene is one such box. Underneath, each is
-- still the game's menu button, so its click can be hooked, restyled: the fill instead of its grey rounded box, a faint
-- white wash instead of its brush stroke when the mouse or the controller's highlight is on it, and its text turning the
-- game's red then, as its menus do. The scene playing now has a faint red wash, a red frame and a red number. (The HUD's
-- glow material drew as a hard-edged bar across a row, so rows use flat washes.)

local UEHelpers = require("UEHelpers")
local scene_name = require("scene_names")
local has_pad, Pad = pcall(require, "Pad")

local CONTROLLER_CLASS = "/Game/Blueprints/Player/BP_PlayerController.BP_PlayerController_C"
local INVENTORY_HOOK = CONTROLLER_CLASS .. ":InpActEvt_Inventory_K2Node_InputActionEvent_8"
local BUTTON_CLASS = "/Game/Blueprints/UI/Menu/BPW_GenericMenuButton.BPW_GenericMenuButton_C"
local BUTTON_SHORT_CLASS = "BPW_GenericMenuButton_C"
local BUTTON_PRESSED_HOOK = BUTTON_CLASS
    .. ":BndEvt__BPW_GenericMenuButton_Button_14_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature"
local SELECTOR_CLASS = "BP_SelectableSceneActor_C"
local LIST_MENU_CLASS = "BPW_SelectableSexMenu_C"
local NAME_FIELD = "Name_2_238638F249DE6D7D55C2828B6A7E9B20"
local OPEN_VARIABLE = "GoonerDLC_ScenePickerOpen" -- true while open; Freecam holds still then
local PROMPT_VARIABLE = "ScenePicker_PromptShown" -- true while the Tab prompt is on the HUD, for tests
local TEST_VARIABLE = "ScenePicker_Test" -- for tests: "open", "open_pad" (as with a controller), "close" or "pick=<index from 0>"; nothing sets it in play
local LOOP_MS = 25 -- often enough to catch a quick tap
local VIEWPORT_LAYER = 50
local PANEL_WIDTH = 560.0
local LIST_MAX_HEIGHT = 720.0 -- a longer list scrolls, so the whole panel stays on a 1080p screen
local GAP = 3.0 -- between the boxes
local FONT_PATH = "/Game/Textures/Font/VTCSwitchbladeRomance_Font.VTCSwitchbladeRomance_Font"
local FRAME_PATH = "/Game/Blueprints/UI/Shops/ShopItemFrame.ShopItemFrame"
local GLOW_PATH = "/Game/Blueprints/UI/HUD/M_UIGlow.M_UIGlow"
local KEYS_DIR = "/Game/Textures/UI/Input_Prompts_Pack/Keyboard_Mouse/Dark/"
local PAD_DIR = "/Game/Textures/UI/Input_Prompts_Pack/XGamepad/Default/"
local KEYBOARD_HINTS = {
    { KEYS_DIR, "T_Mouse_Left_Key_Dark", "Play" },
    { KEYS_DIR, "T_Mouse_Scroll_Key_Dark_Key_Dark", "Scroll" },
    { KEYS_DIR, "T_Tab_Key_Dark", "Close" },
}
local PAD_HINTS = {
    { PAD_DIR, "T_X_Dpad_Y", "Move" },
    { PAD_DIR, "T_X_A_Color", "Play" },
    { PAD_DIR, "T_X_B_Color", "Close" },
}
local FILL = { R = 0.0, G = 0.0, B = 0.0, A = 0.25 }
local PRESSED_FILL = { R = 0.0, G = 0.0, B = 0.0, A = 0.45 }
local CLEAR = { R = 0.0, G = 0.0, B = 0.0, A = 0.0 }
local WHITE = { R = 1.0, G = 1.0, B = 1.0, A = 1.0 }
local PLAYING = { R = 0.75, G = 0.0, B = 0.0, A = 1.0 } -- the game's own highlight red
local ROW_HOVER = { R = 1.0, G = 1.0, B = 1.0, A = 0.12 } -- under the mouse or the controller's highlight
local PLAYING_TINT = { R = 0.75, G = 0.0, B = 0.0, A = 0.14 } -- faint, so the red text of a highlighted row still reads on it
local HINT_GLOW = { R = 1.0, G = 1.0, B = 1.0, A = 0.25 } -- as under the HUD's key prompts
local NAME_SIZE, LABEL_SIZE = 18, 15
local NO_DRAW, DRAW_BOX, DRAW_IMAGE = 0, 1, 3 -- ESlateBrushDrawType
local FILL_ALIGN, LEFT_ALIGN, CENTER_ALIGN, RIGHT_ALIGN = 0, 1, 2, 3 -- EHorizontalAlignment (vertical: fill, top, center, bottom)
local SIZE_FILL = 1 -- ESlateSizeRule::Fill
local VISIBILITY_HIT_TEST_INVISIBLE = 3
local INPUT_LOCK_NONE = 0
local SCROLL_INTO_VIEW_CENTER = 2 -- EDescendantScrollDestination::Center
local SEX_INTERACTION = 1

local function log(message)
    print("[ScenePicker] " .. tostring(message) .. "\n")
end

local function valid(object)
    return object ~= nil and object:IsValid()
end

local function widget_library()
    return StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
end

local function current_controller()
    local controller = FindFirstOf("PlayerController")
    if valid(controller) then return controller end
    return nil
end

local function current_player(controller)
    controller = controller or current_controller()
    if controller and valid(controller.Pawn) then return controller.Pawn end
    return nil
end

local function new_widget(class_path, outer)
    return StaticConstructObject(StaticFindObject(class_path), outer)
end

local function padding(left, top, right, bottom)
    return { Left = left, Top = top or left, Right = right or left, Bottom = bottom or top or left }
end

local assets = {}
local function asset(path)
    local found = assets[path]
    if valid(found) then return found end
    found = StaticFindObject(path)
    if not valid(found) then
        local package, name = path:match("^(.*)%.([^%./]+)$")
        local ok, loaded = pcall(function()
            return StaticFindObject("/Script/AssetRegistry.Default__AssetRegistryHelpers"):GetAsset({
                PackageName = UEHelpers.FindOrAddFName(package), AssetName = UEHelpers.FindOrAddFName(name) })
        end)
        found = ok and loaded or nil
    end
    if valid(found) then
        assets[path] = found
        return found
    end
    return nil
end

local function style_text(block, size, color)
    pcall(function()
        local font = block.Font
        local face = asset(FONT_PATH)
        if face then
            font.FontObject = face
            font.TypefaceFontName = FName("Default")
        end
        font.Size = size
        font.OutlineSettings.OutlineSize = 0
        block:SetFont(font)
    end)
    pcall(function() block:SetShadowColorAndOpacity(CLEAR) end)
    block:SetColorAndOpacity({ SpecifiedColor = color or WHITE, ColorUseRule = 0 })
end

local function new_text(tree, label, size, color)
    local block = new_widget("/Script/UMG.TextBlock", tree)
    block:SetText(FText(label))
    style_text(block, size, color)
    return block
end

-- The shop's 9-slice frame, as the scene list's box draws it.
local function new_frame(tree, tint)
    local image = new_widget("/Script/UMG.Image", tree)
    local texture = asset(FRAME_PATH)
    if texture then
        image:SetBrushFromTexture(texture, false)
        local brush = image.Brush
        brush.DrawAs = DRAW_BOX
        brush.Margin = padding(0.25)
        image:SetBrush(brush)
    end
    image:SetColorAndOpacity(tint or WHITE)
    image:SetVisibility(VISIBILITY_HIT_TEST_INVISIBLE)
    return image
end

local function new_glow(tree, tint)
    local image = new_widget("/Script/UMG.Image", tree)
    local material = asset(GLOW_PATH)
    if material then image:SetBrushFromMaterial(material) end
    image:SetColorAndOpacity(tint)
    image:SetVisibility(VISIBILITY_HIT_TEST_INVISIBLE)
    return image
end

local function place(slot, horizontal, vertical, pad)
    slot:SetHorizontalAlignment(horizontal)
    slot:SetVerticalAlignment(vertical)
    if pad then slot:SetPadding(pad) end
    return slot
end

-- A flat wash over a row (an image with no texture draws white, so its colour is the wash).
local function new_tint(tree, tint)
    local image = new_widget("/Script/UMG.Image", tree)
    image:SetColorAndOpacity(tint)
    image:SetVisibility(VISIBILITY_HIT_TEST_INVISIBLE)
    return image
end

-- The scene list's box: the fill, (the HUD prompts' glow,) the frame, then the content.
local function new_box(tree, content, pad, glow, align)
    local border = new_widget("/Script/UMG.Border", tree)
    border:SetBrushColor(FILL)
    border:SetPadding(padding(0))
    local overlay = new_widget("/Script/UMG.Overlay", tree)
    border:AddChild(overlay)
    if glow then place(overlay:AddChild(new_glow(tree, glow)), FILL_ALIGN, FILL_ALIGN) end
    place(overlay:AddChild(new_frame(tree)), FILL_ALIGN, FILL_ALIGN)
    place(overlay:AddChild(content), align or FILL_ALIGN, CENTER_ALIGN, pad)
    return border
end

-- The game's menu button, kept for its hookable click, drawn as the theme's box (see the top of the file).
local function restyle_button(button, fill, pressed_fill, hover)
    local inner = button.Button_14
    local style = inner.WidgetStyle
    for _, state in ipairs({ "Normal", "Hovered", "Pressed" }) do
        local brush = style[state]
        local colour = state == "Pressed" and pressed_fill or fill
        brush.DrawAs = colour and DRAW_IMAGE or NO_DRAW
        brush.TintColor = { SpecifiedColor = colour or CLEAR, ColorUseRule = 0 }
        brush.OutlineSettings.Width = 0.0
    end
    style.NormalPadding = padding(0)
    style.PressedPadding = padding(0)
    inner:SetStyle(style)
    -- Its highlight image (a brush stroke the button shows on hover and on Highlight) becomes a flat wash.
    local highlight_image = button.Image_54
    pcall(function() highlight_image:SetBrushResourceObject(nil) end)
    highlight_image:SetColorAndOpacity(hover or CLEAR)
    pcall(function() button:Unhighlight() end) -- a new one starts with its highlight showing
end

-- The Free Mode scene list running the player's current scene, if there is one.
local function active_list(player)
    if not player or player.InInteraction ~= true or player["Interaction Type"] ~= SEX_INTERACTION then return nil end
    local scene = player.CurrentSScene
    if not valid(scene) then return nil end
    for _, list in ipairs(FindAllOf(SELECTOR_CLASS) or {}) do
        if valid(list) and valid(list.CurrentScene) and list.CurrentScene:GetAddress() == scene:GetAddress() then
            return list
        end
    end
    return nil
end

local function list_menu(list)
    for _, menu in ipairs(FindAllOf(LIST_MENU_CLASS) or {}) do
        if valid(menu) and valid(menu.SceneSelector) and menu.SceneSelector:GetAddress() == list:GetAddress() then
            return menu
        end
    end
    return nil
end

local function scene_titles(list)
    local titles = {}
    local scenes = list.Scenes
    for i = 1, scenes:GetArrayNum() do
        local handle = scenes[i]
        local title = nil
        pcall(function()
            local row = handle.DataTable:FindRow(handle.RowName:ToString())
            if row then title = row[NAME_FIELD]:ToString() end
        end)
        if not title or title == "" then
            local ok, row_name = pcall(function() return handle.RowName:ToString() end)
            title = ok and row_name or ("Scene " .. i)
        end
        titles[i] = scene_name(title)
    end
    return titles
end

local panel = nil -- { address, list_address, actions = { [button address] = fn }, items = { { address, row_address, index } }, cursor, scrolled }
local reader = nil
if has_pad then
    reader = Pad.Reader({ Pad.UP, Pad.DOWN, Pad.STICK_UP, Pad.STICK_DOWN, Pad.A, Pad.B, Pad.Y, Pad.MENU,
        "Tab", "Escape", "Up", "Down", "Enter" })
end
local reader_needs_reset = false

local function find_host()
    if not panel then return nil end
    for _, host in ipairs(FindAllOf(BUTTON_SHORT_CLASS) or {}) do
        if valid(host) and host:GetAddress() == panel.address then return host end
    end
    return nil
end

-- The scenes' list: host -> canvas -> width box -> stack (header, list, hints) -> list size box -> scroll box -> rows.
local function find_box(host)
    local ok, box = pcall(function()
        return host.WidgetTree.RootWidget:GetChildAt(1):GetChildAt(0):GetChildAt(1):GetChildAt(0):GetChildAt(0)
    end)
    if ok and valid(box) then return box end
    return nil
end

-- A scene's row (its button, frame and number) in the list.
local function item_widget(box, item)
    for index = 0, box:GetChildrenCount() - 1 do
        local child = box:GetChildAt(index)
        if valid(child) and child:GetAddress() == item.row_address then return child end
    end
    return nil
end

local function close_panel(reason)
    if not panel then return end
    local host = find_host()
    panel = nil
    ModRef:SetSharedVariable(OPEN_VARIABLE, false)
    if host then host:RemoveFromParent() end
    local controller = current_controller()
    if controller then
        -- The game never turns input off on these during a scene, so there is no earlier state to put back.
        controller:EnableInput(controller)
        local player = current_player(controller)
        if player then player:EnableInput(controller) end
        widget_library():SetInputMode_GameOnly(controller, true)
        controller.bShowMouseCursor = false
    end
    log("Closed" .. (reason and (": " .. reason) or ""))
end

-- Jumps the list to a scene the way A/D step it (see the top of the file).
local function play_scene(index)
    local player = current_player()
    local list = active_list(player)
    if not list then
        log("No scene list to switch")
        return
    end
    local count = list.Scenes:GetArrayNum()
    local from = list.CurrentIndex
    if index < 0 or index >= count or index == from then return end
    if list.InTransition then
        log("The list is still changing scene; try again in a moment")
        return
    end
    local menu = list_menu(list)
    local backwards = index < from
    if menu then
        list.CurrentIndex = backwards and index + 1 or index - 1
        menu:IncreaseIndexToNewScene(backwards)
    else
        list:StartNewScene(index)
    end
    log(string.format("Switching from scene %d to %d of %d", from + 1, index + 1, count))
end

local function highlight(box, item, on)
    local row = item and item_widget(box, item)
    if row then
        pcall(function()
            local button = row:GetChildAt(0)
            if on then button:Highlight() else button:Unhighlight() end
        end)
    end
    return row
end

local function scroll_to(box, widget, animate)
    pcall(function() box:GetParent():ScrollWidgetIntoView(widget, animate == true, SCROLL_INTO_VIEW_CENTER, 0.0) end)
end

local function move_cursor(box, to)
    local count = #panel.items
    if count == 0 then return end
    to = ((to - 1) % count) + 1
    if panel.cursor and panel.cursor ~= to then highlight(box, panel.items[panel.cursor], false) end
    panel.cursor = to
    local widget = highlight(box, panel.items[to], true)
    if widget then scroll_to(box, widget, true) end
end

local function new_button(controller)
    return widget_library():Create(controller, StaticFindObject(BUTTON_CLASS), controller)
end

local function new_scene_row(tree, controller, number, name, playing)
    local row = new_widget("/Script/UMG.Overlay", tree)
    local button = new_button(controller)
    restyle_button(button, FILL, PRESSED_FILL, ROW_HOVER)
    local label = button.TextBlock_0
    label:SetText(FText(name))
    style_text(label, NAME_SIZE)
    pcall(function() label:SetAutoWrapText(true) end)
    pcall(function() label.Slot:SetPadding(padding(46, 8)) end)
    -- Not shown; the row's number and name for tests and the log.
    button.Text = FText(string.format("%d. %s%s", number, name, playing and " (playing)" or ""))
    place(row:AddChild(button), FILL_ALIGN, FILL_ALIGN)
    if playing then place(row:AddChild(new_tint(tree, PLAYING_TINT)), FILL_ALIGN, FILL_ALIGN) end
    place(row:AddChild(new_frame(tree, playing and PLAYING or nil)), FILL_ALIGN, FILL_ALIGN)
    local digits = new_text(tree, tostring(number), LABEL_SIZE, playing and PLAYING or nil)
    digits:SetVisibility(VISIBILITY_HIT_TEST_INVISIBLE)
    place(row:AddChild(digits), LEFT_ALIGN, CENTER_ALIGN, padding(12, 0, 0, 0))
    return row, button
end

local function build_panel(controller, list, force_pad)
    local host = new_button(controller)
    local tree = host.WidgetTree
    local root = new_widget("/Script/UMG.CanvasPanel", tree)
    local width = new_widget("/Script/UMG.SizeBox", tree)
    local stack = new_widget("/Script/UMG.VerticalBox", tree)
    local list_size = new_widget("/Script/UMG.SizeBox", tree)
    local scroll = new_widget("/Script/UMG.ScrollBox", tree)
    local rows = new_widget("/Script/UMG.VerticalBox", tree)
    local titles = scene_titles(list)
    local current = list.CurrentIndex
    local pad_in_use = force_pad or (has_pad and Pad.using_gamepad(controller))
    local built = { address = host:GetAddress(), list_address = list:GetAddress(), actions = {}, items = {},
        pad_in_use = pad_in_use }

    -- Behind the panel, the whole screen: a click there closes it.
    local backdrop = new_button(controller)
    restyle_button(backdrop, nil, nil, nil)
    backdrop.TextBlock_0:SetText(FText(""))
    built.actions[backdrop:GetAddress()] = function() close_panel("clicked outside") end
    local backdrop_slot = root:AddChild(backdrop)
    backdrop_slot:SetAnchors({ Minimum = { X = 0.0, Y = 0.0 }, Maximum = { X = 1.0, Y = 1.0 } })
    backdrop_slot:SetOffsets(padding(0))

    local slot = root:AddChild(width)
    slot:SetAnchors({ Minimum = { X = 0.5, Y = 0.5 }, Maximum = { X = 0.5, Y = 0.5 } })
    slot:SetAlignment({ X = 0.5, Y = 0.5 })
    slot:SetAutoSize(true)
    width:SetWidthOverride(PANEL_WIDTH)
    width:AddChild(stack)

    -- "Scenes:" and where in the list this is, as the game's own box says it.
    local header = new_widget("/Script/UMG.HorizontalBox", tree)
    local header_label = header:AddChild(new_text(tree, "Scenes:", LABEL_SIZE))
    header_label:SetSize({ SizeRule = SIZE_FILL, Value = 1.0 })
    place(header_label, LEFT_ALIGN, CENTER_ALIGN, padding(5))
    place(header:AddChild(new_text(tree, string.format("%d/%d", current + 1, #titles), NAME_SIZE)), RIGHT_ALIGN, CENTER_ALIGN, padding(5))
    stack:AddChild(new_box(tree, header, padding(0, 2)))

    list_size:SetMaxDesiredHeight(LIST_MAX_HEIGHT)
    list_size:AddChild(scroll)
    scroll:AddChild(rows)
    pcall(function() scroll:SetScrollbarThickness({ X = 4.0, Y = 4.0 }) end)
    place(stack:AddChild(list_size), FILL_ALIGN, FILL_ALIGN, padding(0, GAP, 0, 0))
    for i, name in ipairs(titles) do
        local index = i - 1
        local row, button = new_scene_row(tree, controller, i, name, index == current)
        place(rows:AddChild(row), FILL_ALIGN, FILL_ALIGN, padding(0, 0, 6, i < #titles and GAP or 0))
        built.actions[button:GetAddress()] = function()
            close_panel("picked scene " .. i)
            play_scene(index)
        end
        table.insert(built.items, { address = button:GetAddress(), row_address = row:GetAddress(), index = index })
        if index == current then built.current_item = #built.items end
    end

    -- The keys, with the game's own badges, in a box like the HUD's key prompts.
    local hints = new_widget("/Script/UMG.HorizontalBox", tree)
    for i, hint in ipairs(pad_in_use and PAD_HINTS or KEYBOARD_HINTS) do
        local icon = new_widget("/Script/UMG.Image", tree)
        local texture = asset(hint[1] .. hint[2] .. "." .. hint[2])
        if texture then icon:SetBrushFromTexture(texture, false) end
        place(hints:AddChild(icon), LEFT_ALIGN, CENTER_ALIGN, padding(i > 1 and 26 or 0, 0, 0, 0))
        place(hints:AddChild(new_text(tree, hint[3], NAME_SIZE)), LEFT_ALIGN, CENTER_ALIGN, padding(8, 2, 0, 0))
    end
    place(stack:AddChild(new_box(tree, hints, padding(10), HINT_GLOW, CENTER_ALIGN)), FILL_ALIGN, FILL_ALIGN, padding(0, GAP, 0, 0))

    -- The panel is left unable to take the focus: a focused widget would turn the D-pad into the engine's navigation.
    tree.RootWidget = root
    return host, built
end

local function open_panel(force_pad)
    local controller = current_controller()
    local player = current_player(controller)
    local list = active_list(player)
    if not list then return false end
    if list.InTransition then
        log("The list is changing scene; not opening")
        return false
    end
    local host, built = build_panel(controller, list, force_pad)
    host:AddToViewport(VIEWPORT_LAYER)
    panel = built
    ModRef:SetSharedVariable(OPEN_VARIABLE, true)
    controller:DisableInput(controller)
    player:DisableInput(controller)
    -- Game and UI input, as the game's own menus use: under UI only the engine never sees the controller's buttons.
    -- The game's viewport keeps the focus, as a focused panel would turn the D-pad into the engine's own navigation.
    widget_library():SetInputMode_GameAndUIEx(controller, host, INPUT_LOCK_NONE, false, false)
    widget_library():SetFocusToGameViewport()
    controller.bShowMouseCursor = true
    reader_needs_reset = true
    log(string.format("Opened: %d scenes, playing %d", list.Scenes:GetArrayNum(), list.CurrentIndex + 1))
    return true
end

local function press(item)
    local action = item and panel and panel.actions[item.address]
    if action then action() end
end

-- A mouse click can hand the focus to a button, which would then keep the D-pad, so the focus is taken back.
local function keep_viewport_focus(controller, host)
    local taken = host and (host:HasUserFocus(controller) or host:HasFocusedDescendants())
    if taken then widget_library():SetFocusToGameViewport() end
end

local function panel_tick()
    local controller = current_controller()
    local player = current_player(controller)
    local list = active_list(player)
    if not list or list:GetAddress() ~= panel.list_address then
        close_panel("the scene list is gone")
        return
    end
    local host = find_host()
    local box = host and find_box(host)
    if not box then
        close_panel("the panel is gone")
        return
    end
    keep_viewport_focus(controller, host)
    if not panel.scrolled then
        -- Once laid out, the scene playing now is brought into view (and highlighted for the controller).
        panel.scrolled = true
        local item = panel.items[panel.current_item or 1]
        if panel.pad_in_use then
            move_cursor(box, panel.current_item or 1)
        else
            local row = item and item_widget(box, item)
            if row then scroll_to(box, row) end
        end
    end
    if not reader then return end
    if reader_needs_reset then
        -- The Tab or Y that opened the panel is still down; it is not a new press.
        reader:reset(controller)
        reader_needs_reset = false
        return
    end
    if not reader:update(controller) then return end
    if reader:pressed("Tab") or reader:pressed("Escape") or reader:pressed(Pad.B) or reader:pressed(Pad.Y)
        or reader:pressed(Pad.MENU) then
        close_panel()
        return
    end
    local up = reader:repeated(Pad.UP) or reader:repeated(Pad.STICK_UP) or reader:repeated("Up")
    local down = reader:repeated(Pad.DOWN) or reader:repeated(Pad.STICK_DOWN) or reader:repeated("Down")
    if up or down then
        if not panel.cursor then
            move_cursor(box, panel.current_item or 1)
        else
            move_cursor(box, panel.cursor + (up and -1 or 1))
        end
        return
    end
    if (reader:pressed(Pad.A) or reader:pressed("Enter")) and panel.cursor then
        press(panel.items[panel.cursor])
    end
end

local function run_test_request()
    local request = ModRef:GetSharedVariable(TEST_VARIABLE)
    if type(request) ~= "string" or request == "" then return end
    ModRef:SetSharedVariable(TEST_VARIABLE, "")
    if request == "open" or request == "open_pad" then
        if not panel then log("Test: " .. request .. " -> " .. tostring(open_panel(request == "open_pad"))) end
    elseif request == "close" then
        close_panel("test")
    else
        local index = tonumber(request:match("^pick=(%d+)$"))
        if index then
            close_panel("test pick")
            play_scene(index)
        end
    end
end

-- The game's classes load with the level, so the hooks are retried until they register.
local hooked = {}
local function hook(path, callback)
    if hooked[path] then return true end
    if pcall(RegisterHook, path, callback) then
        hooked[path] = true
        log("Hooked " .. path:match(":(.*)$"))
        return true
    end
    return false
end

local function register_hooks()
    -- After the game's own Inventory handling, which does nothing during a sex scene.
    hook(INVENTORY_HOOK, function()
        ExecuteInGameThread(function()
            local ok, problem = pcall(function()
                if not panel then open_panel() end
            end)
            if not ok then log("Open error: " .. tostring(problem)) end
        end)
    end)
    hook(BUTTON_PRESSED_HOOK, function(context)
        if not panel then return end
        local address = context:get():GetAddress()
        if panel.actions[address] then
            -- Pressing removes the button being pressed, so it waits for the next game thread step.
            ExecuteInGameThread(function()
                local action = panel and panel.actions[address]
                if action then
                    local ok, problem = pcall(action)
                    if not ok then log("Button error: " .. tostring(problem)) end
                end
            end)
        end
    end)
end

-- The key prompt on the HUD's scene page (bottom right: "W Next Stage", "S Previous Stage", "Change Perspective"):
-- while a Free Mode list's scene plays, one more of the game's own prompts (BPW_ActionMappingPrompt2) goes above Next
-- Stage, showing the Inventory key (Tab, or Y once the controller is in use; it follows rebinding) and "Scenes". Its
-- stack has a fixed size on the HUD's canvas, so that grows by the prompt's height and goes back when it is removed.
local PROMPT_CLASS = "/Game/Blueprints/UI/HUD/BPW_ActionMappingPrompt2.BPW_ActionMappingPrompt2_C"
local PROMPT_SHORT_CLASS = "BPW_ActionMappingPrompt2_C"
local PROMPT_TEXT = "Scenes"
local PROMPT_EVERY_LOOPS = 10 -- 250 ms
local prompt = nil -- { address, stack_address, grew }
local prompt_loops = 0

local function find_by_address(short_class, address)
    for _, object in ipairs(FindAllOf(short_class) or {}) do
        if valid(object) and object:GetAddress() == address then return object end
    end
    return nil
end

local function scene_page_stack()
    for _, hud in ipairs(FindAllOf("BPW_MainHud_C") or {}) do
        if valid(hud) and hud:IsInViewport() and valid(hud.NextStageSwitcher) then
            local stack = hud.NextStageSwitcher:GetParent()
            if valid(stack) then return stack end
        end
    end
    return nil
end

local function remove_prompt(reason)
    if not prompt then return end
    local old = prompt
    prompt = nil
    local widget = find_by_address(PROMPT_SHORT_CLASS, old.address)
    if widget then widget:RemoveFromParent() end
    local stack = scene_page_stack()
    if stack and stack:GetAddress() == old.stack_address and old.grew then
        pcall(function()
            local size = stack.Slot:GetSize()
            stack.Slot:SetSize({ X = size.X, Y = size.Y - old.grew })
        end)
    end
    log("Removed the Tab prompt: " .. reason)
end

local function add_prompt(controller)
    local stack = scene_page_stack()
    if not stack then return end
    local widget = widget_library():Create(controller, StaticFindObject(PROMPT_CLASS), controller)
    if not valid(widget) then return end
    -- Set before it is added, as its construction reads them.
    widget["Action Name"] = FName("Inventory")
    widget.Text = FText(PROMPT_TEXT)
    widget.IsAxis = false
    widget.VisibleOnGamepad = true
    -- On top: the stack's own rows are taken out and put back after it, each with its slot as it was (InsertChildAt
    -- and ShiftChild had no effect from Lua here).
    local rows = {}
    for i = 0, stack:GetChildrenCount() - 1 do
        local child = stack:GetChildAt(i)
        if valid(child) then
            local saved = { widget = child }
            pcall(function()
                local slot = child.Slot
                local pad, size = slot.Padding, slot.Size
                saved.padding = { Left = pad.Left, Top = pad.Top, Right = pad.Right, Bottom = pad.Bottom }
                saved.size = { SizeRule = size.SizeRule, Value = size.Value }
                saved.h, saved.v = slot.HorizontalAlignment, slot.VerticalAlignment
            end)
            table.insert(rows, saved)
        end
    end
    stack:ClearChildren()
    stack:AddChild(widget)
    for _, saved in ipairs(rows) do
        local slot = stack:AddChild(saved.widget)
        if slot and saved.padding then
            pcall(function()
                slot:SetPadding(saved.padding)
                slot:SetSize(saved.size)
                slot:SetHorizontalAlignment(saved.h)
                slot:SetVerticalAlignment(saved.v)
            end)
        end
    end
    local grew = nil
    pcall(function()
        local below = stack:GetChildAt(1)
        local height = (valid(below) and below:GetDesiredSize().Y) or 0
        if height < 1 then height = 52.0 end -- the prompts' height at 1080p (their box with a 32 px badge)
        local size = stack.Slot:GetSize()
        stack.Slot:SetSize({ X = size.X, Y = size.Y + height })
        grew = height
    end)
    prompt = { address = widget:GetAddress(), stack_address = stack:GetAddress(), grew = grew }
    ModRef:SetSharedVariable(PROMPT_VARIABLE, true)
    log("Added the Tab prompt above Next Stage")
end

local function prompt_tick()
    prompt_loops = prompt_loops + 1
    if prompt_loops < PROMPT_EVERY_LOOPS then return end
    prompt_loops = 0
    local controller = current_controller()
    local player = current_player(controller)
    local wanted = active_list(player) ~= nil
    if prompt then
        local stack = scene_page_stack()
        local alive = find_by_address(PROMPT_SHORT_CLASS, prompt.address)
        if not wanted or not alive or not stack or stack:GetAddress() ~= prompt.stack_address then
            remove_prompt(wanted and "the HUD changed" or "not in a Free Mode list scene")
            ModRef:SetSharedVariable(PROMPT_VARIABLE, false)
        end
    elseif wanted then
        add_prompt(controller)
    end
end

local errors = 0
LoopInGameThreadWithDelay(LOOP_MS, function()
    if errors >= 5 then return true end
    local ok, problem = pcall(function()
        if not (hooked[INVENTORY_HOOK] and hooked[BUTTON_PRESSED_HOOK]) then register_hooks() end
        run_test_request()
        if panel then panel_tick() end
        prompt_tick()
    end)
    if not ok then
        errors = errors + 1
        log("Error: " .. tostring(problem))
        if errors >= 5 then
            pcall(close_panel, "turned off after repeated errors")
            log("Turned off after repeated errors")
        end
    end
    return false
end)

ModRef:SetSharedVariable(OPEN_VARIABLE, false)
ModRef:SetSharedVariable(PROMPT_VARIABLE, false)
log("Loaded")
