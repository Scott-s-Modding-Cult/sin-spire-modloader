-- Freecam: a third camera in the game's own perspective switch during the player's sex scenes. The Perspective key
-- (middle mouse, or the right stick click on a controller) now goes first person -> third person -> Freecam -> first
-- person. Outside sex scenes the game has no perspective switch, and neither does this.
--
-- How it sits on the game (BP_PlayerCharacter, decompiled in _modtools\full\kismet): the key calls OnTogglePerspective,
-- which calls ToggleTP while CanToggleTP is on and the player is in a sex interaction (Interaction Type 1). ToggleTP puts
-- "FP Camera" on SpringArm1 (third person, InTPMode on) or back on Rotator (first person, InTPMode off).
-- UE4SS runs a hook on a blueprint function after the function, so by the time this sees the key going from third person
-- to first, the game has already moved the camera to the head; this takes it straight off again and puts it where third
-- person had it. InTPMode stays on during Freecam, so the game's next press (ToggleTP) puts the camera back on Rotator
-- itself, and its own scene ending (AnimNotify_disablecamera, EndInteraction) puts it back as it does from third person.
--
-- While Freecam is on:
--   * the player's InCutscene switch is held on, so the controller's move and look handlers stop early
--     (GetBlockedInput): W/S no longer step the scene's stages, A/D no longer switch Free Mode's scene list, and the
--     mouse no longer turns his head. Pause and the Perspective key don't check it, so they still work. The axes still
--     carry their values, which this reads (GetInputAxisValue), so a rebinding in the Controls menu carries over.
--   * the scene's StageCooldown is held on, so nothing else steps the stages either (NextStage checks it first).
--   * looking goes through the control rotation the way the game's own Turn and Look handlers do (its sensitivity, its
--     invert Y, the camera's pitch limits). The control rotation from before Freecam is put back when it ends.
-- On leaving (the key, or the scene ending), the camera goes back on its parent, InCutscene goes back to what it was,
-- the stage cooldown is let go, and the control rotation is put back.
--
-- Controls: WASD or the left stick move, the mouse or the right stick look, Space or RB up, Ctrl or LB down, Shift or
-- LT faster, Alt slower. (RT is the game's Shoot, which a scene uses for its special action, so it is left alone.)
--
-- The game also turns CanToggleTP off for good when a scene ends in third person (AnimNotify_disablecamera), and nothing
-- turns it back on, so after one such scene the key did nothing until the next level. Each new sex scene turns it back
-- on here, as ending a scene in Freecam counts as third person to the game.

local PLAYER_CLASS = "/Game/Blueprints/Player/BP_PlayerCharacter.BP_PlayerCharacter_C"
local HANDLER_CLASS = "BP_SexSceneHandler_C"
local COMMON_LIBRARY = "/Game/Blueprints/BPFL_CommonFunctions.Default__BPFL_CommonFunctions_C"
local SEX_INTERACTION = 1 -- Enum_InteractionType; ToggleTP works only in these
local SPEED = 220.0 -- cm per second at full stick or key
local FAST, SLOW = 3.0, 0.3
local SMOOTHING = 10.0 -- how quickly the camera takes up the speed asked for (per second); higher is snappier
local MAX_STEP_SECONDS = 0.1 -- a hitch longer than this moves the camera as if it were this long
local SNAP = 2 -- EAttachmentRule::SnapToTarget, as ToggleTP attaches
local KEEP_WORLD = 1 -- EDetachmentRule::KeepWorld
local MAX_ERRORS = 5
local MESSAGE_COLOUR = { R = 0.99, G = 0.99, B = 0.99, A = 1.0 }
local KEYBOARD_HINT = "Freecam: WASD and mouse, Space/Ctrl up and down, Shift faster, Alt slower"
local PAD_HINT = "Freecam: sticks to move and look, RB/LB up and down, LT faster"
local MODE_VARIABLE = "Freecam_Mode" -- "fp", "tp" or "free", for tests and other mods
local TEST_VARIABLE = "Freecam_TestInput" -- for tests, e.g. "forward=1,turn=0.5,fast=1"; nothing sets it in play
local PICKER_VARIABLE = "GoonerDLC_ScenePickerOpen" -- true while the scene picker is open

local KEYS = {
    up = { "SpaceBar", "Gamepad_RightShoulder" },
    down = { "LeftControl", "Gamepad_LeftShoulder" },
    fast = { "LeftShift", "RightShift", "Gamepad_LeftTrigger" },
    slow = { "LeftAlt" },
}

local function log(message)
    print("[Freecam] " .. tostring(message) .. "\n")
end

local function valid(object)
    return object ~= nil and object:IsValid()
end

local names = {}
local function name(text)
    local made = names[text]
    if not made then
        made = FName(text)
        names[text] = made
    end
    return made
end

local key_structs = {}
local function key_down(controller, key)
    local struct = key_structs[key]
    if not struct then
        struct = { KeyName = name(key) }
        key_structs[key] = struct
    end
    local ok, down = pcall(function() return controller:IsInputKeyDown(struct) end)
    return ok and down == true
end

local function any_down(controller, keys)
    for _, key in ipairs(keys) do
        if key_down(controller, key) then return true end
    end
    return false
end

local function analog(controller, key)
    local struct = key_structs[key]
    if not struct then
        struct = { KeyName = name(key) }
        key_structs[key] = struct
    end
    local ok, value = pcall(function() return controller:GetInputAnalogKeyState(struct) end)
    return ok and tonumber(value) or 0.0
end

-- The game's own axes (DefaultInput.ini): MoveForward is W/S and the left stick, MoveRight A/D and the left stick,
-- Turn the mouse and the right stick across, Look the mouse and the right stick up and down. Reading the axis keeps any
-- rebinding from the Controls menu; if it reads nothing, the keys the game ships with are read directly instead, with
-- the same scales, so a failed axis read cannot leave Freecam deaf.
local RAW = {
    MoveForward = { { "W", 1.0 }, { "S", -1.0 }, { "Gamepad_LeftY", 1.0, true } },
    MoveRight = { { "D", 1.0 }, { "A", -1.0 }, { "Gamepad_LeftX", 1.0, true } },
    Turn = { { "MouseX", 1.0, true }, { "Gamepad_RightX", 1.0, true } },
    Look = { { "MouseY", -1.0, true }, { "Gamepad_RightY", 1.0, true } },
}

local function axis(controller, axis_name)
    local ok, value = pcall(function() return controller:GetInputAxisValue(name(axis_name)) end)
    value = ok and tonumber(value) or 0.0
    if value ~= 0.0 then return value end
    for _, entry in ipairs(RAW[axis_name]) do
        if entry[3] then
            value = value + analog(controller, entry[1]) * entry[2]
        elseif key_down(controller, entry[1]) then
            value = value + entry[2]
        end
    end
    return value
end

local function using_gamepad(controller)
    local ok, using = pcall(function()
        return StaticFindObject("/Script/Engine.Default__GameplayStatics"):GetGameInstance(controller).UsingGamepad
    end)
    return ok and using == true
end

local function add_test_input(input)
    local text = ModRef:GetSharedVariable(TEST_VARIABLE)
    if type(text) ~= "string" or text == "" then return end
    for field, number in text:gmatch("(%a+)=([%-%d%.]+)") do
        local value = tonumber(number)
        if value and (field == "fast" or field == "slow") then
            input[field] = input[field] or value ~= 0
        elseif value and input[field] ~= nil then
            input[field] = input[field] + value
        end
    end
end

local function read_input(controller)
    -- The scene picker (scene_picker.lua) has the keys and the mouse while it is open, so the camera holds still.
    if ModRef:GetSharedVariable(PICKER_VARIABLE) == true then
        return { forward = 0.0, right = 0.0, turn = 0.0, look = 0.0, up = 0.0, fast = false, slow = false }
    end
    local input = {
        forward = axis(controller, "MoveForward"),
        right = axis(controller, "MoveRight"),
        turn = axis(controller, "Turn"),
        look = axis(controller, "Look"),
        up = 0.0,
        fast = any_down(controller, KEYS.fast),
        slow = any_down(controller, KEYS.slow),
    }
    if any_down(controller, KEYS.up) then input.up = input.up + 1.0 end
    if any_down(controller, KEYS.down) then input.up = input.up - 1.0 end
    add_test_input(input)
    return input
end

local state = {
    mode = "fp", -- "fp", "tp" or "free", as last seen
    free = nil, -- while Freecam is on: where it is and what to put back
    tp_view = nil, -- the camera's last place in third person, where Freecam starts
    in_scene = false,
    errors = 0,
    disabled = false,
}

local published = nil
local function publish()
    if published ~= state.mode then
        published = state.mode
        ModRef:SetSharedVariable(MODE_VARIABLE, state.mode)
    end
end

local function in_sex_scene(player)
    return player.InInteraction == true and player["Interaction Type"] == SEX_INTERACTION
end

local function on_spring_arm(player)
    local camera, arm = player["FP Camera"], player.SpringArm1
    if not valid(camera) or not valid(arm) then return false end
    local parent = camera:GetAttachParent()
    return valid(parent) and parent:GetAddress() == arm:GetAddress()
end

local function message(player, text)
    pcall(function()
        StaticFindObject(COMMON_LIBRARY):ShowHudMessage(FText(text), MESSAGE_COLOUR, player)
    end)
end

local function copy_vector(v)
    return { X = v.X, Y = v.Y, Z = v.Z }
end

local function record_view(player)
    local camera = player["FP Camera"]
    if not valid(camera) then return end
    local location, rotation = camera:K2_GetComponentLocation(), camera:K2_GetComponentRotation()
    local view = state.tp_view or { location = {}, rotation = {} }
    view.location.X, view.location.Y, view.location.Z = location.X, location.Y, location.Z
    view.rotation.Pitch, view.rotation.Yaw = rotation.Pitch, rotation.Yaw
    state.tp_view = view
end

-- Holds the game's switches on, every frame, as the game's own timers and events may turn them off.
local function hold(player)
    if player.InCutscene ~= true then player.InCutscene = true end
    local handler = player.CurrentSScene
    if valid(handler) then
        state.free.handlers[handler:GetAddress()] = true
        if handler.StageCooldown ~= true then handler.StageCooldown = true end
    end
end

local function enter(player)
    local camera, controller = player["FP Camera"], player.Controller
    if not valid(camera) or not valid(controller) then return end
    local view = state.tp_view
    local location = view and view.location or copy_vector(camera:K2_GetComponentLocation())
    local rotation = view and view.rotation or camera:K2_GetComponentRotation()
    local before = controller:GetControlRotation()
    state.free = {
        location = { X = location.X, Y = location.Y, Z = location.Z },
        velocity = { X = 0.0, Y = 0.0, Z = 0.0 },
        control_rotation = { Pitch = before.Pitch, Yaw = before.Yaw, Roll = before.Roll },
        cutscene = player.InCutscene == true,
        handlers = {},
    }
    local look = { Pitch = rotation.Pitch, Yaw = rotation.Yaw, Roll = 0.0 }
    camera:K2_DetachFromComponent(KEEP_WORLD, KEEP_WORLD, KEEP_WORLD, false)
    controller:SetControlRotation(look)
    camera:K2_SetWorldLocationAndRotation(state.free.location, look, false, {}, true)
    player.InTPMode = true -- so the game's next toggle and its scene ending treat it as third person
    hold(player)
    state.mode = "free"
    publish()
    log(string.format("On, from third person at (%.0f, %.0f, %.0f)", location.X, location.Y, location.Z))
    message(player, using_gamepad(controller) and PAD_HINT or KEYBOARD_HINT)
end

local function leave(player, reason)
    local free = state.free
    state.free = nil
    if not free then return end
    if valid(player) then
        local camera = player["FP Camera"]
        if valid(camera) and not valid(camera:GetAttachParent()) then
            -- The game did not take it back itself (it could not toggle, or something else ended Freecam): first person.
            camera:K2_AttachToComponent(player.Rotator, name("None"), SNAP, SNAP, SNAP, true)
        end
        -- Held on for Freecam; off unless the camera really is on the spring arm (a new scene puts it on the head).
        if not on_spring_arm(player) then player.InTPMode = false end
        if valid(player.Controller) then player.Controller:SetControlRotation(free.control_rotation) end
        if player.InCutscene == true and not free.cutscene then player.InCutscene = false end
    end
    for _, handler in ipairs(FindAllOf(HANDLER_CLASS) or {}) do
        if valid(handler) and free.handlers[handler:GetAddress()] then handler.StageCooldown = false end
    end
    log("Off: " .. reason)
end

local function step(player, seconds)
    local controller, camera = player.Controller, player["FP Camera"]
    if not valid(controller) or not valid(camera) then return end
    local free = state.free
    hold(player)
    local input = read_input(controller)

    -- Looking, as the controller's Turn and Look handlers would (they stop early now). It reaches the control rotation
    -- on the controller's next update, as the game's own look does.
    local sensitivity = tonumber(controller.Sensitivity) or 1.0
    if input.turn ~= 0 then player:AddControllerYawInput(input.turn * sensitivity) end
    -- The game's Look handler negates the axis here, but in Freecam that came out inverted (mouse up looked down, as the
    -- user found in game), so the axis goes in as it is; the game's Invert Y setting still flips it.
    if input.look ~= 0 then
        player:AddControllerPitchInput((controller.InvertY == true and -input.look or input.look) * sensitivity)
    end
    local rotation = controller:GetControlRotation()
    local pitch, yaw = math.rad(rotation.Pitch), math.rad(rotation.Yaw)

    -- Moving along the look (forward includes looking up or down), sideways level, and up and down straight.
    local cp, sp, cy, sy = math.cos(pitch), math.sin(pitch), math.cos(yaw), math.sin(yaw)
    local x = cp * cy * input.forward - sy * input.right
    local y = cp * sy * input.forward + cy * input.right
    local z = sp * input.forward + math.max(-1.0, math.min(1.0, input.up))
    local length = math.sqrt(x * x + y * y + z * z)
    if length > 1.0 then x, y, z = x / length, y / length, z / length end
    local speed = SPEED * (input.fast and FAST or 1.0) * (input.slow and SLOW or 1.0)
    local blend = 1.0 - math.exp(-SMOOTHING * seconds)
    local v, at = free.velocity, free.location
    v.X = v.X + (x * speed - v.X) * blend
    v.Y = v.Y + (y * speed - v.Y) * blend
    v.Z = v.Z + (z * speed - v.Z) * blend
    at.X, at.Y, at.Z = at.X + v.X * seconds, at.Y + v.Y * seconds, at.Z + v.Z * seconds
    camera:K2_SetWorldLocationAndRotation(at, { Pitch = rotation.Pitch, Yaw = rotation.Yaw, Roll = 0.0 }, false, {}, true)
end

local function on_toggle(player)
    if state.disabled or not valid(player) or not in_sex_scene(player) then return end
    if state.free then
        leave(player, "switched to first person")
        state.mode = player.InTPMode and "tp" or "fp"
    elseif state.mode == "tp" and not player.InTPMode then
        enter(player)
    else
        state.mode = player.InTPMode and "tp" or "fp"
    end
    publish()
end

local function on_tick(player, seconds)
    if state.disabled or not valid(player) then return end
    if not in_sex_scene(player) then
        if state.free then leave(player, "the scene ended") end
        if state.in_scene then
            state.in_scene, state.mode, state.tp_view = false, "fp", nil
            publish()
        end
        return
    end
    if not state.in_scene then
        state.in_scene = true
        if player.CanToggleTP ~= true then
            player.CanToggleTP = true
            log("Turned the perspective switch back on (the game had left it off after an earlier scene)")
        end
    end
    if state.free then
        local camera = player["FP Camera"]
        if not player.InTPMode or (valid(camera) and valid(camera:GetAttachParent())) then
            leave(player, "the game took the camera back")
            state.mode = player.InTPMode and "tp" or "fp"
            publish()
            return
        end
        step(player, math.min(tonumber(seconds) or 0.0, MAX_STEP_SECONDS))
    else
        -- Third person is the camera on the spring arm. A new scene from Free Mode's list (A/D, or the scene picker)
        -- puts the camera back on the head without turning InTPMode off, so the next press did nothing visible; the
        -- switch is kept in step with where the camera really is.
        local on_arm = on_spring_arm(player)
        if player.InTPMode ~= on_arm then player.InTPMode = on_arm end
        local mode = on_arm and "tp" or "fp"
        if mode ~= state.mode then
            state.mode = mode
            publish()
        end
        if mode == "tp" then record_view(player) end
    end
end

-- A hook that keeps failing would fill the log every frame, so after a few errors Freecam lets go and turns itself off.
local function guarded(fn, player, ...)
    local ok, problem = pcall(fn, player, ...)
    if ok then return end
    state.errors = state.errors + 1
    log("Error: " .. tostring(problem))
    if state.errors >= MAX_ERRORS then
        state.disabled = true
        pcall(leave, player, "turned off after repeated errors")
        log("Turned off after repeated errors")
    end
end

-- The player's class loads with the first level, so the hooks are retried until they register.
local hooked = {}
local function hook(function_name, callback)
    if hooked[function_name] then return true end
    if pcall(RegisterHook, PLAYER_CLASS .. ":" .. function_name, callback) then
        hooked[function_name] = true
        log("Hooked " .. function_name)
        return true
    end
    return false
end

LoopInGameThreadWithDelay(500, function()
    local toggle = hook("OnTogglePerspective", function(context)
        guarded(on_toggle, context:get())
    end)
    local tick = hook("ReceiveTick", function(context, delta)
        guarded(on_tick, context:get(), delta:get())
    end)
    return toggle and tick
end)

publish()
log("Loaded")
