-- Written by make_kissbehind_keys.py: timing for the player's kiss-from-behind scene clips. Do not edit.
return {
    nurse_root = { X = -0.000, Y = 22.891, Z = -0.000 },
    clips = {
        Enter = {
            length = 2.5000,
            counts = { 1.500 },
            spurts = {  },
            events = { { 0.500, "slide" }, { 1.500, "slap" } },
        },
        Loop1 = {
            length = 3.0000,
            cycle = 1.0000,
            counts = { 0.500, 1.500, 2.500 },
            spurts = {  },
            events = { { 0.500, "slap" }, { 1.500, "slap" }, { 2.500, "slap" } },
        },
        Loop2 = {
            length = 2.2000,
            cycle = 0.5500,
            counts = { 0.275, 0.825, 1.375, 1.925 },
            spurts = {  },
            events = { { 0.275, "slap" }, { 0.825, "slap" }, { 1.375, "slap" }, { 1.925, "slap" } },
        },
        Loop3 = {
            length = 2.4000,
            cycle = 0.4000,
            counts = { 0.200, 0.600, 1.000, 1.400, 1.800, 2.200 },
            spurts = {  },
            events = { { 0.200, "slap" }, { 0.600, "slap" }, { 1.000, "slap" }, { 1.400, "slap" }, { 1.800, "slap" }, { 2.200, "slap" } },
        },
        End = {
            length = 7.0000,
            counts = {  },
            spurts = { 1.000, 1.600, 2.300 },
            purify = 5.000,
            events = { { 0.450, "slap" }, { 0.900, "slap" }, { 1.000, "cum" }, { 1.600, "internal" }, { 2.300, "internal" }, { 5.300, "slide" } },
        },
    },
}
