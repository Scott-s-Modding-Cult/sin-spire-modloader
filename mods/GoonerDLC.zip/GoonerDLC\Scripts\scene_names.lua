-- Scene names as the game's font (VTC Switchblade Romance) can draw them. It has no hyphen, and "#" and "+" are not
-- known to draw either, so "Floor - Legs Lifted Missionary" showed as "Floor   Legs Lifted Missionary". Letters,
-- digits, ":", "/", "[" and "]" are seen drawing in the game's own labels.
--   "Floor - Couple/Romantic - Intimate Session #4"  ->  "Floor: Couple/Romantic: Intimate Session 4"
--   "Standing - Pile-driver Position"                ->  "Standing: Pile driver Position"
--   "Classic Oraljob + Squat Masturbation"           ->  "Classic Oraljob and Squat Masturbation"
--   "Seated Kamasutra 69 #1"                          ->  "Seated Kamasutra 69 [1]"
-- Used for the rows' Name (which the scene list's own label shows) and by the scene picker. Logs keep the real titles.

return function(title)
    local name = tostring(title or "")
    name = name:gsub("%s+%-%s+", ": ")
    name = name:gsub("%s+%+%s+", " and ")
    name = name:gsub("%-", " ")
    name = name:gsub("(%d)%s+#%s*(%d+)", "%1 [%2]") -- "69 #1" -> "69 [1]", not "69 1"
    name = name:gsub("#%s*", "")
    name = name:gsub("%s%s+", " ")
    return name
end
