-- Gooner DLC's Boss Timer row (admin panel, "Gooner DLC" tab): Off stops the dungeon countdown before the stalker boss
-- arrives, so it never comes, and hides the countdown on the HUD. On (the default) leaves the game alone.
--
-- The countdown is the game's BP_StalkerTimer actor, one per dungeon. A looping 0.1 s timer takes one from
-- "Time in Deciseconds", and at 0 the stalker spawns at a door. Below 30 s the HUD plays its danger animation. Being
-- spotted by an enemy takes 1 s off and restarts the looping timer, even while it is paused, and sex scenes pause and
-- unpause it. So while Off, each tick pauses it again (the game's own OnPause) and holds the time where it was, never under
-- one minute, so a spot between ticks can't run it out. The HUD's TimerShow text is hidden while Off. Back On, the game's
-- own OnUnpause and the HUD's TimerStateSwitched handler put both back as the game would have them.
-- A stalker that already arrived is left alone; Off only stops the next one.
--
-- The choice is saved to boss-timer.txt in the mod's folder (beside mod.json, so a rebuild keeps it).

local AdminTabs = require("AdminTabs")

local TICK_MS = 250
local MIN_HOLD = 600 -- deciseconds; the HUD's danger mode starts under 300
local SETTINGS_FILE = "ue4ss\\Mods\\GoonerDLC\\boss-timer.txt"
local OPTIONS = { "On", "Off" }
local VISIBLE, COLLAPSED = 0, 1 -- ESlateVisibility, as the HUD sets it
local TEST_VARIABLE = "GoonerDLC_BossTimerState" -- for tests: written each tick, nothing reads it in play

local function log(message)
    print("[BossTimer] " .. tostring(message) .. "\n")
end

local function load_off()
    local file = io.open(SETTINGS_FILE, "r")
    if not file then return false end
    local text = file:read("*a") or ""
    file:close()
    return text:match("off") ~= nil
end

local function save_off(off)
    local file = io.open(SETTINGS_FILE, "w")
    if not file then
        log("Could not save " .. SETTINGS_FILE)
        return
    end
    file:write(off and "off\n" or "on\n")
    file:close()
end

local off = load_off()
local held = {} -- timer address -> the time held for it
local hidden_hud = nil -- address of the HUD whose timer text was hidden

local function valid(object)
    return object ~= nil and object:IsValid()
end

local function find_timer()
    local timer = FindFirstOf("BP_StalkerTimer_C")
    if valid(timer) then return timer end
end

local function find_hud()
    for _, hud in ipairs(FindAllOf("BPW_MainHud_C") or {}) do
        if hud:IsValid() and valid(hud.TimerShow) then return hud end
    end
end

-- Puts the timer and the HUD back the game's way.
local function release()
    local timer = find_timer()
    if timer then
        local ok, problem = pcall(function() timer:OnUnpause() end)
        if not ok then log("Unpause failed: " .. tostring(problem)) end
    end
    local hud = find_hud()
    if hud then
        local ok, problem = pcall(function() hud:TimerStateSwitched_Event(hud.TimerActivated) end)
        if not ok then log("Showing the HUD timer failed: " .. tostring(problem)) end
    end
    held, hidden_hud = {}, nil
end

local function hold()
    local timer = find_timer()
    local state = "no timer"
    if timer then
        local address = timer:GetAddress()
        if timer.StalkerSpawned then
            state = "stalker already here"
        else
            local now = timer["Time in Deciseconds"]
            if held[address] == nil then
                held[address] = math.max(now, MIN_HOLD)
                log(string.format("Holding the countdown at %d s (it was at %d s)", held[address] // 10, now // 10))
            end
            if now ~= held[address] then timer["Time in Deciseconds"] = held[address] end
            timer:OnPause()
            state = "held " .. held[address]
        end
    end
    local hud = find_hud()
    if hud then
        if hud.TimerShow:GetVisibility() ~= COLLAPSED then hud.TimerShow:SetVisibility(COLLAPSED) end
        local address = hud:GetAddress()
        if hidden_hud ~= address then
            hidden_hud = address
            hud:ResetTimer_Event() -- stops the danger animation if it was already playing
        end
    end
    ModRef:SetSharedVariable(TEST_VARIABLE, state)
end

local tab = AdminTabs.AddTab({ id = "GoonerDLC", title = "Gooner DLC" })
tab:AddChoice("Boss Timer", OPTIONS, off and 1 or 0, function(index)
    local now_off = index == 1
    if now_off == off then return end
    off = now_off
    save_off(off)
    log("Boss timer is now " .. OPTIONS[index + 1])
    if not off then release() end
end)

LoopInGameThreadWithDelay(TICK_MS, function()
    AdminTabs.Poll()
    if off then
        local ok, problem = pcall(hold)
        if not ok then log("Hold failed: " .. tostring(problem)) end
    end
end)

log("Loaded, boss timer " .. (off and "Off" or "On"))
