-- AnimationsPlus: the player's own scenes with humanoid enemies, from the library's OLL sequences.
--
-- Each scene is a row added to the enemy's own scene table (DT_WitnessSex, DT_BansheeSex, ...), so the game's own scene
-- handler runs it: its camera, its W/S stages, its climax bar and its ending, as NurseTouch's Kiss From Behind does.
-- The rows have no montages; this module plays the player's clip in his DefaultSlot and the enemy's clip on her mesh.
-- Stage 1-3 play the sequence's loops; once the climax bar is full and the player goes on, its climax (or its last
-- loop once more) plays, the game's Purification event fires, and the interaction ends as the game's own scenes end.
--
-- While the player aims at a matching enemy, a roll (the chance) decides whether the game picks one of these rows or
-- one of its own: on "ours" the game's rows are switched off and ours on, from the side each scene is played from (in
-- front or behind, as the game's rows do); otherwise ours are off and the game's rows are as the game made them.
-- NurseTouch's Kiss From Behind row (in DT_WitnessSex) is NurseTouch's: it is only switched off while ours win.
-- In Free Mode the same rows are also in the Twisted's, the Twisted Nurse's and the Witness's scene lists (D), whatever
-- the chance; there the list ends the scene after Purification.
--
-- main.lua calls update(player) every tick. Nothing keeps a game object between ticks except by address.

local UEHelpers = require("UEHelpers")
local DATA = require("player_scenes_data") -- Written by ap_player_build.py.
local scene_name = require("scene_names") -- titles as the game's font can draw them

local TABLE_DIR = "/Game/Blueprints/Player/Interactions/"
-- Enemy class -> its scene table, its skeleton (an enemy clip plays only on its own) and its rig family. A class not
-- listed counts as its nearest listed parent (the Witness's Lust, Red and Sloth versions are hers).
local ENEMIES = {
    BP_TwistedNurse_C = { table = "DT_WitnessSex", skeleton = "Twisted", variant = "twisted", voice = "Twisted" },
    BP_Twisted_C = { table = "DT_WitnessSex", skeleton = "Twisted", variant = "twisted", voice = "Twisted" },
    BP_Witness_C = { table = "DT_WitnessSex", skeleton = "Witness", variant = "witness", voice = "Witness" },
}
-- Free Mode's scene lists ("Scenes", D to switch): each character's dialogue asset holds a DE_StartSceneSelector whose
-- Scenes the list copies when it opens. Ours are appended to those of the characters that can play them.
local LIST_CLASS = "DE_StartSceneSelector_C"
local LISTS = {
    DIS_Twisted = { table = "DT_WitnessSex", variant = "twisted" },
    DIS_Twisted1 = { table = "DT_WitnessSex", variant = "twisted" }, -- the Twisted Nurse
    DIS_Witness = { table = "DT_WitnessSex", variant = "witness" },
}
local LIST_EVERY_TICKS = 20
local FIELD = {
    name = "Name_2_238638F249DE6D7D55C2828B6A7E9B20",
    animation = "Animation_18_B3E1E06D4393F322E226088A34C4879A",
    player_montage = "PlayerMontage_2_3C1386214D3CDFDAA0CB969D98F9E52A",
    npc_montage = "NPCMontage_4_EFDFA2E449426E7EFF4CCAB705208D09",
    unconscious = "NPCUnconscious_12_3F39B04B4A2BD0A8C24E399443E241F1",
    context = "ContextualSettings_74_8BB80D564193B78460CB0E8348A96875",
    can_context = "CanBeContextual_12_52D8872D45F50F894920D3AB612C9673",
    in_front = "InFront_13_529801B742FBA50F9892989D9B4F966C",
    bones = "RelevantBones_4_7A33A7914121F256ECD764AB3467E24A",
    tags = "SceneTags_94_C7BDFD0D4FC07F9E3783DEB587897D1C",
}
local TAG = "AnimationsPlus"
local FOREIGN_TAG = "NurseTouchKissBehind" -- NurseTouch's own row; left to NurseTouch except while ours win
local SLOT = "DefaultSlot"
local BLEND_SECONDS = 0.2
local LOOP_COUNT = 10000
local SYNC_SECONDS = 0.05
local HAND_OVER_SECONDS = BLEND_SECONDS + 0.15
local END_AFTER_PURIFY_SECONDS = 1.95 -- as the game's own nurse scene: EndInteraction 1.95 s after Purification
local VIEW_PITCH_MIN, VIEW_PITCH_MAX = -80.0, 45.0
local VIEW_CHANGE_DEG = 20.0
local CUM_BONE, CUM_YAW = "penis_06", 270.0 -- measured in game for the player's own shaft (GhostKiss)
local CUM_PACKAGE, CUM_NAME = "/Game/Blueprints/Effects/NS_Cum", "NS_Cum"
local KEEP_RELATIVE_OFFSET, NO_POOLING = 0, 0
local ANIMATION_BLUEPRINT = 0
local SOUNDS = {
    slap = { "/Game/Audio/SexFoley/OpenNSFW/Plap/SC_DoggyStyle", "SC_DoggyStyle", 0.7 },
    cum = { "/Game/Audio/SexFoley/Homemade/Cum", "Cum", 1.0 },
}
local VOICES = {
    Twisted = { dir = "/Game/Audio/Voice/Monsters/Twisted/", climax = "S_Twisted_SexClimax", fast = "S_Twisted_SexMoanFast%02d", count = 7 },
    Witness = { dir = "/Game/Audio/Voice/Monsters/Witness/", climax = "S_WitnessClimax", fast = "S_WitnessMoanFast%02d", count = 8 },
}
local SELECTOR_CLASS = "BP_SelectableSceneActor_C"
local OUTFIT_CLASS = "/Game/Blueprints/Components/Outfit/BPC_OutfitComponent.BPC_OutfitComponent_C"
local EVENT_LIBRARY = "/Script/EasyEventSystem.Default__EasyEventManagerLibrary"

return function(ctx)
    local log = ctx.log
    local chance = ctx.chance
    local scene = nil
    local forced = nil -- a scene id, for tests: only that one of ours can be picked
    local target_address, ours_now, rolled_table = nil, false, nil
    local tables = {} -- table name -> { originals = { row -> bool }, ours = { row -> scene } }

    local function valid(o) return o ~= nil and o:IsValid() end
    -- Not UEHelpers.FindOrAddFName: for a new name ending in _<number> (most scene ids) its lookup returns "None_<n>",
    -- which is not NAME_None, so the name was never added and the tag read back as "None_1". FNAME_Add also finds.
    local function fname(t) return FName(t, EFindName.FNAME_Add) end
    local function statics() return StaticFindObject("/Script/Engine.Default__GameplayStatics") end

    local function load(package, name)
        local helpers = StaticFindObject("/Script/AssetRegistry.Default__AssetRegistryHelpers")
        local asset = helpers:GetAsset({ PackageName = fname(package), AssetName = fname(name) })
        if asset:IsValid() then return asset end
        return nil
    end

    local function enemy_info(actor)
        local ok, info = pcall(function()
            local class = actor:GetClass()
            for _ = 1, 8 do
                if not valid(class) then return nil end
                local i = ENEMIES[class:GetFName():ToString()]
                if i then return i end
                class = class:GetSuperStruct()
            end
        end)
        return ok and info or nil
    end

    local function plays(s, variant)
        for _, v in ipairs(s.variants) do
            if v == variant then return true end
        end
        return false
    end

    local function sex_table(name)
        local dt = StaticFindObject(TABLE_DIR .. name .. "." .. name)
        if valid(dt) then return dt end
        return load(TABLE_DIR .. name, name)
    end

    local function row_tags(row)
        local out = {}
        pcall(function()
            local tags = row[FIELD.tags]
            for i = 1, tags:GetArrayNum() do out[tags[i]:ToString()] = true end
        end)
        return out
    end

    -- Our rows go in once per table (they stay for the session), each a copy of one of the game's rows from the
    -- same side, with no montages, no bone it must be aimed at, and our tags.
    local function prepare(name, dt)
        local t = tables[name]
        if t then return t end
        t = { originals = {}, ours = {}, foreign = {} }
        local game_rows = {}
        for _, row_name in ipairs(dt:GetRowNames() or {}) do
            -- UE4SS hands these back as plain strings (an FName's ToString is taken in case a version does not)
            local rn = type(row_name) == "string" and row_name or row_name:ToString()
            local row = dt:FindRow(rn)
            if row then
                local tags = row_tags(row)
                if tags[FOREIGN_TAG] then
                    t.foreign[rn] = true
                elseif not tags[TAG] then
                    t.originals[rn] = row[FIELD.context][FIELD.can_context]
                    table.insert(game_rows, { name = rn, front = row[FIELD.context][FIELD.in_front] })
                end
            end
        end
        for _, s in ipairs(DATA.scenes) do
            local rn = "AP_" .. s.id
            if not dt:FindRow(rn) then
                local front = s.side ~= "behind"
                local source = nil
                for _, g in ipairs(game_rows) do
                    if g.front == front then source = g.name break end
                end
                source = source or (game_rows[1] and game_rows[1].name)
                if source then
                    dt:AddRow(rn, dt:FindRow(source))
                    local row = dt:FindRow(rn)
                    row[FIELD.name] = FText(scene_name(s.title))
                    local animation = row[FIELD.animation]
                    animation[FIELD.player_montage] = nil
                    animation[FIELD.npc_montage] = nil
                    animation[FIELD.unconscious] = nil
                    local context = row[FIELD.context]
                    context[FIELD.in_front] = front
                    context[FIELD.can_context] = false
                    pcall(function() context[FIELD.bones]:Empty() end)
                    local tags = row[FIELD.tags]
                    tags[tags:GetArrayNum() + 1] = fname(TAG)
                    tags[tags:GetArrayNum() + 1] = fname("AP:" .. s.id)
                end
            end
            if dt:FindRow(rn) then t.ours[rn] = s end
        end
        tables[name] = t
        local n = 0
        for _ in pairs(t.ours) do n = n + 1 end
        log(string.format("Added %d player scenes to %s", n, name))
        return t
    end

    -- Free Mode's lists: appends our rows to each known character's selector once (a list already open keeps its copy).
    -- Checked by the rows themselves, as a selector can be loaded again at another address or the same one.
    local function add_to_lists()
        for _, selector in ipairs(FindAllOf(LIST_CLASS) or {}) do
            if valid(selector) then
                local full = selector:GetFullName()
                local where = nil
                for dis, w in pairs(LISTS) do
                    if full:find("/" .. dis .. "." .. dis .. ":", 1, true) then where = w end
                end
                local dt = where and sex_table(where.table)
                if dt then
                    local t = prepare(where.table, dt)
                    local scenes = selector.Scenes
                    local have = {}
                    for i = 1, scenes:GetArrayNum() do have[scenes[i].RowName:ToString()] = true end
                    local added = 0
                    for _, s in ipairs(DATA.scenes) do
                        local rn = "AP_" .. s.id
                        if t.ours[rn] and not have[rn] and plays(s, where.variant) then
                            scenes[scenes:GetArrayNum() + 1] = { DataTable = dt, RowName = fname(rn) }
                            added = added + 1
                        end
                    end
                    if added > 0 then
                        log(string.format("Added %d player scenes to the scene list of %s (%d in it now)", added,
                            full:match("FreemodeInfo/([%w_]+)%.") or full, scenes:GetArrayNum()))
                    end
                end
            end
        end
    end

    local function set_rows(dt, t, ours, variant, restore_game)
        if not t then return end
        for rn, s in pairs(t.ours) do
            local row = dt:FindRow(rn)
            if row then
                local fits = plays(s, variant)
                if forced and forced ~= s.id then fits = false end -- tests: only the forced scene
                row[FIELD.context][FIELD.can_context] = ours and fits
            end
        end
        if ours or restore_game then
            for rn, original in pairs(t.originals) do
                local row = dt:FindRow(rn)
                -- NurseTouch rolls its Kiss From Behind against the game's "Test_0"; when ours lose, that row is its.
                if row and (ours or not (next(t.foreign) and rn == "Test_0")) then
                    row[FIELD.context][FIELD.can_context] = (not ours) and original
                end
            end
        end
        if ours then
            for rn in pairs(t.foreign) do
                local row = dt:FindRow(rn)
                if row then row[FIELD.context][FIELD.can_context] = false end
            end
        end
    end

    -- Each tick while not in a scene: roll for a newly aimed-at enemy, and keep ours winning while they won (another
    -- mod may write the table once when the target changes).
    local function sync_tables(player)
        if not player or (valid(player.CurrentSScene) and player.InInteraction) then return end
        local enemy, info = nil, nil
        local interactable = player.CurrentInteractable
        if valid(interactable) then
            local owner = interactable:GetOwner()
            if valid(owner) then
                info = enemy_info(owner)
                if info then enemy = owner end
            end
        end
        local address = enemy and enemy:GetAddress() or nil
        if address ~= target_address then
            if rolled_table then -- the previous target's table goes back as the game made it
                local dt = sex_table(rolled_table)
                if dt and tables[rolled_table] then set_rows(dt, tables[rolled_table], false, nil, true) end
            end
            target_address, rolled_table = address, nil
            if enemy then
                ours_now = math.random() < chance
                rolled_table = info.table
                local dt = sex_table(info.table)
                if dt then set_rows(dt, prepare(info.table, dt), ours_now, info.variant, true) end
                if ours_now then log("Rolled an AnimationsPlus scene for " .. enemy:GetClass():GetFName():ToString()) end
            end
        elseif enemy and ours_now then
            local dt = sex_table(info.table)
            if dt then set_rows(dt, tables[info.table], true, info.variant, false) end
        end
    end

    local function scene_of(handler)
        local id = nil
        pcall(function()
            local tags = handler.SexSceneInfo[FIELD.tags]
            for i = 1, tags:GetArrayNum() do
                local t = tags[i]:ToString()
                if t:sub(1, 3) == "AP:" then id = t:sub(4) end
            end
        end)
        if not id then return nil end
        for _, s in ipairs(DATA.scenes) do
            if s.id == id then return s end
        end
        return nil
    end

    local function our_montage(mesh, address)
        local instance = mesh:GetAnimInstance()
        if not valid(instance) or not address then return nil end
        local montage = instance:GetCurrentActiveMontage()
        if not valid(montage) or montage:GetAddress() ~= address then return nil end
        return instance, montage
    end

    local function play_clip(state, enemy, player, key)
        local timing = DATA.clips[key]
        local player_name = "AS_APP_" .. state.variant .. "_" .. key
        local enemy_name = "AS_APE_" .. state.skeleton .. "_" .. key
        local pclip = load(DATA.dir .. player_name, player_name)
        local eclip = load(DATA.dir .. enemy_name, enemy_name)
        if not pclip or not eclip then
            error("could not load " .. (pclip and enemy_name or player_name))
        end
        local montage = player.Mesh:GetAnimInstance():PlaySlotAnimationAsDynamicMontage(pclip, fname(SLOT),
            BLEND_SECONDS, BLEND_SECONDS, 1.0, timing.once and 1 or LOOP_COUNT, 0.0, 0.0)
        if not valid(montage) then error("could not play " .. player_name) end
        enemy.Mesh:PlayAnimation(eclip, not timing.once)
        state.montage, state.key, state.last_position = montage:GetAddress(), key, 0.0
    end

    local function place_enemy(player, enemy)
        enemy.Mesh:K2_SetWorldLocationAndRotation(player.Mesh:K2_GetComponentLocation(),
            player.Mesh:K2_GetComponentRotation(), false, {}, true)
    end

    local function play_sound(kind, at_actor)
        local e = SOUNDS[kind]
        local sound = e and load(e[1], e[2])
        if sound then
            statics():PlaySoundAtLocation(at_actor, sound, at_actor.Mesh:GetSocketLocation(fname("pelvis")),
                { Pitch = 0, Yaw = 0, Roll = 0 }, e[3], 0.95 + math.random() * 0.1, 0.0, nil, nil, nil, nil)
        end
    end

    local function play_voice(state, enemy, climax)
        local v = VOICES[state.voice]
        if not v then return end
        local name = climax and v.climax or string.format(v.fast, math.random(v.count))
        local sound = load(v.dir .. name, name)
        if sound then
            local at = enemy:K2_GetActorLocation()
            statics():PlaySoundAtLocation(enemy, sound, { X = at.X, Y = at.Y, Z = at.Z + 40 }, { Pitch = 0, Yaw = 0, Roll = 0 },
                climax and 1.0 or 0.7, 0.96 + math.random() * 0.08, 0.0, nil, nil, nil, nil)
        end
    end

    local function spurt(player)
        local system = load(CUM_PACKAGE, CUM_NAME)
        local library = StaticFindObject("/Script/Niagara.Default__NiagaraFunctionLibrary")
        if system and library:IsValid() then
            library:SpawnSystemAttached(system, player.Mesh, fname(CUM_BONE), { X = 0, Y = 0, Z = 0 },
                { Pitch = 0, Yaw = CUM_YAW, Roll = 0 }, KEEP_RELATIVE_OFFSET, true, true, NO_POOLING, true)
        end
    end

    local function scene_list(handler)
        for _, actor in ipairs(FindAllOf(SELECTOR_CLASS) or {}) do
            if valid(actor.CurrentScene) and actor.CurrentScene:GetAddress() == handler:GetAddress() then return actor end
        end
        return nil
    end

    -- The camera follows the control rotation. Each clip has a look at her from the player's head (ap_player_build.py,
    -- averaged over the clip, in his mesh's space), as the scenes face every which way. Set at the start, and again on a
    -- clip change only when it moves further than VIEW_CHANGE_DEG, so the player's own look is mostly left alone.
    local function apply_view(state, player, key, always)
        local d = DATA.views and DATA.views[state.variant] and DATA.views[state.variant][key]
        if not d or not valid(player.Controller) then return end
        local r = math.rad(player.Mesh:K2_GetComponentRotation().Yaw)
        local x, y = d[1] * math.cos(r) - d[2] * math.sin(r), d[1] * math.sin(r) + d[2] * math.cos(r)
        local yaw = math.deg(math.atan(y, x))
        local pitch = math.max(VIEW_PITCH_MIN, math.min(VIEW_PITCH_MAX, math.deg(math.atan(d[3], math.sqrt(x * x + y * y)))))
        if not always and state.view then
            local dy = math.abs((yaw - state.view.yaw + 180) % 360 - 180)
            if math.max(dy, math.abs(pitch - state.view.pitch)) < VIEW_CHANGE_DEG then return end
        end
        state.view = { yaw = yaw, pitch = pitch }
        player.Controller:SetControlRotation({ Pitch = pitch, Yaw = yaw, Roll = 0 })
    end

    local function begin(player, handler, s)
        local enemy = handler.InteractedActor
        local info = valid(enemy) and enemy_info(enemy)
        if not info then
            error("the scene is not on an enemy AnimationsPlus knows (" .. (valid(enemy) and enemy:GetClass():GetFName():ToString() or "none") .. ")")
        end
        if not plays(s, info.variant) then error(s.title .. " has no " .. info.variant .. " clips") end
        local mesh = enemy.Mesh
        local loc, rot, sc = mesh.RelativeLocation, mesh.RelativeRotation, mesh.RelativeScale3D
        scene = {
            handler_address = handler:GetAddress(), enemy_address = enemy:GetAddress(), id = s.id, title = s.title,
            scene = s, variant = info.variant, skeleton = info.skeleton, voice = info.voice,
            in_list = scene_list(handler) ~= nil,
            saved = { location = { X = loc.X, Y = loc.Y, Z = loc.Z }, rotation = { Pitch = rot.Pitch, Yaw = rot.Yaw, Roll = rot.Roll },
                      scale = { X = sc.X, Y = sc.Y, Z = sc.Z }, update_rate = mesh.bEnableUpdateRateOptimizations,
                      tick_option = mesh.VisibilityBasedAnimTickOption, player_tick_option = player.Mesh.VisibilityBasedAnimTickOption },
        }
        mesh.bEnableUpdateRateOptimizations = false
        mesh.VisibilityBasedAnimTickOption = 0
        player.Mesh.VisibilityBasedAnimTickOption = 0
        pcall(function() if valid(enemy.CurrentWeapon) then enemy.CurrentWeapon:SetActorHiddenInGame(true) end end)
        -- The Twisted has Expose() of her own; the Witness's clothes are on her outfit component (as the scene list's
        -- RedoExposure uses), which the list puts back itself when it ends.
        if not pcall(function() enemy:Expose() end) then
            pcall(function()
                local class = StaticFindObject(OUTFIT_CLASS)
                local outfit = valid(class) and enemy:GetComponentByClass(class)
                if valid(outfit) then outfit:Expose() end
            end)
        end
        player:EnableCamera(true) -- the game's own player montage turns the camera on; our rows have none
        mesh:SetWorldScale3D({ X = 1.0, Y = 1.0, Z = 1.0 })
        place_enemy(player, enemy)
        play_clip(scene, enemy, player, s.stages[1])
        apply_view(scene, player, s.stages[1], true)
        log("Player scene started: " .. s.title .. (scene.in_list and " (from the scene list)" or ""))
    end

    local function finish(player, reason)
        local state = scene
        scene = nil
        log("Player scene ended: " .. reason)
        local enemy = nil
        for _, e in ipairs(FindAllOf("Character") or {}) do
            if e:IsValid() and e:GetAddress() == state.enemy_address then enemy = e break end
        end
        if player then
            local instance, montage = our_montage(player.Mesh, state.montage)
            if instance then instance:Montage_Stop(BLEND_SECONDS, montage) end
            player.Mesh.VisibilityBasedAnimTickOption = state.saved.player_tick_option
        end
        if enemy and enemy.Mesh:IsValid() then
            local mesh = enemy.Mesh
            mesh:SetAnimationMode(ANIMATION_BLUEPRINT, true)
            mesh:K2_SetRelativeLocationAndRotation(state.saved.location, state.saved.rotation, false, {}, true)
            mesh:SetRelativeScale3D(state.saved.scale)
            mesh.bEnableUpdateRateOptimizations = state.saved.update_rate
            mesh.VisibilityBasedAnimTickOption = state.saved.tick_option
            pcall(function() if valid(enemy.CurrentWeapon) then enemy.CurrentWeapon:SetActorHiddenInGame(false) end end)
        end
    end

    local function leave(handler)
        local list = scene_list(handler)
        if list then list:EndAnyScene() else handler:ForceEndScene() end
    end

    local function drive(player, handler)
        local state = scene
        local enemy = handler.InteractedActor
        if not valid(enemy) then
            finish(player, "the enemy is gone")
            if not state.in_list and player.InInteraction then player:EndInteraction() end
            return
        end
        place_enemy(player, enemy)
        local s = state.scene
        local timing = DATA.clips[state.key]
        local instance, montage = our_montage(player.Mesh, state.montage)
        if not instance then
            if not state.ending then play_clip(state, enemy, player, state.key) end -- something took the slot over
            return
        end
        local raw = instance:Montage_GetPosition(montage)
        local position = timing.once and raw or raw % timing.length
        if math.abs(enemy.Mesh:GetPosition() - position) > SYNC_SECONDS then enemy.Mesh:SetPosition(position, false) end
        local from = state.last_position
        local wrapped = position < from
        local function crossed(at)
            if wrapped then return at > from or at <= position end
            return at > from and at <= position
        end
        for i, at in ipairs(timing.counts) do
            if crossed(at) then
                if not handler.EndingSequence then
                    StaticFindObject(EVENT_LIBRARY):CallEvent(handler, fname("CLevel"), "", nil)
                end
                if timing.kind == "vag" or timing.kind == "ass" then play_sound("slap", enemy) end
                if i % 2 == 0 then play_voice(state, enemy, false) end
            end
        end
        for i, at in ipairs(timing.cum or {}) do
            if crossed(at) then
                spurt(player)
                if i == 1 then
                    play_sound("cum", enemy)
                    play_voice(state, enemy, true)
                end
            end
        end
        if timing.purify and state.ending and crossed(timing.purify) and not state.purified_at then
            log("Player scene: purification")
            state.purified_at = ctx.now()
            StaticFindObject(EVENT_LIBRARY):CallEvent(handler, fname("Purification"), "", nil)
        end
        state.last_position = position

        if state.ending then
            if not state.frozen and position >= timing.length - HAND_OVER_SECONDS then
                state.frozen = true -- held on its last pose rather than blending back
                instance:Montage_SetPlayRate(montage, 0.0)
                enemy.Mesh:SetPlayRate(0.0)
            end
            if state.purified_at and not state.ended and ctx.now() - state.purified_at >= END_AFTER_PURIFY_SECONDS then
                state.ended = true
                if not state.in_list then
                    log("Player scene: end of interaction")
                    player:EndInteraction()
                end
            end
            return
        end
        local wanted = handler.EndingSequence and s.ending or s.stages[(handler.CurrentStage or 0) + 1] or s.stages[#s.stages]
        if wanted ~= state.key then
            -- Change at the shallow end of a stroke (one cycle boundary), where the clips meet.
            local cycle = math.max(timing.cycle or 1.0, 0.2)
            if handler.EndingSequence or wrapped or math.floor(position / cycle) ~= math.floor(from / cycle) then
                state.ending = handler.EndingSequence and true or false
                log("Player scene: " .. (state.ending and "ending" or ("stage " .. ((handler.CurrentStage or 0) + 1))))
                play_clip(state, enemy, player, wanted)
                apply_view(state, player, wanted, false)
            end
        end
    end

    local ticks, list_problem = 0, nil
    local function update(player)
        ticks = ticks + 1
        if ticks % LIST_EVERY_TICKS == 1 then
            local ok, message = pcall(add_to_lists)
            if not ok and message ~= list_problem then log("Could not add to the scene lists: " .. tostring(message)) end
            list_problem = not ok and message or nil
        end
        sync_tables(player)
        local handler = player and player.CurrentSScene
        local current = valid(handler) and player.InInteraction and handler or nil
        if scene and (not current or current:GetAddress() ~= scene.handler_address) then
            finish(player, "the game's scene ended")
        end
        if current and not scene then
            local s = scene_of(current)
            if s then
                local ok, message = pcall(begin, player, current, s)
                if not ok then
                    log("Could not start the player scene: " .. tostring(message))
                    if scene then finish(player, "could not start") end
                    leave(current)
                    return
                end
            end
        end
        if scene then
            local ok, message = pcall(drive, player, current)
            if not ok then
                log("Player scene failed: " .. tostring(message))
                finish(player, "error")
                leave(current)
            end
        end
    end

    return {
        update = update,
        set_chance = function(v) chance = v; target_address = nil end,
        set_forced = function(id) forced = (id ~= "" and id) or nil; target_address = nil end,
        scenes = DATA.scenes,
        enemies = ENEMIES,
    }
end
