-- NurseTouch: the player's kiss-from-behind scene with a Twisted Nurse.
--
-- A row in the nurse's own scene table (the game's Witness and Twisted Nurse share DT_WitnessSex), so the game's own
-- scene handler runs it: its camera, its W/S stages, its climax bar and its end. The row has no montages of its own;
-- this module plays its clips in the game's slots, as GhostKiss's Neck scene does. The clips are keyed for the nurse's
-- body, so the row is only in the table while the player aims at a Twisted Nurse. When the player approaches a nurse
-- from behind the game picks one of the table's "from behind" rows at random; each time the player aims at a nurse,
-- the chance decides whether that pick is this scene or the game's own.
--
-- main.lua passes in its helpers and calls update(live, player) every tick.

local STAGES = require("kissbehind_stages") -- Written by make_kissbehind_keys.py.

local SEX_TABLE_PACKAGE = "/Game/Blueprints/Player/Interactions/DT_WitnessSex"
local SEX_TABLE_NAME = "DT_WitnessSex"
local GAME_BEHIND_ROW = "Test_0" -- The game's own "From Behind", which the new row starts as a copy of.
local ROW = "NurseTouchKissBehind"
local TITLE = "Kiss From Behind"
local TAG = "NurseTouchKissBehind"
local FIELD = {
    name = "Name_2_238638F249DE6D7D55C2828B6A7E9B20",
    animation = "Animation_18_B3E1E06D4393F322E226088A34C4879A",
    player_montage = "PlayerMontage_2_3C1386214D3CDFDAA0CB969D98F9E52A",
    npc_montage = "NPCMontage_4_EFDFA2E449426E7EFF4CCAB705208D09",
    unconscious = "NPCUnconscious_12_3F39B04B4A2BD0A8C24E399443E241F1",
    context = "ContextualSettings_74_8BB80D564193B78460CB0E8348A96875",
    can_context = "CanBeContextual_12_52D8872D45F50F894920D3AB612C9673",
    tags = "SceneTags_94_C7BDFD0D4FC07F9E3783DEB587897D1C",
}
local NURSE_CLIP = "AS_Twisted_PlayerKiss"
local PLAYER_CLIP = "AS_Player_NurseKiss"
local SLOT = "DefaultSlot" -- Both of the game's own nurse scenes play in this slot, on her and on the player.
local STAGE_CLIPS = { "Loop1", "Loop2", "Loop3" } -- By the handler's stage, counted from 0.
local BLEND_SECONDS = 0.2
local LOOP_COUNT = 10000 -- A stage's clip loops until the player changes stage.
local SYNC_SECONDS = 0.05 -- Her clip is put back in step with the player's when further apart than this.
local HAND_OVER_SECONDS = BLEND_SECONDS + 0.15 -- A clip played once hands over this long before its end.
-- The player's head is against hers for the kiss, so looking ahead puts the view inside her hair. It looks down over her
-- left shoulder instead, at her chest and his hands.
local LOOK_PITCH_DEG = -40.0
local LOOK_YAW_DEG = -25.0
local CUM_BONE = "penis_06"
local CUM_YAW = 270.0 -- Measured in game for GhostKiss: the effect shoots along +X, the player's shaft runs along -Y.
local SOUNDS = {
    slap = { "/Game/Audio/SexFoley/OpenNSFW/Plap/SC_DoggyStyle", "SC_DoggyStyle", 0.8 },
    slide = { "/Game/Audio/SexFoley/OpenNSFW/Slide/SC_SlideOut", "SC_SlideOut", 0.8 },
    cum = { "/Game/Audio/SexFoley/Homemade/Cum", "Cum", 1.0 },
    internal = { "/Game/Audio/SexFoley/OpenNSFW/Extra/SC_InternalCumshot", "SC_InternalCumshot", 0.9 },
}
-- The game's own nurse scene purifies her (its montage's Purification event, which runs her DoSexEndSequence: sanity,
-- perks, and with the Purification perk her dissolve) and ends the player's interaction 1.95 s later (EndInteraction at
-- 8.03 s of the player's montage, Purification at 6.07 s of hers). Nothing else is done to her, so neither is it here.
local END_AFTER_PURIFY_SECONDS = 1.95
local SELECTOR_CLASS = "BP_SelectableSceneActor_C"
local EVENT_LIBRARY = "/Script/EasyEventSystem.Default__EasyEventManagerLibrary"

return function(ctx)
    local log, load_by_package, UEHelpers = ctx.log, ctx.load_by_package, ctx.UEHelpers

    local chance = ctx.chance
    local scene = nil -- The game's scene handler running this scene, while it does.
    local target_address = nil -- The nurse the chance was last rolled for.
    local in_table = false

    local function valid(object)
        return object ~= nil and object:IsValid()
    end

    local function fname(text)
        return UEHelpers.FindOrAddFName(text)
    end

    local function sex_table()
        local dt = StaticFindObject(SEX_TABLE_PACKAGE .. "." .. SEX_TABLE_NAME)
        if valid(dt) then
            return dt
        end
        return load_by_package(SEX_TABLE_PACKAGE, SEX_TABLE_NAME)
    end

    local function set_contextual(dt, row_name, on)
        local row = dt:FindRow(row_name)
        if row then
            row[FIELD.context][FIELD.can_context] = on
        end
    end

    local function add_row(dt)
        if dt:FindRow(ROW) then
            return true
        end
        local source = dt:FindRow(GAME_BEHIND_ROW)
        if not source then
            log("The nurse's scene table has no " .. GAME_BEHIND_ROW .. " row to copy")
            return false
        end
        dt:AddRow(ROW, source)
        local row = dt:FindRow(ROW)
        row[FIELD.name] = FText(TITLE)
        local animation = row[FIELD.animation]
        animation[FIELD.player_montage] = nil
        animation[FIELD.npc_montage] = nil
        animation[FIELD.unconscious] = nil
        local tags = row[FIELD.tags]
        tags[tags:GetArrayNum() + 1] = fname(TAG)
        return true
    end

    -- Puts the row in while the player aims at a Twisted Nurse, rolls the chance for each nurse, and puts the table
    -- back as the game made it otherwise. Left alone while a scene runs.
    local function sync_table(player)
        if not player or (valid(player.CurrentSScene) and player.InInteraction) then
            return
        end
        local target = nil
        local interactable = player.CurrentInteractable
        if valid(interactable) then
            local owner = interactable:GetOwner()
            if valid(owner) and owner:GetClass():GetFName():ToString() == ctx.NURSE_CLASS then
                target = owner:GetAddress()
            end
        end
        if target == target_address then
            return
        end
        target_address = target
        local dt = sex_table()
        if not dt then
            return
        end
        if target then
            if not add_row(dt) then
                return
            end
            in_table = true
            local ours = math.random() < chance
            set_contextual(dt, ROW, ours)
            set_contextual(dt, GAME_BEHIND_ROW, not ours)
        else
            if in_table then
                dt:RemoveRow(ROW)
                in_table = false
            end
            set_contextual(dt, GAME_BEHIND_ROW, true)
        end
    end

    local function is_ours(handler)
        local ours = false
        pcall(function()
            local tags = handler.SexSceneInfo[FIELD.tags]
            for i = 1, tags:GetArrayNum() do
                if tags[i]:ToString() == TAG then
                    ours = true
                end
            end
        end)
        return ours
    end

    local function player_space(player, point)
        local origin = player.Mesh:K2_GetComponentLocation()
        local forward = player:GetActorForwardVector()
        local right = player:GetActorRightVector()
        return {
            X = origin.X - right.X * point.X + forward.X * point.Y,
            Y = origin.Y - right.Y * point.X + forward.Y * point.Y,
            Z = origin.Z - right.Z * point.X + forward.Z * point.Y + point.Z,
        }
    end

    -- The clip playing in a mesh's slot, if it is still the one this module started there.
    local function our_montage(mesh, address)
        local instance = mesh:GetAnimInstance()
        if not valid(instance) or not address then
            return nil
        end
        local montage = instance:GetCurrentActiveMontage()
        if not valid(montage) or montage:GetAddress() ~= address then
            return nil
        end
        return instance, montage
    end

    local function play_clip(state, nurse, player, name)
        local timing = STAGES.clips[name]
        local played = {}
        for key, part in pairs({ nurse = { nurse.Mesh, NURSE_CLIP }, player = { player.Mesh, PLAYER_CLIP } }) do
            local asset = part[2] .. name
            local clip = load_by_package(ctx.MOD_DIR .. asset, asset)
            if not clip then
                error("Could not load the clip " .. asset)
            end
            local montage = part[1]:GetAnimInstance():PlaySlotAnimationAsDynamicMontage(clip, fname(SLOT),
                BLEND_SECONDS, BLEND_SECONDS, 1.0, timing.cycle and LOOP_COUNT or 1, 0.0, 0.0)
            if not valid(montage) then
                error("Could not play the clip " .. asset)
            end
            played[key] = montage:GetAddress()
        end
        state.montages = played
        state.clip = name
        state.last_position = 0.0
    end

    -- The clips are keyed with the nurse's origin on one spot in the player's space, facing the way the player does.
    local function place_nurse(player, nurse)
        nurse.Mesh:K2_SetWorldLocationAndRotation(player_space(player, STAGES.nurse_root),
            player.Mesh:K2_GetComponentRotation(), false, {}, true)
    end

    local function play_sound(kind, nurse)
        local entry = SOUNDS[kind]
        local sound = entry and load_by_package(entry[1], entry[2])
        if not sound then
            return
        end
        StaticFindObject("/Script/Engine.Default__GameplayStatics"):PlaySoundAtLocation(nurse, sound,
            nurse.Mesh:GetSocketLocation(fname("pelvis")), { Pitch = 0, Yaw = 0, Roll = 0 }, entry[3],
            ctx.random_between(0.95, 1.05), 0.0, nil, nil, nil, nil)
    end

    local function spurt(player)
        local system = load_by_package(ctx.CUM_PACKAGE, ctx.CUM_NAME)
        local library = StaticFindObject("/Script/Niagara.Default__NiagaraFunctionLibrary")
        if system and library:IsValid() then
            library:SpawnSystemAttached(system, player.Mesh, fname(CUM_BONE), { X = 0, Y = 0, Z = 0 },
                { Pitch = 0, Yaw = CUM_YAW, Roll = 0 }, ctx.KEEP_RELATIVE_OFFSET, true, true, ctx.NO_POOLING, true)
            log("Kiss from behind: spurt")
        end
    end

    local function scene_list(handler)
        for _, actor in ipairs(FindAllOf(SELECTOR_CLASS) or {}) do
            if valid(actor.CurrentScene) and actor.CurrentScene:GetAddress() == handler:GetAddress() then
                return actor
            end
        end
        return nil
    end

    local function begin(player, handler)
        local nurse = handler.InteractedActor
        if not valid(nurse) or nurse:GetClass():GetFName():ToString() ~= ctx.NURSE_CLASS then
            error("the scene is not on a Twisted Nurse")
        end
        local mesh = nurse.Mesh
        local location, rotation, scale = mesh.RelativeLocation, mesh.RelativeRotation, mesh.RelativeScale3D
        scene = {
            handler_address = handler:GetAddress(),
            nurse_address = nurse:GetAddress(),
            in_list = scene_list(handler) ~= nil,
            saved = {
                location = { X = location.X, Y = location.Y, Z = location.Z },
                rotation = { Pitch = rotation.Pitch, Yaw = rotation.Yaw, Roll = rotation.Roll },
                scale = { X = scale.X, Y = scale.Y, Z = scale.Z },
                update_rate = mesh.bEnableUpdateRateOptimizations,
                tick_option = mesh.VisibilityBasedAnimTickOption,
                player_tick_option = player.Mesh.VisibilityBasedAnimTickOption,
            },
        }
        -- The update rate optimisation would let the two clips drift apart.
        mesh.bEnableUpdateRateOptimizations = false
        mesh.VisibilityBasedAnimTickOption = 0
        player.Mesh.VisibilityBasedAnimTickOption = 0
        ctx.set_weapon_shown(nurse, false)
        pcall(function() nurse:Expose() end)
        -- The game's own player montage turns the camera on as it starts; this row has none.
        player:EnableCamera(true)
        if valid(player.Controller) then
            player.Controller:SetControlRotation({ Pitch = LOOK_PITCH_DEG, Yaw = player:K2_GetActorRotation().Yaw + LOOK_YAW_DEG, Roll = 0 })
        end
        mesh:SetWorldScale3D({ X = 1.0, Y = 1.0, Z = 1.0 })
        place_nurse(player, nurse)
        play_clip(scene, nurse, player, "Enter")
        log("Kiss from behind started from the game's scene" .. (scene.in_list and " list" or ""))
    end

    local function finish(live, player, reason)
        local state = scene
        scene = nil
        log("Kiss from behind ended: " .. reason)
        local nurse = live[state.nurse_address]
        for key, mesh in pairs({ nurse = nurse and nurse.Mesh, player = player and player.Mesh }) do
            if mesh then
                local instance, montage = our_montage(mesh, state.montages and state.montages[key])
                if instance then
                    instance:Montage_Stop(BLEND_SECONDS, montage)
                end
            end
        end
        if nurse then
            local mesh = nurse.Mesh
            mesh:K2_SetRelativeLocationAndRotation(state.saved.location, state.saved.rotation, false, {}, true)
            mesh:SetRelativeScale3D(state.saved.scale)
            mesh.bEnableUpdateRateOptimizations = state.saved.update_rate
            mesh.VisibilityBasedAnimTickOption = state.saved.tick_option
            ctx.set_weapon_shown(nurse, true)
        end
        if player then
            player.Mesh.VisibilityBasedAnimTickOption = state.saved.player_tick_option
        end
    end

    -- The game's own way out of a scene, through the Free Mode scene list when that started it.
    local function leave(handler)
        local list = scene_list(handler)
        if list then
            list:EndAnyScene()
        else
            handler:ForceEndScene()
        end
    end

    local function drive(live, player, handler)
        local state = scene
        local nurse = handler.InteractedActor
        if not valid(nurse) then
            finish(live, player, "the nurse is gone")
            if not state.in_list and player.InInteraction then
                player:EndInteraction()
            end
            return
        end
        place_nurse(player, nurse)
        local timing = STAGES.clips[state.clip]
        local instance, montage = our_montage(player.Mesh, state.montages.player)
        if not instance then
            -- Something else took the slot over: a loop starts again, the entry goes on to the stage, the climax is
            -- over.
            if state.clip == "Enter" then
                play_clip(state, nurse, player, STAGE_CLIPS[handler.CurrentStage + 1] or STAGE_CLIPS[1])
            elseif state.clip ~= "End" then
                play_clip(state, nurse, player, state.clip)
            end
            return
        end
        local raw = instance:Montage_GetPosition(montage)
        local position = timing.cycle and raw % timing.length or raw
        local nurse_instance, nurse_montage = our_montage(nurse.Mesh, state.montages.nurse)
        if nurse_instance and math.abs(nurse_instance:Montage_GetPosition(nurse_montage) - raw) > SYNC_SECONDS then
            nurse_instance:Montage_SetPosition(nurse_montage, raw)
        end

        local from = state.last_position
        local wrapped = position < from
        local function crossed(at)
            if wrapped then
                return at > from or at <= position
            end
            return at > from and at <= position
        end
        for _, event in ipairs(timing.events) do
            if crossed(event[1]) then
                play_sound(event[2], nurse)
                if event[2] == "cum" then
                    ctx.play_voice(nurse, "S_Twisted_SexClimax", player, 1.0)
                end
            end
        end
        for _, at in ipairs(timing.counts) do
            if crossed(at) then
                if not handler.EndingSequence then
                    StaticFindObject(EVENT_LIBRARY):CallEvent(handler, fname("CLevel"), "", nil)
                end
                state.last_voice = ctx.pick_moan(state.last_voice)
                ctx.play_voice(nurse, state.last_voice, player, 0.8)
            end
        end
        for _, at in ipairs(timing.spurts) do
            if crossed(at) then
                spurt(player)
            end
        end
        if timing.purify and crossed(timing.purify) and not state.purified_at then
            log("Kiss from behind: purification")
            state.purified_at = ctx.now()
            StaticFindObject(EVENT_LIBRARY):CallEvent(handler, fname("Purification"), "", nil)
        end
        state.last_position = position

        -- The handler's stage picks the loop; once the climax bar is full and the player goes on, the climax plays.
        local wanted = handler.EndingSequence and "End" or STAGE_CLIPS[handler.CurrentStage + 1] or STAGE_CLIPS[#STAGE_CLIPS]
        if state.clip == "Enter" then
            if position >= timing.length - HAND_OVER_SECONDS then
                log("Kiss from behind: " .. wanted)
                play_clip(state, nurse, player, wanted)
            end
        elseif state.clip == "End" then
            if not state.frozen and position >= timing.length - HAND_OVER_SECONDS then
                -- Held on its last pose rather than blending back to her own animation.
                state.frozen = true
                instance:Montage_SetPlayRate(montage, 0.0)
                if nurse_instance then
                    nurse_instance:Montage_SetPlayRate(nurse_montage, 0.0)
                end
            end
            -- In Free Mode the scene list ends it. Elsewhere it ends as the game's own player montage ends it.
            if state.purified_at and not state.ended and ctx.now() - state.purified_at >= END_AFTER_PURIFY_SECONDS then
                state.ended = true
                if not state.in_list then
                    log("Kiss from behind: end of interaction")
                    player:EndInteraction()
                end
            end
        elseif wanted ~= state.clip then
            -- Every loop passes the shallow end of a thrust once a cycle, where the clips meet.
            if wrapped or math.floor(position / timing.cycle) ~= math.floor(from / timing.cycle) then
                log("Kiss from behind: " .. wanted)
                play_clip(state, nurse, player, wanted)
            end
        end
    end

    local function update(live, player)
        sync_table(player)
        local handler = player and player.CurrentSScene
        -- A destroyed handler still reads as valid until it is cleaned up, and the player's interaction ends with it.
        local current = valid(handler) and player.InInteraction and handler or nil
        if scene and (not current or current:GetAddress() ~= scene.handler_address) then
            finish(live, player, "the game's scene ended")
        end
        if current and not scene and is_ours(current) then
            local ok, message = pcall(begin, player, current)
            if not ok then
                log("Could not start the kiss from behind: " .. tostring(message))
                if scene then
                    finish(live, player, "could not start")
                end
                leave(current)
                return
            end
        end
        if scene then
            local ok, message = pcall(drive, live, player, current)
            if not ok then
                log("Kiss from behind failed: " .. tostring(message))
                finish(live, player, "error")
                leave(current)
            end
        end
    end

    return {
        update = update,
        set_chance = function(value)
            chance = value
            target_address = nil -- Rolled again for the nurse in view.
        end,
        running = function()
            return scene ~= nil
        end,
    }
end
