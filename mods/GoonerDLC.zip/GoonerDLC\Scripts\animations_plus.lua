-- AnimationsPlus's own script: the player's scenes with humanoid enemies, from the library's sequences
-- (player_scenes.lua). The library itself (Shared\AnimationsPlus) needs no script and works for other mods either way.
-- Private: made from a third-party animation pack.

local UEHelpers = require("UEHelpers")
local AdminTabs = require("AdminTabs")

local TICK_MS = 100
-- That a scene with a matching enemy (dungeon, hold E) is one of these instead of the game's own. Free Mode's scene
-- lists always have them, whatever this is.
local CHANCE = 0.5
local CHANCE_OPTIONS = { "Never", "25%", "50%", "75%", "Always" }
local CHANCE_VALUES = { 0.0, 0.25, 0.5, 0.75, 1.0 }
local CHANCE_VARIABLE = "AnimationsPlus_PlayerSceneChance" -- for tests and other mods: 0..1, read each tick

local function log(message)
    print("[AnimationsPlus] " .. tostring(message) .. "\n")
end

local elapsed = 0.0
local scenes = require("player_scenes")({ log = log, chance = CHANCE, now = function() return elapsed end })

local tab = AdminTabs.AddTab({ id = "AnimationsPlus", title = "Animations Plus" })
tab:AddChoice("Player Scene Chance", CHANCE_OPTIONS, 2, function(index)
    scenes.set_chance(CHANCE_VALUES[index + 1] or CHANCE)
    log("Player scene chance is now " .. CHANCE_OPTIONS[index + 1])
end)

local last_override = nil
local FORCE_VARIABLE = "AnimationsPlus_ForceScene" -- for tests: a scene id, or "" for any (nothing sets it in play)
local last_forced = nil
LoopInGameThreadWithDelay(TICK_MS, function()
    elapsed = elapsed + TICK_MS / 1000.0
    AdminTabs.Poll()
    local override = ModRef:GetSharedVariable(CHANCE_VARIABLE)
    if override ~= nil and override ~= last_override then
        last_override = override
        scenes.set_chance(tonumber(override) or CHANCE)
        log("Player scene chance set to " .. tostring(override))
    end
    local forced = ModRef:GetSharedVariable(FORCE_VARIABLE)
    if forced ~= last_forced then
        last_forced = forced
        scenes.set_forced(forced and tostring(forced) or "")
        log("Player scene forced: " .. tostring(forced))
    end
    local controller = FindFirstOf("PlayerController")
    local player = controller and controller:IsValid() and controller.Pawn:IsValid() and controller.Pawn or nil
    local ok, message = pcall(scenes.update, player)
    if not ok then
        log("Player scene update failed: " .. tostring(message))
    end
end)

math.randomseed(os.time())
log("Loaded, player scenes for " .. (function() local n = 0 for _ in pairs(scenes.enemies) do n = n + 1 end return n end)() .. " enemy kinds")
