-- Gooner DLC: the futa nurse and nurse pairs (nurse_touch.lua, formerly the NurseTouch mod) and the extra animations
-- with the player's scenes from them (animations_plus.lua, formerly the AnimationsPlus mod), as one mod. freecam.lua adds
-- Freecam to the game's own perspective switch in the player's sex scenes, and scene_picker.lua a panel of every scene in
-- a Free Mode scene list (Tab during one of its scenes).
-- The animation library stays a shared module, Shared\AnimationsPlus, so other mods can still require("AnimationsPlus").
-- The extra animations are retargeted from the OLL Animations (AP) pack for WickedWhims. Published to the mod loader's
-- repo and releases at the user's request on 2026-11-13.
--
-- Each part is its own module with its own locals and its own game-thread loop, so one failing to load leaves the other
-- running.

local function log(message)
    print("[GoonerDLC] " .. tostring(message) .. "\n")
end

local loaded = {}
local PARTS = { "nurse_touch", "animations_plus", "freecam", "scene_picker" }
for _, part in ipairs(PARTS) do
    local ok, problem = pcall(require, part)
    if ok then
        loaded[#loaded + 1] = part
    else
        log("Could not load " .. part .. ": " .. tostring(problem))
    end
end
log("Loaded " .. #loaded .. " of " .. #PARTS .. " parts: " .. table.concat(loaded, ", "))
