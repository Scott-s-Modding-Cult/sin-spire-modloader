-- AnimationsPlus: a library of extra animations for Sin Spire mods.
--
--   local ok, AnimationsPlus = pcall(require, "AnimationsPlus")   -- pcall, so a mod still loads without it
--   for _, a in ipairs(AnimationsPlus.List({ kind = "pair", rig = "twisted", roles = { "taken", "futa" } })) do
--       print(a.id, a.title, a.length)
--   end
--   AnimationsPlus.Play("oll_kamasutra_libra_1", { taken = nurse.Mesh, futa = other.Mesh, shaft = shaft_component })
--   AnimationsPlus.Resync(other.Mesh, nurse.Mesh:GetPosition(), entry.length)    -- each tick, to keep them together
--
-- An entry describes one animation:
--   id, title, message     names for code, menus and logs
--   kind                   "pair" = two actors (plus attachments) on one origin and facing; place every role's actor
--                          at the same spot with the same yaw and they line up
--   rig                    the main skeleton: "twisted" = the Twisted Nurse's (SK_Twisted_Skeleton)
--   roles                  role name -> { anim = asset name, rig = skeleton, on = role it is attached to }
--                          pairs use taken (the nurse being taken), futa (the nurse with the shaft) and shaft
--                          (NurseTouch's SK_NurseShaft, attached to the futa's pelvis bone, snapped)
--   dir                    the package folder the clips are in
--   loop, length           seconds; loops close without a jump
--   climax, quiet_until, cum   seconds into the loop (cum = spurt times; the first is the climax), when there are any
--   tags                   e.g. "vaginal", "cowgirl", "floor"
--   private                true when made from someone else's animations and not to be published
--
-- Mods run in separate Lua states, so each mod that requires this gets its own copy of the catalogue. Register() adds
-- an entry for the calling mod only. Nothing here keeps a game object: clips are looked up each time they are needed.

local UEHelpers = require("UEHelpers")

local AnimationsPlus = { version = "1.0.0" }

local entries, by_id = {}, {}

local function add(entry)
    if type(entry) ~= "table" or type(entry.id) ~= "string" or type(entry.roles) ~= "table" or type(entry.dir) ~= "string" then
        return false
    end
    if by_id[entry.id] then
        for i, e in ipairs(entries) do
            if e.id == entry.id then
                table.remove(entries, i)
                break
            end
        end
    end
    table.insert(entries, entry)
    by_id[entry.id] = entry
    return true
end

local loaded, catalog = pcall(require, "AnimationsPlusCatalog")
if loaded and type(catalog) == "table" then
    AnimationsPlus.catalog_version = catalog.version
    for _, entry in ipairs(catalog.entries or {}) do
        add(entry)
    end
else
    print("[AnimationsPlus] Could not load the catalogue: " .. tostring(catalog) .. "\n")
end

local function has_tag(entry, tag)
    for _, t in ipairs(entry.tags or {}) do
        if t == tag then
            return true
        end
    end
    return false
end

-- Entries matching every field given: kind, rig, tag (one tag) or tags (all of them), roles (all of them).
function AnimationsPlus.List(filter)
    filter = filter or {}
    local out = {}
    for _, e in ipairs(entries) do
        local ok = (not filter.kind or e.kind == filter.kind) and (not filter.rig or e.rig == filter.rig)
            and (not filter.tag or has_tag(e, filter.tag))
        for _, t in ipairs(filter.tags or {}) do
            ok = ok and has_tag(e, t)
        end
        for _, r in ipairs(filter.roles or {}) do
            ok = ok and e.roles[r] ~= nil
        end
        if ok then
            table.insert(out, e)
        end
    end
    table.sort(out, function(a, b) return a.id < b.id end)
    return out
end

function AnimationsPlus.Get(id)
    return by_id[id]
end

function AnimationsPlus.Register(entry)
    return add(entry)
end

local function resolve(entry)
    if type(entry) == "string" then
        return by_id[entry]
    end
    return entry
end

-- The clip for one role, or nil. Mod paks are not in the game's asset registry, so it is found by package name.
function AnimationsPlus.Load(entry, role)
    entry = resolve(entry)
    local r = entry and entry.roles[role]
    if not r then
        return nil
    end
    local helpers = StaticFindObject("/Script/AssetRegistry.Default__AssetRegistryHelpers")
    if not helpers or not helpers:IsValid() then
        return nil
    end
    local asset = helpers:GetAsset({
        PackageName = UEHelpers.FindOrAddFName(entry.dir .. r.anim),
        AssetName = UEHelpers.FindOrAddFName(r.anim),
    })
    if asset and asset:IsValid() then
        return asset
    end
    return nil
end

-- Plays each given role's clip on its SkeletalMeshComponent, looping, from start_seconds. Every frame is evaluated,
-- so meshes that must match cannot read different update steps. Returns true, or false and the missing roles.
function AnimationsPlus.Play(entry, components, start_seconds)
    entry = resolve(entry)
    if not entry then
        return false, "unknown animation"
    end
    local clips, missing = {}, {}
    for role, component in pairs(components) do
        local clip = AnimationsPlus.Load(entry, role)
        if clip and component and component:IsValid() then
            clips[role] = clip
        else
            table.insert(missing, role)
        end
    end
    if #missing > 0 then
        return false, table.concat(missing, ", ")
    end
    for role, component in pairs(components) do
        component.bEnableUpdateRateOptimizations = false
        component.VisibilityBasedAnimTickOption = 1 -- AlwaysTickPose
        component:PlayAnimation(clips[role], entry.loop ~= false)
        if start_seconds and start_seconds > 0 then
            component:SetPosition(start_seconds, false)
        end
    end
    return true
end

-- Keeps one clip on another's time: small gaps close by playing up to 15% faster or slower, big ones (over a second)
-- jump. Jumping on every small gap snapped whole poses in NurseTouch's pairs. The gap is taken the short way round.
function AnimationsPlus.Resync(component, position, length)
    local behind = (position - component:GetPosition()) % length
    if behind > length / 2 then
        behind = behind - length
    end
    if math.abs(behind) > 1.0 then
        component:SetPosition(position, false)
        component:SetPlayRate(1.0)
    else
        component:SetPlayRate(1.0 + math.max(-0.15, math.min(0.15, behind * 0.6)))
    end
end

return AnimationsPlus
