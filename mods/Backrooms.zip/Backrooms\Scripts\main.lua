-- The Backrooms: a door in the Starting Hall and in Free Mode leads to a dungeon of Backrooms rooms, built the way the
-- game builds its own dungeons. On arrival this script adds the game's dungeon manager and one of the game's floor builders
-- for each floor, between 3 and 10 of them, and the game does the rest: its loading screen and the build of each floor
-- from the Backrooms rooms, with the player and enemies paused until it is done. The rooms are the mod's own maps, so
-- this script points the builder at them, gives each room the doorway grid the builder reads, and adds what the game's
-- rooms carry: the travel doors between floors, enemy spawners, key stands, map tiles and pickups. The main map is the
-- Lobby, the starting zone, with a door up to the first floor and one back out. The last floor ends in a door back out.
--
-- The game can delete any object and reuse its memory at any moment, so objects are looked up again each tick, except
-- those added for a room while the builder is still working on it, which are checked before use.

local UEHelpers = require("UEHelpers")
local ModSettings = require("ModSettings")
local layout = require("layout")

local hum_volume = ModSettings.AddSlider({
    mod = "Backrooms",
    key = "BackroomsHumVolume",
    label = "Backrooms Hum Volume",
    tab = "audio",
    min = 0,
    max = 100,
    step = 5,
    default = 50,
    format = "%d%%",
})
local NORMAL_VOLUME_SETTING = 50.0
local HUM_BASE_VOLUME = 0.06

local MAP_PATH = "/Game/Mods/Backrooms/Backrooms"
local MAP_NAME = "backrooms"
local ROOM_PATH = "/Game/Mods/Backrooms/Rooms/"
-- LoadLevelInstance refuses a mod's map: its check does not go by the files, and a game map passes where a mod's does
-- not. So the builder is given the names of game maps it never uses here, and each room is pointed at its Backrooms map
-- before it starts loading. These come from the game's unused test dungeon, one per room in layout order; there are
-- enough for 28 normal rooms.
local STAND_IN_ROOMS = { "Test_HallwayCorner", "Test_HallwayCrossRoads", "Test_HallwayGeneric", "Test_HallwayJunction",
    "Test_Hallway_SpikeTrap", "Test_MediumSmallRoom", "Test_OpenHall", "Test_RoomLarge", "Test_RoomMassive",
    "Test_SmallRoom", "Test_Level2Start", "Test_Level2End", "Test_Hallway_SpikeTrap_2X" }
for level_number = 3, 10 do
    table.insert(STAND_IN_ROOMS, "Test_Level" .. level_number .. "Start")
    table.insert(STAND_IN_ROOMS, "Test_Level" .. level_number .. "End")
end
local STAND_IN_START, STAND_IN_END = "Test_Level1Start", "Test_Level1End"

local ENTRY_DOOR_ID = "BackroomsEntry" -- The door you came through, as the game tracks it across a level change.
local RETURN_DOOR_ID = "BackroomsReturn"
local ENTER_REQUESTS_VARIABLE = "Backrooms_EnterRequests" -- AdminPanel adds to this for its button.
-- Levels that get a door in, by map name in lower case, and the name to open when coming back. After the opening the
-- game sends people to StartingHall_Destroyed, not StartingHall, so that is the hall almost everyone is in.
local DOOR_LEVELS = {
    startinghall_destroyed = "StartingHall_Destroyed",
    startinghall = "StartingHall",
    freemode = "FreeMode",
}
local DEFAULT_RETURN_MAP = "StartingHall_Destroyed"
-- Where to look for a wall from, when the level's PlayerStart is not where people arrive. If there is no floor under
-- it, the PlayerStart is used after all. StartingHall_Destroyed's PlayerStart is on the raised floor people arrive on.
local DOOR_SEARCH_FROM = {
    startinghall = { X = 0.0, Y = -1095.0 },
}
-- The game's own doors, which the Backrooms door must not stand beside or in front of.
local GAME_DOOR_CLASSES = { "BP_BaseAreaDoor_C", "BP_BossDoor_C", "BP_DoorPortal_C", "BP_DoubleDoor_C", "BP_OpenableDoor_C",
    "BP_LocalTravellingDoor_C", "BP_SlidingDoor_C", "BP_DoorApartment_C" }
local GAME_DOOR_CLEARANCE_CM = 500.0

-- The game's dungeon pieces, as package and class.
local PIECES = {
    manager = { "/Game/Maps/BP_DungeonManager", "BP_DungeonManager_C" },
    builder = { "/Game/Blueprints/DungeonGenerator/Generator/DungeonBuilder", "DungeonBuilder_C" },
    canvas = { "/Game/Blueprints/DungeonGenerator/SubLevels/Blueprint/BP_Canvas_Small", "BP_Canvas_Small_C" },
    map_helper = { "/MapSystem/Core/BP_MapHelper", "BP_MapHelper_C" },
    map_plane = { "/Game/Blueprints/UI/Map/BP_MapPlaneactor", "BP_MapPlaneactor_C" },
    pause = { "/Game/Blueprints/Player/BP_PauseManager", "BP_PauseManager_C" },
    travel_door = { "/Game/Blueprints/Objects/Doors/BP_LocalTravellingDoor_Child", "BP_LocalTravellingDoor_Child_C" },
    spawner = { "/Game/Blueprints/AI/Spawners/BP_AISpawner", "BP_AISpawner_C" },
    key_stand = { "/Game/Blueprints/Objects/BP_KeyStand", "BP_KeyStand_C" },
    player_spawn = { "/Game/Blueprints/Player/BP_PlayerSpawn", "BP_PlayerSpawn_C" },
}
local EVENT_LIBRARY = "/Script/EasyEventSystem.Default__EasyEventManagerLibrary"

-- The dungeon. Floors are stacked 1000 cm apart like the game's, above the Lobby, each built around the middle.
local FLOORS_MIN, FLOORS_MAX = 3, 10
local ROOMS_MIN, ROOMS_MAX = 14, 22 -- Per floor; the game's own dungeons use 20.
local FLOOR_SPACING_CM, FLOOR_OFFSET_CM = 1000.0, 500.0
local MAP_HELPER_Z_CM = 15000.0
local BUILDER_SETTINGS = { -- As the game's own floors have them.
    ChanceForRare = 20, MaxNumberOfRare = 1, DistanceForRare = 4000.0, MaxNumberOfExit = 1, DistanceForExit = 40000.0,
}
local ROOM_SCALE = layout.room_cm / 2000.0 -- The grid's doorways are 1000 cm from its middle at a scale of 1.
local CONNECTED_STATES = { [1] = true, [2] = true } -- A doorway the builder joined to another room.
local OPEN_STATE, CLOSED_STATE = 0, 3
local PLUG_TAG = "BR_Plug"
local PLUG_MATCH_CM = 150.0
local LOBBY_NAME = "The Lobby"
local EXIT_TAG = "BR_Exit"
local LOCK_CHANCE = 0.15 -- That a floor's exit is locked until its key is found, as in the game's floors.
local KEY_STAND_CHANCE = 0.3 -- Per room; the key manager keeps one stand per floor and clears the rest.
local SPAWNER_CHANCE = 0.45 -- Per room, for enemies.
local PICKUP_CHANCE = 0.35 -- Per room.
local SPAWNER_Z_CM = 0.0 -- The spawner itself lifts what it spawns by 88 cm.
local PICKUP_Z_CM = 30.0
local KEY_STAND_Z_CM = 0.0
local MONSTERS = {
    { class = { "/Game/Blueprints/AI/Enemies/BP_Smiler", "BP_Smiler_C" },
      controller = { "/Game/Blueprints/AI/Behaviours/Smiler/BPAI_Smiler", "BPAI_Smiler_C" }, weight = 3 },
    { class = { "/Game/Blueprints/AI/Enemies/BP_Mannequin", "BP_Mannequin_C" },
      controller = { "/Game/Blueprints/AI/Behaviours/Mannequin/BPAI_Mannequin", "BPAI_Mannequin_C" }, weight = 2 },
    { class = { "/Game/Blueprints/AI/Enemies/BP_LostSoul", "BP_LostSoul_C" },
      controller = { "/Game/Blueprints/AI/Behaviours/LostSoul/BPAI_LostSoul", "BPAI_LostSoul_C" }, weight = 1 },
}
local PICKUPS = {
    { "/Game/Blueprints/Weapons/Pickups/BP_PistolAmmo_Pickup", "BP_PistolAmmo_Pickup_C" },
    { "/Game/Blueprints/Weapons/Pickups/BP_RifleAmmoPickup", "BP_RifleAmmoPickup_C" },
    { "/Game/Blueprints/Weapons/Pickups/BP_Buckshot_Pickup", "BP_Buckshot_Pickup_C" },
}
local GENERATION_TIMEOUT_SECONDS = 180.0
local SPAWN_COLLISION_ALWAYS = 1
local SCALE_MULTIPLY_WITH_ROOT = 1

-- BP_BaseAreaDoor's only visible part is a stretched placeholder cube, so it gets one of the game's doors instead.
local DOOR_PACKAGE, DOOR_CLASS = "/Game/Blueprints/Objects/Doors/BP_BaseAreaDoor", "BP_BaseAreaDoor_C"
local DOOR_MESH_PACKAGE, DOOR_MESH_NAME = "/Game/Models/Environment/Slaughterhouse/SM_DoorMetalSL", "SM_DoorMetalSL"
local DOOR_LIGHT_COLOUR = { R = 1.0, G = 0.8, B = 0.45, A = 1.0 }
local DOOR_LIGHT_INTENSITY = 4000.0
local DOOR_LIGHT_RADIUS_CM = 700.0
local DOOR_LIGHT_OUT_CM, DOOR_LIGHT_UP_CM = 120.0, 260.0
local MOBILITY_MOVABLE = 2

local TICK_MS = 100
local DOOR_DELAY_SECONDS = 2.0
local PLAYER_STATE_DELAY_SECONDS = 0.3
local WALL_TOUCH_CM = 2.0
local DOOR_MAX_HEIGHT_CM = 280.0
local DOOR_SCAN_DIRECTIONS = 24
local DOOR_SCAN_HEIGHT_CM = 120.0
local DOOR_SCAN_TOP_CM = 260.0
local DOOR_CLEAR_CM, DOOR_CLEAR_HEIGHT_CM = 250.0, 50.0
local DOOR_SCAN_MIN_CM, DOOR_SCAN_MAX_CM = 200.0, 2500.0
local DOOR_HALF_WIDTH_CM = 120.0
local DOOR_FLAT_TOLERANCE_CM = 15.0
local TRACE_CHANNEL_VISIBILITY = 0
local DRAW_NO_DEBUG = 0
local NO_COLOUR = { R = 0, G = 0, B = 0, A = 0 }

local world_address = nil
local level = nil -- What is under way in the current level: { name, clock, ... }
local return_map = DEFAULT_RETURN_MAP
local enter_requests_seen = 0

local function log(message)
    print("[Backrooms] " .. message .. "\n")
end

-- LoadAsset only finds assets in the game's asset registry, which a mod pak is not part of.
local function load_by_package(package_name, asset_name)
    local helpers = StaticFindObject("/Script/AssetRegistry.Default__AssetRegistryHelpers")
    if not helpers:IsValid() then
        return nil
    end
    local asset = helpers:GetAsset({
        PackageName = UEHelpers.FindOrAddFName(package_name),
        AssetName = UEHelpers.FindOrAddFName(asset_name),
    })
    if asset:IsValid() then
        return asset
    end
    log("Could not load " .. asset_name)
    return nil
end

local function current_player()
    local player = FindFirstOf("BP_PlayerCharacter_C")
    if player and player:IsValid() then
        return player
    end
    return nil
end

local function game_instance()
    local instance = FindFirstOf("BP_VeleroGameInstance_C")
    if instance and instance:IsValid() then
        return instance
    end
    return nil
end

local function trace(context, from, to)
    local hit = {}
    local found = UEHelpers.GetKismetSystemLibrary():LineTraceSingle(context, from, to, TRACE_CHANNEL_VISIBILITY, false, {},
        DRAW_NO_DEBUG, hit, true, NO_COLOUR, NO_COLOUR, 0.0)
    if found and hit.ImpactPoint and hit.ImpactPoint.X then
        return hit
    end
    return nil
end

-- The hall and the Backrooms are both dim, so a light on the door is what makes it stand out from across the room.
local function place_door_light(x, y, z)
    local class = StaticFindObject("/Script/Engine.PointLight")
    local light = UEHelpers.GetWorld():SpawnActor(class, { X = x, Y = y, Z = z }, { Pitch = 0, Yaw = 0, Roll = 0 })
    if not light or not light:IsValid() then
        log("Could not spawn the door's light")
        return
    end
    local component = light.PointLightComponent
    component:SetMobility(MOBILITY_MOVABLE)
    component:SetLightColor(DOOR_LIGHT_COLOUR, true)
    component:SetIntensity(DOOR_LIGHT_INTENSITY)
    component:SetAttenuationRadius(DOOR_LIGHT_RADIUS_CM)
end

local function dress_door(door, front_angle)
    local mesh = load_by_package(DOOR_MESH_PACKAGE, DOOR_MESH_NAME)
    if not mesh then
        return
    end
    local component = door.StaticMesh
    local hit = {}
    component:SetStaticMesh(mesh)
    component:SetRelativeScale3D({ X = 1, Y = 1, Z = 1 })
    component:K2_SetRelativeLocation({ X = 0, Y = 0, Z = 0 }, false, hit, false)
    -- A door's thin side has to face the way the door opens onto, whichever axis its model was made along.
    local centre, extent = {}, {}
    door:GetActorBounds(true, centre, extent, false)
    local front_is_x = math.abs(math.cos(math.rad(front_angle))) > 0.5
    if (front_is_x and extent.X > extent.Y) or (not front_is_x and extent.Y > extent.X) then
        component:K2_SetRelativeRotation({ Pitch = 0, Yaw = 90, Roll = 0 }, false, hit, false)
    end
end

-- Stands an actor with a SpawnPoint arrow, like the game's doors, against a wall. X and Y are on the wall's face, yaw
-- points out of the wall, and floor_z is under it. The mesh is not centred on its origin, so this measures it unrotated,
-- where its box fits it tightly, and moves it into place. Measured at an angle, the box is far deeper than the door.
-- dress is called with the door unrotated, for changes that alter its size. Returns the door's height.
local function stand_against_wall(door, x, y, floor_z, yaw, dress)
    door:K2_SetActorRotation({ Pitch = 0, Yaw = 0, Roll = 0 }, false)
    local origin = door:K2_GetActorLocation()
    local front = door.SpawnPoint:K2_GetComponentLocation()
    local front_angle = math.deg(math.atan(front.Y - origin.Y, front.X - origin.X))
    if dress then
        dress(door, front_angle)
    end

    local centre, extent = {}, {}
    door:GetActorBounds(true, centre, extent, false)
    if extent.Z * 2.0 > DOOR_MAX_HEIGHT_CM then
        local scale = DOOR_MAX_HEIGHT_CM / (extent.Z * 2.0)
        door:SetActorScale3D({ X = scale, Y = scale, Z = scale })
        door:GetActorBounds(true, centre, extent, false)
    end
    origin = door:K2_GetActorLocation()
    local offset_x, offset_y, offset_z = centre.X - origin.X, centre.Y - origin.Y, centre.Z - origin.Z
    local out_x, out_y = math.cos(math.rad(yaw)), math.sin(math.rad(yaw))
    local front_x, front_y = math.cos(math.rad(front_angle)), math.sin(math.rad(front_angle))
    local depth = math.abs(extent.X * front_x) + math.abs(extent.Y * front_y)

    -- Which way the door opens onto is where it puts people arriving through it, so that side must face out of the wall.
    local turn = math.rad(yaw - front_angle)
    local turned_x = offset_x * math.cos(turn) - offset_y * math.sin(turn)
    local turned_y = offset_x * math.sin(turn) + offset_y * math.cos(turn)
    local hit = {}
    door:K2_SetActorRotation({ Pitch = 0, Yaw = yaw - front_angle, Roll = 0 }, false)
    door:K2_SetActorLocation({
        X = x + out_x * (depth + WALL_TOUCH_CM) - turned_x,
        Y = y + out_y * (depth + WALL_TOUCH_CM) - turned_y,
        Z = floor_z + extent.Z - offset_z,
    }, false, hit, false)
    return extent.Z * 2.0
end

-- A door back to a level outside: the game's area door, dressed as a metal door with a light over it.
local function place_door(x, y, floor_z, yaw, door_id, map_name)
    local class = load_by_package(DOOR_PACKAGE, DOOR_CLASS)
    if not class then
        return nil
    end
    local door = UEHelpers.GetWorld():SpawnActor(class, { X = x, Y = y, Z = floor_z }, { Pitch = 0, Yaw = yaw, Roll = 0 })
    if not door or not door:IsValid() then
        log("Could not spawn a door")
        return nil
    end
    door.DoorID = UEHelpers.FindOrAddFName(door_id)
    door.MapName = UEHelpers.FindOrAddFName(map_name)
    door.CanAutosave = false -- An autosave here would record a map the Continue button may not find.
    door.NeedsConfirmation = false
    door.Interactable = true
    door.BP_InteractableObject.CanInteract = true
    local height = stand_against_wall(door, x, y, floor_z, yaw, dress_door)
    local out_x, out_y = math.cos(math.rad(yaw)), math.sin(math.rad(yaw))
    place_door_light(x + out_x * DOOR_LIGHT_OUT_CM, y + out_y * DOOR_LIGHT_OUT_CM, floor_z + DOOR_LIGHT_UP_CM)
    log(string.format("Door %s at %.0f, %.0f, %.0f facing %.0f, %.0f cm tall, leads to %s", door_id, x, y, floor_z, yaw, height, map_name))
    return door
end

-- Puts the player in front of a door they have just come through.
local function put_player_at_door(door)
    local player = current_player()
    if not player then
        return
    end
    local spot = door.SpawnPoint:K2_GetComponentLocation()
    local rotation = door.SpawnPoint:K2_GetComponentRotation()
    local hit = {}
    player:K2_SetActorLocation({ X = spot.X, Y = spot.Y, Z = spot.Z + 100.0 }, false, hit, true)
    local controller = player.Controller
    if controller:IsValid() then
        controller:SetControlRotation({ Pitch = 0, Yaw = rotation.Yaw, Roll = 0 })
    end
end

local function game_door_spots()
    local spots = {}
    for _, class in ipairs(GAME_DOOR_CLASSES) do
        local doors = FindAllOf(class)
        if doors then
            for _, door in ipairs(doors) do
                if door:IsValid() and not door:GetFullName():find("Default__", 1, true) then
                    table.insert(spots, door:K2_GetActorLocation())
                end
            end
        end
    end
    return spots
end

local function near_game_door(spots, x, y)
    for _, spot in ipairs(spots) do
        if (spot.X - x) ^ 2 + (spot.Y - y) ^ 2 < GAME_DOOR_CLEARANCE_CM ^ 2 then
            return true
        end
    end
    return false
end

local search_around

-- Looks around the level's start for a stretch of flat wall, the same one every time because the start does not move.
local function find_door_wall(context, level_name)
    local start = FindFirstOf("PlayerStart")
    if not start or not start:IsValid() then
        return nil
    end
    local from = start:K2_GetActorLocation()
    local search_from = DOOR_SEARCH_FROM[level_name]
    if search_from then
        local wall = search_around(context, { X = search_from.X, Y = search_from.Y, Z = from.Z })
        if wall then
            return wall
        end
        log("Nothing at the set search point in " .. level_name .. ", searching from the PlayerStart")
    end
    return search_around(context, from)
end

search_around = function(context, from)
    local floor_hit = trace(context, from, { X = from.X, Y = from.Y, Z = from.Z - 500.0 })
    if not floor_hit then
        return nil
    end
    local doors = game_door_spots()
    local floor_z = floor_hit.ImpactPoint.Z
    local at = { X = from.X, Y = from.Y, Z = floor_z + DOOR_SCAN_HEIGHT_CM }
    local best = nil
    for step = 0, DOOR_SCAN_DIRECTIONS - 1 do
        local angle = step * 2.0 * math.pi / DOOR_SCAN_DIRECTIONS
        local dx, dy = math.cos(angle), math.sin(angle)
        local hit = trace(context, at, { X = at.X + dx * DOOR_SCAN_MAX_CM, Y = at.Y + dy * DOOR_SCAN_MAX_CM, Z = at.Z })
        if hit and math.abs(hit.ImpactNormal.Z) < 0.1 then
            local distance = math.sqrt((hit.ImpactPoint.X - at.X) ^ 2 + (hit.ImpactPoint.Y - at.Y) ^ 2)
            if distance >= DOOR_SCAN_MIN_CM and (not best or distance < best.distance)
                and not near_game_door(doors, hit.ImpactPoint.X, hit.ImpactPoint.Y) then
                local side_x, side_y = -hit.ImpactNormal.Y, hit.ImpactNormal.X
                local flat = true
                for _, side in ipairs({ -DOOR_HALF_WIDTH_CM, DOOR_HALF_WIDTH_CM }) do
                    local probe = {
                        X = hit.ImpactPoint.X + side_x * side + hit.ImpactNormal.X * 60.0,
                        Y = hit.ImpactPoint.Y + side_y * side + hit.ImpactNormal.Y * 60.0,
                        Z = at.Z,
                    }
                    -- Checked up the door's whole height, as furniture and pedestals are flat too, but shorter than a wall.
                    for _, height in ipairs({ DOOR_SCAN_HEIGHT_CM, DOOR_SCAN_TOP_CM }) do
                        local side_hit = trace(context, { X = probe.X, Y = probe.Y, Z = floor_z + height }, {
                            X = probe.X - hit.ImpactNormal.X * (60.0 + DOOR_FLAT_TOLERANCE_CM),
                            Y = probe.Y - hit.ImpactNormal.Y * (60.0 + DOOR_FLAT_TOLERANCE_CM),
                            Z = floor_z + height,
                        })
                        if not side_hit then
                            flat = false
                        end
                    end
                    local spot_floor = trace(context, probe, { X = probe.X, Y = probe.Y, Z = floor_z - 30.0 })
                    if not spot_floor or math.abs(spot_floor.ImpactPoint.Z - floor_z) > DOOR_FLAT_TOLERANCE_CM then
                        flat = false
                    end
                    -- Furniture in front would block the way to the door, and trap people arriving through it.
                    local clear_from = { X = probe.X, Y = probe.Y, Z = floor_z + DOOR_CLEAR_HEIGHT_CM }
                    if trace(context, clear_from, {
                        X = probe.X + hit.ImpactNormal.X * DOOR_CLEAR_CM,
                        Y = probe.Y + hit.ImpactNormal.Y * DOOR_CLEAR_CM,
                        Z = clear_from.Z,
                    }) then
                        flat = false
                    end
                end
                if flat then
                    best = {
                        distance = distance,
                        x = hit.ImpactPoint.X,
                        y = hit.ImpactPoint.Y,
                        yaw = math.deg(math.atan(hit.ImpactNormal.Y, hit.ImpactNormal.X)),
                    }
                end
            end
        end
    end
    if best then
        best.floor_z = floor_z
    end
    return best
end

-- Restores the weapons and stats saved by the door the player left through. The game's own doors do this when they load
-- in the new level, but ours are placed too late to match, so it is done here.
local function finish_arrival(state)
    local instance = game_instance()
    if not instance or not state.arriving then
        return
    end
    if os.clock() - state.clock < PLAYER_STATE_DELAY_SECONDS or not current_player() then
        return
    end
    state.arriving = false
    instance:LoadPlayerState()
    log("Player state restored")
end

local function check_arrival(state)
    local instance = game_instance()
    if not instance or not instance.LoadingThroughDoor then
        return
    end
    local door_id = instance.CurrentDoorID:ToString()
    if door_id == ENTRY_DOOR_ID or door_id == RETURN_DOOR_ID then
        instance.LoadingThroughDoor = false
        state.arriving = true
        state.through = door_id
        log("Arrived through " .. door_id)
    end
end

-- Runs whenever the slider moves, so the hum can be turned down from the pause menu while standing in it.
local function apply_hum_volume(state)
    if state.hum_applied == hum_volume.value then
        return
    end
    local sound = FindFirstOf("AmbientSound")
    if sound and sound:IsValid() then
        sound.AudioComponent:SetVolumeMultiplier(HUM_BASE_VOLUME * hum_volume.value / NORMAL_VOLUME_SETTING)
        state.hum_applied = hum_volume.value
    end
end

-- Without this the player reloads the whole level on death, and with it a new layout, which would wipe out the run.
local function place_respawn()
    local start = FindFirstOf("PlayerStart")
    local class = load_by_package(PIECES.player_spawn[1], PIECES.player_spawn[2])
    if class and start and start:IsValid() then
        UEHelpers.GetWorld():SpawnActor(class, start:K2_GetActorLocation(), { Pitch = 0, Yaw = 0, Roll = 0 })
    end
end

local function gameplay_statics()
    return StaticFindObject("/Script/Engine.Default__GameplayStatics")
end

-- One part of starting or ending the load. A part that fails is logged and the rest still run, so that a missing piece
-- can never leave the loading screen up or the player frozen.
local function step(what, action)
    local ok, problem = pcall(action)
    if not ok then
        log(what .. " failed: " .. tostring(problem))
    end
end

local function is_live(object)
    return object and object:IsValid() and not object:GetFullName():find("Default__", 1, true)
end

local function pause_manager()
    local manager = FindFirstOf(PIECES.pause[2])
    if is_live(manager) then
        return manager
    end
    return nil
end

-- The game's levels each have a pause manager placed in them; the Backrooms map does not, and its doors need one.
local function ensure_pause_manager()
    if pause_manager() then
        return
    end
    local class = load_by_package(PIECES.pause[1], PIECES.pause[2])
    if class then
        UEHelpers.GetWorld():SpawnActor(class, { X = 0, Y = 0, Z = 0 }, { Pitch = 0, Yaw = 0, Roll = 0 })
        log("Added a pause manager")
    end
end

local function fname(text)
    return UEHelpers.FindOrAddFName(text)
end

local function piece(key)
    return load_by_package(PIECES[key][1], PIECES[key][2])
end

local function set_name_array(object, property, names)
    local array = object[property]
    array:Empty()
    for i, name in ipairs(names) do
        array[i] = fname(name)
    end
end

local function has_tag(actor, tag)
    local tags = actor.Tags
    for i = 1, #tags do
        if tags[i]:ToString() == tag then
            return true
        end
    end
    return false
end

local function make_transform(x, y, z, yaw, scale_xy)
    local half = math.rad(yaw) / 2.0
    scale_xy = scale_xy or 1.0
    return {
        Rotation = { X = 0.0, Y = 0.0, Z = math.sin(half), W = math.cos(half) },
        Translation = { X = x, Y = y, Z = z },
        Scale3D = { X = scale_xy, Y = scale_xy, Z = 1.0 },
    }
end

-- Spawns an actor with its settings made before it starts, as the game's own pieces read theirs on BeginPlay.
local function spawn_deferred(class, transform, setup)
    local statics = gameplay_statics()
    local actor = statics:BeginDeferredActorSpawnFromClass(UEHelpers.GetWorld(), class, transform, SPAWN_COLLISION_ALWAYS, nil,
        SCALE_MULTIPLY_WITH_ROOT)
    if not actor or not actor:IsValid() then
        return nil
    end
    if setup then
        setup(actor)
    end
    actor = statics:FinishSpawningActor(actor, transform, SCALE_MULTIPLY_WITH_ROOT)
    if actor and actor:IsValid() then
        return actor
    end
    return nil
end

local function call_event(context, name, message)
    StaticFindObject(EVENT_LIBRARY):CallEvent(context, fname(name), message or "", nil)
end

-- The rooms by the stand-in name the builder is given for each, and the roles' names for the builders.
local rooms_by_stand_in = {}
local stand_ins = { room = {}, hallway = {}, rare = {} }
local lobby_room = nil
do
    local next_stand_in = 1
    for _, room in ipairs(layout.rooms) do
        local stand_in = nil
        if room.role == "start" then
            stand_in = STAND_IN_START
        elseif room.role == "end" then
            stand_in = STAND_IN_END
        elseif room.role == "hub" then
            lobby_room = room
        else
            stand_in = STAND_IN_ROOMS[next_stand_in]
            next_stand_in = next_stand_in + 1
            if stand_in then
                table.insert(stand_ins[room.role], stand_in)
            else
                log("No stand-in name left for " .. room.name .. "; add more to STAND_IN_ROOMS")
            end
        end
        if stand_in then
            rooms_by_stand_in[stand_in] = room
        end
    end
end

-- Where a point given from a room's middle is in the world.
local function in_world(record, local_x, local_y)
    local c, s = math.cos(math.rad(record.yaw)), math.sin(math.rad(record.yaw))
    return record.x + local_x * c - local_y * s, record.y + local_x * s + local_y * c
end

local function floor_of(z)
    return math.floor((z - FLOOR_OFFSET_CM) / FLOOR_SPACING_CM + 0.5) + 1
end

local function floor_z(floor)
    return FLOOR_OFFSET_CM + (floor - 1) * FLOOR_SPACING_CM
end

local function door_ids(floor, last)
    return {
        start = "BR_Start" .. floor,
        start_target = floor == 1 and "BR_Lobby" or ("BR_End" .. (floor - 1)),
        start_next = floor == last and EXIT_TAG or ("BR_End" .. floor),
        finish = "BR_End" .. floor,
        finish_target = "BR_Start" .. (floor + 1),
        finish_next = "BR_Start" .. floor,
    }
end

local function floor_title(floor)
    return "Level " .. floor
end

-- A travel door between floors: the game's own, which finds its way by the ids and shows the floor's name on arrival.
local function place_travel_door(record, spot, id, target, next_target, title, lock_chance)
    local class = piece("travel_door")
    if not class then
        return nil
    end
    local x, y = in_world(record, spot[1], spot[2])
    local yaw = record.yaw + spot[3]
    local door = spawn_deferred(class, make_transform(x, y, record.z, yaw), function(door)
        door.DoorID = fname(id) -- Becomes its only tag on BeginPlay, which is how the other end finds it.
        door.TargetDoorID = fname(target)
        door.NextTarget = fname(next_target)
        door.FloorName = FText(title)
        door.Locked = false
        door.ChanceToBeLocked = lock_chance or 0.0
        door.IsFinalDoor = false
    end)
    if not door then
        log("Could not spawn travel door " .. id)
        return nil
    end
    stand_against_wall(door, x, y, record.z, yaw)
    return door
end

local function pick_monster()
    local total = 0
    for _, monster in ipairs(MONSTERS) do
        total = total + monster.weight
    end
    local roll = math.random() * total
    for _, monster in ipairs(MONSTERS) do
        roll = roll - monster.weight
        if roll <= 0 then
            return monster
        end
    end
    return MONSTERS[1]
end

-- The doorway grid the builder reads for a room. The game's rooms carry theirs; these are added at the room's place as it
-- is asked for, tagged New as the builder expects, with each side's middle doorway open if the room has one there.
local function place_canvas(record)
    local class = piece("canvas")
    if not class then
        return nil
    end
    return spawn_deferred(class, make_transform(record.x, record.y, record.z, record.yaw, ROOM_SCALE), function(canvas)
        for _, side in ipairs({ "N", "S", "E", "W" }) do
            canvas["CP_" .. side .. "_00"] = record.room.doorways:find(side, 1, true) and OPEN_STATE or CLOSED_STATE
            canvas["CP_" .. side .. "_01"] = CLOSED_STATE
            canvas["CP_" .. side .. "_02"] = CLOSED_STATE
        end
        set_name_array(canvas, "Tags", { "New" })
    end)
end

-- The tile that shows the room on the game's map. The map is drawn from these when the dungeon is done.
local function place_map_tile(record)
    local class = piece("map_plane")
    if not class then
        return nil
    end
    local tile = UEHelpers.GetWorld():SpawnActor(class, { X = record.x, Y = record.y, Z = record.z + 5.0 },
        { Pitch = 0, Yaw = record.yaw, Roll = 0 })
    if not tile or not tile:IsValid() then
        return nil
    end
    local centre, extent = {}, {}
    tile:GetActorBounds(false, centre, extent, false)
    if extent.X > 1.0 and extent.Y > 1.0 then
        tile:SetActorScale3D({ X = layout.room_cm / 2.0 / extent.X, Y = layout.room_cm / 2.0 / extent.Y, Z = 1.0 })
    end
    return tile
end

-- What a normal room carries in the game: now and then an enemy spawner, a key stand or something to pick up.
local function furnish_room(record, add)
    local spots = {}
    for _, spot in ipairs(record.room.spots) do
        table.insert(spots, spot)
    end
    local function take_spot()
        if #spots == 0 then
            return nil
        end
        local spot = table.remove(spots, math.random(#spots))
        local x, y = in_world(record, spot[1], spot[2])
        return x, y
    end
    local world = UEHelpers.GetWorld()
    if math.random() < SPAWNER_CHANCE then
        local x, y = take_spot()
        local monster = pick_monster()
        local class = load_by_package(monster.class[1], monster.class[2])
        local controller = load_by_package(monster.controller[1], monster.controller[2])
        local spawner_class = piece("spawner")
        if x and class and controller and spawner_class then
            add(spawn_deferred(spawner_class, make_transform(x, y, record.z + SPAWNER_Z_CM, math.random(0, 359)), function(spawner)
                spawner.AIClass = class
                spawner.AIControllerClass = controller
                spawner.UseChance = false
            end))
        end
    end
    if not record.last_floor and math.random() < KEY_STAND_CHANCE then
        local x, y = take_spot()
        local class = piece("key_stand")
        if x and class then
            add(world:SpawnActor(class, { X = x, Y = y, Z = record.z + KEY_STAND_Z_CM }, { Pitch = 0, Yaw = math.random(0, 359), Roll = 0 }))
        end
    end
    if math.random() < PICKUP_CHANCE then
        local x, y = take_spot()
        local pickup = PICKUPS[math.random(#PICKUPS)]
        local class = load_by_package(pickup[1], pickup[2])
        if x and class then
            add(world:SpawnActor(class, { X = x, Y = y, Z = record.z + PICKUP_Z_CM }, { Pitch = 0, Yaw = math.random(0, 359), Roll = 0 }))
        end
    end
end

-- Everything a room needs besides its own map, added as the builder asks for the room. Rooms it only measures, at the
-- middle of the Lobby's floor, get just their grid.
local function add_room_pieces(record)
    local function add(actor)
        if actor and actor:IsValid() then
            table.insert(record.actors, actor)
        end
    end
    add(place_canvas(record))
    if record.z < FLOOR_OFFSET_CM - FLOOR_SPACING_CM / 2.0 then
        return
    end
    local dungeon = level.dungeon
    local floor = floor_of(record.z)
    record.last_floor = floor >= dungeon.floors
    add(place_map_tile(record))
    local ids = door_ids(floor, dungeon.floors)
    local role = record.room.role
    if role == "start" then
        add(place_travel_door(record, record.room.door, ids.start, ids.start_target, ids.start_next, floor_title(floor), 0.0))
    elseif role == "end" then
        if record.last_floor then
            local x, y = in_world(record, record.room.door[1], record.room.door[2])
            local door = place_door(x, y, record.z, record.yaw + record.room.door[3], RETURN_DOOR_ID, return_map)
            if door then
                local tags = door.Tags
                tags[#tags + 1] = fname(EXIT_TAG) -- For the start door's compass.
                add(door)
            end
        else
            add(place_travel_door(record, record.room.door, ids.finish, ids.finish_target, ids.finish_next, floor_title(floor),
                LOCK_CHANCE))
        end
    else
        furnish_room(record, add)
    end
end

local rooms_in_play = {} -- By the address of the room's streaming level, while the builder has it.

local function on_room_loading(streaming, should_load)
    if not level or level.name ~= MAP_NAME or not level.dungeon then
        return
    end
    local key = streaming:GetAddress()
    if not should_load then
        -- The builder has finished measuring the room, or found it overlapping another and is trying something else.
        local record = rooms_in_play[key]
        if record then
            rooms_in_play[key] = nil
            for _, actor in ipairs(record.actors) do
                if actor:IsValid() then
                    actor:K2_DestroyActor()
                end
            end
        end
        return
    end
    if rooms_in_play[key] then
        return
    end
    local short = streaming.PackageNameToLoad:ToString():match("([^/%.]+)$")
    local room = short and rooms_by_stand_in[short]
    if not room then
        return
    end
    streaming.PackageNameToLoad = fname(ROOM_PATH .. room.name)
    local transform = streaming.LevelTransform
    local q = transform.Rotation
    local record = {
        room = room,
        actors = {},
        x = transform.Translation.X,
        y = transform.Translation.Y,
        z = transform.Translation.Z,
        yaw = math.deg(math.atan(2.0 * (q.W * q.Z + q.X * q.Y), 1.0 - 2.0 * (q.Y * q.Y + q.Z * q.Z))),
    }
    rooms_in_play[key] = record
    level.dungeon.rooms_asked = level.dungeon.rooms_asked + 1
    add_room_pieces(record)
end

local hooked = false
local function hook_room_loading()
    if hooked then
        return
    end
    hooked = true
    for _, name in ipairs({ "/Script/Engine.LevelStreaming:SetShouldBeLoaded", "/Script/Engine.LevelStreamingDynamic:SetShouldBeLoaded" }) do
        if StaticFindObject(name):IsValid() then
            RegisterHook(name, function(context, should_load)
                local ok, problem = pcall(on_room_loading, context:get(), should_load:get())
                if not ok then
                    log("Room hook failed: " .. tostring(problem))
                end
            end)
            log("Hooked " .. name)
        end
    end
end

-- The game's map: one entry per floor, by height, with the Lobby first, as the game's own dungeons have it.
local MAP_FLOOR_FIELDS = {
    min = "WorldHeightMin_14_6B8BA296490583F42F559EB69B753228",
    max = "WorldHeightMax_16_5BF30CF0423022B8463C498F8DC110C8",
    mesh_min = "MapMeshHeight_11_51CA75234E399BC38D707A9D279A9B73",
    mesh_max = "MapMeshHeightMax_13_E429635141AB052EA2DA25A9F05CB091",
    name = "Name_20_ECF8810D43ECBFCE9400E09049C0E2B3",
}

local function place_map_helper(floors)
    local class = piece("map_helper")
    if not class then
        return
    end
    spawn_deferred(class, make_transform(0.0, 0.0, MAP_HELPER_Z_CM, 0.0), function(helper)
        helper.InDungeon = true -- Otherwise it draws an empty map at once, before the manager asks for the real one.
        local entries = helper.Floors
        entries:Empty()
        for floor = 0, floors do
            local low = floor == 0 and -FLOOR_SPACING_CM or (floor_z(floor) - FLOOR_OFFSET_CM)
            local high = floor == 0 and (FLOOR_OFFSET_CM - 1.0) or (floor_z(floor) + FLOOR_OFFSET_CM - 1.0)
            entries[floor + 1] = {
                [MAP_FLOOR_FIELDS.min] = low,
                [MAP_FLOOR_FIELDS.max] = high,
                [MAP_FLOOR_FIELDS.mesh_min] = low,
                [MAP_FLOOR_FIELDS.mesh_max] = high,
                [MAP_FLOOR_FIELDS.name] = FText(floor == 0 and LOBBY_NAME or floor_title(floor)),
            }
        end
        log("Map has " .. #helper.Floors .. " floors")
    end)
end

local function place_builder(floor, floors)
    local class = piece("builder")
    if not class then
        return
    end
    spawn_deferred(class, make_transform(0.0, 0.0, floor_z(floor), 0.0), function(builder)
        builder.Spawn = fname(STAND_IN_START)
        set_name_array(builder, "ExitLevelNames", { STAND_IN_END })
        set_name_array(builder, "LevelNames", stand_ins.room)
        set_name_array(builder, "HallwayLevelNames", stand_ins.hallway)
        local normal = {}
        for _, name in ipairs(stand_ins.room) do table.insert(normal, name) end
        for _, name in ipairs(stand_ins.hallway) do table.insert(normal, name) end
        set_name_array(builder, "NormalLevelNames", normal)
        set_name_array(builder, "RareLevelNames", stand_ins.rare)
        for setting, value in pairs(BUILDER_SETTINGS) do
            builder[setting] = value
        end
        builder.MaxRoomNumber = math.random(ROOMS_MIN, ROOMS_MAX)
        -- Measure the rooms afresh, rather than use the measurements the game keeps from its last dungeon.
        builder.FirstInitialize = true
        builder.UseRandomSeed = true
        builder.DungeonName = "BRDung" .. floor
    end)
end

-- The Lobby's own two doors: up to the first floor, and back out.
local function place_lobby_doors()
    local record = { room = lobby_room, x = 0.0, y = 0.0, z = 0.0, yaw = 0.0 }
    local ids = door_ids(1, level.dungeon.floors)
    place_travel_door(record, lobby_room.door, "BR_Lobby", ids.start, ids.start, LOBBY_NAME, 0.0)
    place_door(lobby_room.exit[1], lobby_room.exit[2], 0.0, lobby_room.exit[3], RETURN_DOOR_ID, return_map)
    place_map_tile(record)
end

local function begin_dungeon(world)
    local dungeon = { floors = math.random(FLOORS_MIN, FLOORS_MAX), clock = os.clock(), rooms_asked = 0 }
    level.dungeon = dungeon
    rooms_in_play = {}
    hook_room_loading()
    place_respawn()
    ensure_pause_manager()
    step("Lobby doors", place_lobby_doors)
    step("Map", function() place_map_helper(dungeon.floors) end)
    for floor = 1, dungeon.floors do
        step("Builder " .. floor, function() place_builder(floor, dungeon.floors) end)
    end
    -- Last, as the manager collects the builders when it starts and puts up the loading screen.
    local manager = piece("manager")
    if manager then
        world:SpawnActor(manager, { X = 0, Y = 0, Z = 0 }, { Pitch = 0, Yaw = 0, Roll = 0 })
    end
    log(string.format("Building %d floors", dungeon.floors))
end

-- Doorways the builder joined to another room lose their plug; the rest stay walled off.
local function open_joined_doorways()
    local joined = {}
    for _, canvas in ipairs(FindAllOf(PIECES.canvas[2]) or {}) do
        if is_live(canvas) then
            local points = canvas.AllConnectionPoints
            for i = 1, #points do
                local point = points[i]
                if point:IsValid() and point.Type == 0 and CONNECTED_STATES[point.State] then
                    table.insert(joined, point:K2_GetActorLocation())
                end
            end
        end
    end
    local opened, plugs = 0, 0
    for _, actor in ipairs(FindAllOf("StaticMeshActor") or {}) do
        if is_live(actor) and has_tag(actor, PLUG_TAG) then
            plugs = plugs + 1
            local at = actor:K2_GetActorLocation()
            local forward = actor:GetActorForwardVector()
            local x, y = at.X + forward.X * layout.room_cm / 2.0, at.Y + forward.Y * layout.room_cm / 2.0
            for _, point in ipairs(joined) do
                if math.abs(point.Z - at.Z) < 100.0 and (point.X - x) ^ 2 + (point.Y - y) ^ 2 < PLUG_MATCH_CM ^ 2 then
                    actor:SetActorHiddenInGame(true)
                    actor:SetActorEnableCollision(false)
                    opened = opened + 1
                    break
                end
            end
        end
    end
    log(string.format("Opened %d of %d doorways (%d joins)", opened, plugs, #joined))
end

local function finish_dungeon(dungeon)
    dungeon.finished = true
    step("Doorways", open_joined_doorways)
    local player = current_player()
    local context = player or FindFirstOf(PIECES.manager[2])
    if is_live(context) then
        -- Without the game's AI manager, which would swap in its own enemies, the spawners are told to go here.
        step("Enemies", function() call_event(context, "SpawnAllAI") end)
        -- Enemies on other floors than the player's sleep until the player arrives there, as in the game's dungeons.
        local z = player and player:K2_GetActorLocation().Z or 0.0
        step("Floor", function() call_event(context, "SwitchedFloor", string.format("%.1f", z)) end)
    else
        log("Nothing to send the enemy events from")
    end
    local counts = {}
    for _, key in ipairs({ "canvas", "travel_door", "spawner", "key_stand", "map_plane" }) do
        local n = 0
        for _, actor in ipairs(FindAllOf(PIECES[key][2]) or {}) do
            if is_live(actor) then
                n = n + 1
            end
        end
        table.insert(counts, key .. " " .. n)
    end
    log(string.format("Dungeon ready after %.1f s: %d floors, %d rooms asked for, %s", os.clock() - dungeon.clock,
        dungeon.floors, dungeon.rooms_asked, table.concat(counts, ", ")))
end

local function update_backrooms(world, state)
    apply_hum_volume(state)
    local dungeon = state.dungeon
    if not dungeon then
        if current_player() then
            begin_dungeon(world)
        end
        return
    end
    if dungeon.finished then
        return
    end
    local manager = FindFirstOf(PIECES.manager[2])
    if not is_live(manager) then
        return
    end
    if manager.IsGenerating then
        dungeon.started = true
    elseif dungeon.started then
        finish_dungeon(dungeon)
        return
    end
    if os.clock() - dungeon.clock > GENERATION_TIMEOUT_SECONDS and not dungeon.forced then
        -- The manager's last step waits on the map; if that never answers, this lets the player in rather than leave them.
        dungeon.forced = true
        log("The dungeon is taking too long; finishing it as it is")
        step("Forcing the end", function() manager:FinishedGeneratingMap_Event() end)
    end
end

local function update_door_level(state)
    if state.door_done or os.clock() - state.clock < DOOR_DELAY_SECONDS or not current_player() then
        return
    end
    state.door_done = true
    return_map = DOOR_LEVELS[state.name]
    local wall = find_door_wall(current_player(), state.name)
    if not wall then
        log("No wall found for the door in " .. state.name)
        return
    end
    local door = place_door(wall.x, wall.y, wall.floor_z, wall.yaw, ENTRY_DOOR_ID, MAP_PATH)
    if door and state.through == RETURN_DOOR_ID then
        put_player_at_door(door)
    end
end

-- The admin panel's button goes the same way as walking through a door, so nothing is lost.
local function update_enter_requests()
    local total = ModRef:GetSharedVariable(ENTER_REQUESTS_VARIABLE) or 0
    if total <= enter_requests_seen then
        return
    end
    local player = current_player()
    local instance = game_instance()
    if not player or not instance or StaticFindObject("/Script/Engine.Default__GameplayStatics"):IsGamePaused(player) then
        return
    end
    enter_requests_seen = total
    if level and DOOR_LEVELS[level.name] then
        return_map = DOOR_LEVELS[level.name]
    end
    instance:SavePlayerState(player)
    instance.CurrentDoorID = UEHelpers.FindOrAddFName(ENTRY_DOOR_ID)
    instance.LoadingThroughDoor = true
    StaticFindObject("/Script/Engine.Default__GameplayStatics"):OpenLevel(player, UEHelpers.FindOrAddFName(MAP_PATH), true, "")
    log("Entering by request")
end

local function begin_level(world)
    world_address = world:GetAddress()
    level = { name = world:GetFName():ToString():lower(), clock = os.clock() }
    log("Level " .. level.name)
end

LoopInGameThreadWithDelay(TICK_MS, function()
    -- A script error here would otherwise stop this loop for the rest of the session.
    local ok, problem = pcall(function()
        local world = UEHelpers.GetWorld()
        if not world or not world:IsValid() then
            return
        end
        if world:GetAddress() ~= world_address then
            begin_level(world)
        end
        if not level.checked_arrival and current_player() then
            level.checked_arrival = true
            check_arrival(level)
        end
        finish_arrival(level)
        if level.name == MAP_NAME then
            update_backrooms(world, level)
        elseif DOOR_LEVELS[level.name] then
            update_door_level(level)
        end
        update_enter_requests()
    end)
    if not ok then
        log("Tick failed, trying again: " .. tostring(problem))
    end
    ModSettings.Poll()
end)

math.randomseed(os.time())
log("Loaded.")
