-- The Backrooms: a door in the Starting Hall and in Free Mode leads to a level put together at random on each visit.
-- The level is a grid of tiles with baked lighting, all with their openings in the same places, so any tile fits beside
-- any other. The tile in the corner is the entrance and is part of the map; the rest are streamed in here. A door
-- somewhere far from the entrance leads back out, and it is never in the same place twice running.
--
-- The game can delete any object and reuse its memory at any moment, so nothing here keeps a game object between ticks.

local UEHelpers = require("UEHelpers")
local ModSettings = require("ModSettings")
local layout = require("layout")

local hum_volume = ModSettings.AddSlider({
    mod = "Backrooms",
    key = "BackroomsHumVolume",
    label = "Backrooms Hum Volume",
    tab = "audio",
    min = 0,
    max = 100,
    step = 5,
    default = 50,
    format = "%d%%",
})
local NORMAL_VOLUME_SETTING = 50.0
local HUM_BASE_VOLUME = 0.06

local MAP_PATH = "/Game/Mods/Backrooms/Backrooms"
local MAP_NAME = "backrooms"
local TILE_PATH = "/Game/Mods/Backrooms/Tiles/BR_Tile_%02dT"
-- LoadLevelInstance refuses a mod's map: its check does not go by the files, and a game map passes where a mod's does
-- not. So each call names this map of the game's, and the request is pointed at the tile before anything starts loading.
local PASSES_CHECK_MAP = "/Game/Maps/LustDungeon/SubLevels/Lust_RoomLarge"
local DOOR_PACKAGE, DOOR_CLASS = "/Game/Blueprints/Objects/Doors/BP_BaseAreaDoor", "BP_BaseAreaDoor_C"
local PLAYER_SPAWN_PACKAGE, PLAYER_SPAWN_CLASS = "/Game/Blueprints/Player/BP_PlayerSpawn", "BP_PlayerSpawn_C"
local ENTRY_DOOR_ID = "BackroomsEntry" -- The door you came through, as the game tracks it across a level change.
local RETURN_DOOR_ID = "BackroomsReturn"
local ENTER_REQUESTS_VARIABLE = "Backrooms_EnterRequests" -- AdminPanel adds to this for its button.
-- Levels that get a door in, by map name in lower case, and the name to open when coming back.
local DOOR_LEVELS = { startinghall = "StartingHall", freemode = "FreeMode" }
local DEFAULT_RETURN_MAP = "StartingHall"
-- Where to look for a wall from, when the level's PlayerStart is not where people arrive.
local DOOR_SEARCH_FROM = { startinghall = { X = 0.0, Y = -1095.0 } }
-- BP_BaseAreaDoor's only visible part is a stretched placeholder cube, so it gets one of the game's doors instead.
local DOOR_MESH_PACKAGE, DOOR_MESH_NAME = "/Game/Models/Environment/Slaughterhouse/SM_DoorMetalSL", "SM_DoorMetalSL"
local DOOR_LIGHT_COLOUR = { R = 1.0, G = 0.8, B = 0.45, A = 1.0 }
local DOOR_LIGHT_INTENSITY = 4000.0
local DOOR_LIGHT_RADIUS_CM = 700.0
local DOOR_LIGHT_OUT_CM, DOOR_LIGHT_UP_CM = 120.0, 260.0
local MOBILITY_MOVABLE = 2

local TICK_MS = 100
local DOOR_DELAY_SECONDS = 2.0
local TILE_LOAD_TIMEOUT_SECONDS = 10.0
local CONTENTS_DELAY_SECONDS = 4.0 -- Lets the navigation catch up with the new tiles before anything walks on it.
local PLAYER_STATE_DELAY_SECONDS = 0.3
local WALL_TOUCH_CM = 2.0
local DOOR_MAX_HEIGHT_CM = 280.0
local DOOR_SCAN_DIRECTIONS = 24
local DOOR_SCAN_HEIGHT_CM = 120.0
local DOOR_SCAN_TOP_CM = 260.0
local DOOR_CLEAR_CM, DOOR_CLEAR_HEIGHT_CM = 250.0, 50.0
local DOOR_SCAN_MIN_CM, DOOR_SCAN_MAX_CM = 200.0, 2500.0
local DOOR_HALF_WIDTH_CM = 120.0
local DOOR_FLAT_TOLERANCE_CM = 15.0
local MIN_EXIT_TILE_DISTANCE = 3 -- In tiles from the entrance, counting along the grid.
local MONSTERS_MIN, MONSTERS_MAX = 5, 8
local MONSTER_MIN_TILE_DISTANCE = 2
local MONSTER_Z_CM = 110.0
local MONSTERS = {
    { package = "/Game/Blueprints/AI/Enemies/BP_Smiler", class = "BP_Smiler_C", weight = 3 },
    { package = "/Game/Blueprints/AI/Enemies/BP_Mannequin", class = "BP_Mannequin_C", weight = 2 },
    { package = "/Game/Blueprints/AI/Enemies/BP_LostSoul", class = "BP_LostSoul_C", weight = 1 },
}
local PICKUPS_MIN, PICKUPS_MAX = 8, 14
local PICKUP_Z_CM = 30.0
local PICKUPS = {
    { package = "/Game/Blueprints/Weapons/Pickups/BP_PistolAmmo_Pickup", class = "BP_PistolAmmo_Pickup_C" },
    { package = "/Game/Blueprints/Weapons/Pickups/BP_RifleAmmoPickup", class = "BP_RifleAmmoPickup_C" },
    { package = "/Game/Blueprints/Weapons/Pickups/BP_Buckshot_Pickup", class = "BP_Buckshot_Pickup_C" },
}
local TRACE_CHANNEL_VISIBILITY = 0
local DRAW_NO_DEBUG = 0
local NO_COLOUR = { R = 0, G = 0, B = 0, A = 0 }

local world_address = nil
local level = nil -- What is under way in the current level: { name, clock, ... }
local return_map = DEFAULT_RETURN_MAP
local enter_requests_seen = 0
local grid = {} -- Which tile variant is at each grid spot in the current visit, as grid[x][y].

local function log(message)
    print("[Backrooms] " .. message .. "\n")
end

-- LoadAsset only finds assets in the game's asset registry, which a mod pak is not part of.
local function load_by_package(package_name, asset_name)
    local helpers = StaticFindObject("/Script/AssetRegistry.Default__AssetRegistryHelpers")
    if not helpers:IsValid() then
        return nil
    end
    local asset = helpers:GetAsset({
        PackageName = UEHelpers.FindOrAddFName(package_name),
        AssetName = UEHelpers.FindOrAddFName(asset_name),
    })
    if asset:IsValid() then
        return asset
    end
    log("Could not load " .. asset_name)
    return nil
end

local function current_player()
    local player = FindFirstOf("BP_PlayerCharacter_C")
    if player and player:IsValid() then
        return player
    end
    return nil
end

local function game_instance()
    local instance = FindFirstOf("BP_VeleroGameInstance_C")
    if instance and instance:IsValid() then
        return instance
    end
    return nil
end

local function trace(context, from, to)
    local hit = {}
    local found = UEHelpers.GetKismetSystemLibrary():LineTraceSingle(context, from, to, TRACE_CHANNEL_VISIBILITY, false, {},
        DRAW_NO_DEBUG, hit, true, NO_COLOUR, NO_COLOUR, 0.0)
    if found and hit.ImpactPoint and hit.ImpactPoint.X then
        return hit
    end
    return nil
end

-- The hall and the Backrooms are both dim, so a light on the door is what makes it stand out from across the room.
local function place_door_light(x, y, z)
    local class = StaticFindObject("/Script/Engine.PointLight")
    local light = UEHelpers.GetWorld():SpawnActor(class, { X = x, Y = y, Z = z }, { Pitch = 0, Yaw = 0, Roll = 0 })
    if not light or not light:IsValid() then
        log("Could not spawn the door's light")
        return
    end
    local component = light.PointLightComponent
    component:SetMobility(MOBILITY_MOVABLE)
    component:SetLightColor(DOOR_LIGHT_COLOUR, true)
    component:SetIntensity(DOOR_LIGHT_INTENSITY)
    component:SetAttenuationRadius(DOOR_LIGHT_RADIUS_CM)
end

local function dress_door(door, front_angle)
    local mesh = load_by_package(DOOR_MESH_PACKAGE, DOOR_MESH_NAME)
    if not mesh then
        return
    end
    local component = door.StaticMesh
    local hit = {}
    component:SetStaticMesh(mesh)
    component:SetRelativeScale3D({ X = 1, Y = 1, Z = 1 })
    component:K2_SetRelativeLocation({ X = 0, Y = 0, Z = 0 }, false, hit, false)
    -- A door's thin side has to face the way the door opens onto, whichever axis its model was made along.
    local centre, extent = {}, {}
    door:GetActorBounds(true, centre, extent, false)
    local front_is_x = math.abs(math.cos(math.rad(front_angle))) > 0.5
    if (front_is_x and extent.X > extent.Y) or (not front_is_x and extent.Y > extent.X) then
        component:K2_SetRelativeRotation({ Pitch = 0, Yaw = 90, Roll = 0 }, false, hit, false)
    end
end

-- Stands a door against a wall. X and Y are on the wall's face, yaw points out of the wall, and floor_z is under it.
-- The door's mesh is not centred on its origin, so this measures it unrotated, where its box fits it tightly, and moves it
-- into place. Measured at an angle, the box is far deeper than the door, which would leave it standing off the wall.
local function place_door(x, y, floor_z, yaw, door_id, map_name)
    local class = load_by_package(DOOR_PACKAGE, DOOR_CLASS)
    if not class then
        return nil
    end
    local door = UEHelpers.GetWorld():SpawnActor(class, { X = x, Y = y, Z = floor_z }, { Pitch = 0, Yaw = yaw, Roll = 0 })
    if not door or not door:IsValid() then
        log("Could not spawn a door")
        return nil
    end
    door.DoorID = UEHelpers.FindOrAddFName(door_id)
    door.MapName = UEHelpers.FindOrAddFName(map_name)
    door.CanAutosave = false -- An autosave here would record a map the Continue button may not find.
    door.NeedsConfirmation = false
    door.Interactable = true
    door.BP_InteractableObject.CanInteract = true

    door:K2_SetActorRotation({ Pitch = 0, Yaw = 0, Roll = 0 }, false)
    local origin = door:K2_GetActorLocation()
    local front = door.SpawnPoint:K2_GetComponentLocation()
    local front_angle = math.deg(math.atan(front.Y - origin.Y, front.X - origin.X))
    dress_door(door, front_angle)

    local centre, extent = {}, {}
    door:GetActorBounds(true, centre, extent, false)
    if extent.Z * 2.0 > DOOR_MAX_HEIGHT_CM then
        local scale = DOOR_MAX_HEIGHT_CM / (extent.Z * 2.0)
        door:SetActorScale3D({ X = scale, Y = scale, Z = scale })
        door:GetActorBounds(true, centre, extent, false)
    end
    origin = door:K2_GetActorLocation()
    local offset_x, offset_y, offset_z = centre.X - origin.X, centre.Y - origin.Y, centre.Z - origin.Z
    local out_x, out_y = math.cos(math.rad(yaw)), math.sin(math.rad(yaw))
    local front_x, front_y = math.cos(math.rad(front_angle)), math.sin(math.rad(front_angle))
    local depth = math.abs(extent.X * front_x) + math.abs(extent.Y * front_y)

    -- Which way the door opens onto is where it puts people arriving through it, so that side must face out of the wall.
    local turn = math.rad(yaw - front_angle)
    local turned_x = offset_x * math.cos(turn) - offset_y * math.sin(turn)
    local turned_y = offset_x * math.sin(turn) + offset_y * math.cos(turn)
    local hit = {}
    door:K2_SetActorRotation({ Pitch = 0, Yaw = yaw - front_angle, Roll = 0 }, false)
    door:K2_SetActorLocation({
        X = x + out_x * (depth + WALL_TOUCH_CM) - turned_x,
        Y = y + out_y * (depth + WALL_TOUCH_CM) - turned_y,
        Z = floor_z + extent.Z - offset_z,
    }, false, hit, false)
    place_door_light(x + out_x * DOOR_LIGHT_OUT_CM, y + out_y * DOOR_LIGHT_OUT_CM, floor_z + DOOR_LIGHT_UP_CM)
    log(string.format("Door %s at %.0f, %.0f, %.0f facing %.0f, %.0f cm tall, leads to %s", door_id, x, y, floor_z, yaw, extent.Z * 2.0, map_name))
    return door
end

-- Puts the player in front of a door they have just come through.
local function put_player_at_door(door)
    local player = current_player()
    if not player then
        return
    end
    local spot = door.SpawnPoint:K2_GetComponentLocation()
    local rotation = door.SpawnPoint:K2_GetComponentRotation()
    local hit = {}
    player:K2_SetActorLocation({ X = spot.X, Y = spot.Y, Z = spot.Z + 100.0 }, false, hit, true)
    local controller = player.Controller
    if controller:IsValid() then
        controller:SetControlRotation({ Pitch = 0, Yaw = rotation.Yaw, Roll = 0 })
    end
end

-- Looks around the level's start for a stretch of flat wall, the same one every time because the start does not move.
local function find_door_wall(context, level_name)
    local start = FindFirstOf("PlayerStart")
    if not start or not start:IsValid() then
        return nil
    end
    local from = start:K2_GetActorLocation()
    local search_from = DOOR_SEARCH_FROM[level_name]
    if search_from then
        from.X, from.Y = search_from.X, search_from.Y
    end
    local floor_hit = trace(context, from, { X = from.X, Y = from.Y, Z = from.Z - 500.0 })
    if not floor_hit then
        return nil
    end
    local floor_z = floor_hit.ImpactPoint.Z
    local at = { X = from.X, Y = from.Y, Z = floor_z + DOOR_SCAN_HEIGHT_CM }
    local best = nil
    for step = 0, DOOR_SCAN_DIRECTIONS - 1 do
        local angle = step * 2.0 * math.pi / DOOR_SCAN_DIRECTIONS
        local dx, dy = math.cos(angle), math.sin(angle)
        local hit = trace(context, at, { X = at.X + dx * DOOR_SCAN_MAX_CM, Y = at.Y + dy * DOOR_SCAN_MAX_CM, Z = at.Z })
        if hit and math.abs(hit.ImpactNormal.Z) < 0.1 then
            local distance = math.sqrt((hit.ImpactPoint.X - at.X) ^ 2 + (hit.ImpactPoint.Y - at.Y) ^ 2)
            if distance >= DOOR_SCAN_MIN_CM and (not best or distance < best.distance) then
                local side_x, side_y = -hit.ImpactNormal.Y, hit.ImpactNormal.X
                local flat = true
                for _, side in ipairs({ -DOOR_HALF_WIDTH_CM, DOOR_HALF_WIDTH_CM }) do
                    local probe = {
                        X = hit.ImpactPoint.X + side_x * side + hit.ImpactNormal.X * 60.0,
                        Y = hit.ImpactPoint.Y + side_y * side + hit.ImpactNormal.Y * 60.0,
                        Z = at.Z,
                    }
                    -- Checked up the door's whole height, as furniture and pedestals are flat too, but shorter than a wall.
                    for _, height in ipairs({ DOOR_SCAN_HEIGHT_CM, DOOR_SCAN_TOP_CM }) do
                        local side_hit = trace(context, { X = probe.X, Y = probe.Y, Z = floor_z + height }, {
                            X = probe.X - hit.ImpactNormal.X * (60.0 + DOOR_FLAT_TOLERANCE_CM),
                            Y = probe.Y - hit.ImpactNormal.Y * (60.0 + DOOR_FLAT_TOLERANCE_CM),
                            Z = floor_z + height,
                        })
                        if not side_hit then
                            flat = false
                        end
                    end
                    local spot_floor = trace(context, probe, { X = probe.X, Y = probe.Y, Z = floor_z - 30.0 })
                    if not spot_floor or math.abs(spot_floor.ImpactPoint.Z - floor_z) > DOOR_FLAT_TOLERANCE_CM then
                        flat = false
                    end
                    -- Furniture in front would block the way to the door, and trap people arriving through it.
                    local clear_from = { X = probe.X, Y = probe.Y, Z = floor_z + DOOR_CLEAR_HEIGHT_CM }
                    if trace(context, clear_from, {
                        X = probe.X + hit.ImpactNormal.X * DOOR_CLEAR_CM,
                        Y = probe.Y + hit.ImpactNormal.Y * DOOR_CLEAR_CM,
                        Z = clear_from.Z,
                    }) then
                        flat = false
                    end
                end
                if flat then
                    best = {
                        distance = distance,
                        x = hit.ImpactPoint.X,
                        y = hit.ImpactPoint.Y,
                        yaw = math.deg(math.atan(hit.ImpactNormal.Y, hit.ImpactNormal.X)),
                    }
                end
            end
        end
    end
    if best then
        best.floor_z = floor_z
    end
    return best
end

-- Restores the weapons and stats saved by the door the player left through. The game's own doors do this when they load
-- in the new level, but ours are placed too late to match, so it is done here.
local function finish_arrival(state)
    local instance = game_instance()
    if not instance or not state.arriving then
        return
    end
    if os.clock() - state.clock < PLAYER_STATE_DELAY_SECONDS or not current_player() then
        return
    end
    state.arriving = false
    instance:LoadPlayerState()
    log("Player state restored")
end

local function check_arrival(state)
    local instance = game_instance()
    if not instance or not instance.LoadingThroughDoor then
        return
    end
    local door_id = instance.CurrentDoorID:ToString()
    if door_id == ENTRY_DOOR_ID or door_id == RETURN_DOOR_ID then
        instance.LoadingThroughDoor = false
        state.arriving = true
        state.through = door_id
        log("Arrived through " .. door_id)
    end
end

-- Picks a variant for each spot. Each is used once before any repeats, and never right beside a copy of itself.
local function arrange_tiles()
    local bag = {}
    grid = {}
    local function draw(avoid_a, avoid_b)
        if #bag == 0 then
            for variant = 1, layout.tile_variants do
                bag[variant] = variant
            end
            for i = #bag, 2, -1 do
                local j = math.random(i)
                bag[i], bag[j] = bag[j], bag[i]
            end
        end
        for i = #bag, 1, -1 do
            if bag[i] ~= avoid_a and bag[i] ~= avoid_b then
                return table.remove(bag, i)
            end
        end
        return table.remove(bag)
    end
    for x = 0, layout.grid_tiles - 1 do
        grid[x] = {}
        for y = 0, layout.grid_tiles - 1 do
            if x > 0 or y > 0 then
                grid[x][y] = draw(x > 0 and grid[x - 1][y] or nil, y > 0 and grid[x][y - 1] or nil)
            end
        end
    end
end

-- Asks for one tile. Tiles are asked for one at a time, as the game's own dungeon builder does, because requests made
-- together do not all arrive.
local function stream_tile(world, spot)
    local library = StaticFindObject("/Script/Engine.Default__LevelStreamingDynamic")
    local streaming_class = StaticFindObject("/Script/Engine.LevelStreamingDynamic")
    local success = {}
    local streaming = library:LoadLevelInstance(world, PASSES_CHECK_MAP,
        { X = spot.x * layout.tile_cm, Y = spot.y * layout.tile_cm, Z = 0.0 }, { Pitch = 0, Yaw = 0, Roll = 0 }, success,
        "", streaming_class, false)
    if streaming and streaming:IsValid() then
        streaming.PackageNameToLoad = UEHelpers.FindOrAddFName(string.format(TILE_PATH, grid[spot.x][spot.y]))
        streaming.bShouldBlockOnLoad = true -- A hitch now is better than walking into the void.
        return true
    end
    log(string.format("Tile %d at %d, %d did not start loading", grid[spot.x][spot.y], spot.x, spot.y))
    return false
end

local function tiles_loaded()
    local loaded = 0
    local streaming = FindAllOf("LevelStreamingDynamic")
    if streaming then
        for _, level_streaming in ipairs(streaming) do
            if level_streaming:IsValid() and level_streaming:IsLevelLoaded() then
                loaded = loaded + 1
            end
        end
    end
    return loaded
end

local function random_cell_in_tile(x, y)
    return (x + (math.random(layout.tile_cells) - 0.5) / layout.tile_cells) * layout.tile_cm,
        (y + (math.random(layout.tile_cells) - 0.5) / layout.tile_cells) * layout.tile_cm
end

local function spots_away_from_entrance(min_distance)
    local spots = {}
    for x = 0, layout.grid_tiles - 1 do
        for y = 0, layout.grid_tiles - 1 do
            if x + y >= min_distance then
                table.insert(spots, { x = x, y = y })
            end
        end
    end
    return spots
end

local function place_exit()
    local spots = spots_away_from_entrance(MIN_EXIT_TILE_DISTANCE)
    local spot = spots[math.random(#spots)]
    local choices = layout.exits[grid[spot.x][spot.y]]
    local choice = choices[math.random(#choices)]
    local x, y = spot.x * layout.tile_cm + choice.X, spot.y * layout.tile_cm + choice.Y
    log(string.format("Exit in tile %d, %d", spot.x, spot.y))
    return place_door(x, y, 0.0, choice.Yaw, RETURN_DOOR_ID, return_map)
end

local function pick_monster()
    local total = 0
    for _, monster in ipairs(MONSTERS) do
        total = total + monster.weight
    end
    local roll = math.random() * total
    for _, monster in ipairs(MONSTERS) do
        roll = roll - monster.weight
        if roll <= 0 then
            return monster
        end
    end
    return MONSTERS[1]
end

local function place_monsters()
    local world = UEHelpers.GetWorld()
    local spots = spots_away_from_entrance(MONSTER_MIN_TILE_DISTANCE)
    local placed = 0
    for _ = 1, math.random(MONSTERS_MIN, MONSTERS_MAX) do
        local monster = pick_monster()
        local class = load_by_package(monster.package, monster.class)
        local spot = spots[math.random(#spots)]
        local x, y = random_cell_in_tile(spot.x, spot.y)
        local actor = class and world:SpawnActor(class, { X = x, Y = y, Z = MONSTER_Z_CM }, { Pitch = 0, Yaw = math.random(0, 359), Roll = 0 })
        if actor and actor:IsValid() then
            if not actor.Controller:IsValid() then
                actor:SpawnDefaultController()
            end
            placed = placed + 1
            log(string.format("%s at %.0f, %.0f, controller %s", monster.class, x, y, tostring(actor.Controller:IsValid())))
        end
    end
    log(string.format("Placed %d monsters", placed))
end

local function place_pickups()
    local world = UEHelpers.GetWorld()
    local spots = spots_away_from_entrance(1)
    local placed = 0
    for _ = 1, math.random(PICKUPS_MIN, PICKUPS_MAX) do
        local pickup = PICKUPS[math.random(#PICKUPS)]
        local class = load_by_package(pickup.package, pickup.class)
        local spot = spots[math.random(#spots)]
        local x, y = random_cell_in_tile(spot.x, spot.y)
        local actor = class and world:SpawnActor(class, { X = x, Y = y, Z = PICKUP_Z_CM }, { Pitch = 0, Yaw = math.random(0, 359), Roll = 0 })
        if actor and actor:IsValid() then
            placed = placed + 1
        end
    end
    log(string.format("Placed %d pickups", placed))
end

-- Runs whenever the slider moves, so the hum can be turned down from the pause menu while standing in it.
local function apply_hum_volume(state)
    if state.hum_applied == hum_volume.value then
        return
    end
    local sound = FindFirstOf("AmbientSound")
    if sound and sound:IsValid() then
        sound.AudioComponent:SetVolumeMultiplier(HUM_BASE_VOLUME * hum_volume.value / NORMAL_VOLUME_SETTING)
        state.hum_applied = hum_volume.value
    end
end

-- Without this the player reloads the whole level on death, and with it a new layout, which would wipe out the run.
local function place_respawn()
    local start = FindFirstOf("PlayerStart")
    local class = load_by_package(PLAYER_SPAWN_PACKAGE, PLAYER_SPAWN_CLASS)
    if class and start and start:IsValid() then
        UEHelpers.GetWorld():SpawnActor(class, start:K2_GetActorLocation(), { Pitch = 0, Yaw = 0, Roll = 0 })
    end
end

local function update_backrooms(world, state)
    apply_hum_volume(state)
    if not state.tile_queue then
        arrange_tiles()
        state.tile_queue = {}
        for x = 0, layout.grid_tiles - 1 do
            for y = 0, layout.grid_tiles - 1 do
                if grid[x][y] then
                    table.insert(state.tile_queue, { x = x, y = y })
                end
            end
        end
        state.tiles_requested = 0
        state.tiles_given_up = 0
        state.clock_tiles = os.clock()
        state.clock_tile = 0.0
        place_respawn()
        return
    end
    if not state.tiles_ready then
        local loaded = tiles_loaded()
        local waiting = state.tiles_requested - state.tiles_given_up > loaded
        if waiting and os.clock() - state.clock_tile < TILE_LOAD_TIMEOUT_SECONDS then
            return
        end
        if waiting then
            state.tiles_given_up = state.tiles_requested - loaded
            log(string.format("Tile %d at %d, %d did not arrive in time", grid[state.last_tile.x][state.last_tile.y], state.last_tile.x, state.last_tile.y))
        end
        local spot = table.remove(state.tile_queue, 1)
        if spot then
            state.clock_tile = os.clock()
            state.last_tile = spot
            state.tiles_requested = state.tiles_requested + 1
            if not stream_tile(world, spot) then
                state.tiles_given_up = state.tiles_given_up + 1
            end
            return
        end
        state.tiles_ready = true
        state.clock_ready = os.clock()
        log(string.format("%d of %d tiles loaded after %.1f s", loaded, state.tiles_requested, os.clock() - state.clock_tiles))
        return
    end
    if not state.contents_placed and os.clock() - state.clock_ready >= CONTENTS_DELAY_SECONDS then
        state.contents_placed = true
        place_exit()
        place_monsters()
        place_pickups()
    end
end

local function update_door_level(state)
    if state.door_done or os.clock() - state.clock < DOOR_DELAY_SECONDS or not current_player() then
        return
    end
    state.door_done = true
    return_map = DOOR_LEVELS[state.name]
    local wall = find_door_wall(current_player(), state.name)
    if not wall then
        log("No wall found for the door in " .. state.name)
        return
    end
    local door = place_door(wall.x, wall.y, wall.floor_z, wall.yaw, ENTRY_DOOR_ID, MAP_PATH)
    if door and state.through == RETURN_DOOR_ID then
        put_player_at_door(door)
    end
end

-- The admin panel's button goes the same way as walking through a door, so nothing is lost.
local function update_enter_requests()
    local total = ModRef:GetSharedVariable(ENTER_REQUESTS_VARIABLE) or 0
    if total <= enter_requests_seen then
        return
    end
    local player = current_player()
    local instance = game_instance()
    if not player or not instance or StaticFindObject("/Script/Engine.Default__GameplayStatics"):IsGamePaused(player) then
        return
    end
    enter_requests_seen = total
    if level and DOOR_LEVELS[level.name] then
        return_map = DOOR_LEVELS[level.name]
    end
    instance:SavePlayerState(player)
    instance.CurrentDoorID = UEHelpers.FindOrAddFName(ENTRY_DOOR_ID)
    instance.LoadingThroughDoor = true
    StaticFindObject("/Script/Engine.Default__GameplayStatics"):OpenLevel(player, UEHelpers.FindOrAddFName(MAP_PATH), true, "")
    log("Entering by request")
end

local function begin_level(world)
    world_address = world:GetAddress()
    level = { name = world:GetFName():ToString():lower(), clock = os.clock() }
    log("Level " .. level.name)
end

LoopInGameThreadWithDelay(TICK_MS, function()
    -- A script error here would otherwise stop this loop for the rest of the session.
    local ok, problem = pcall(function()
        local world = UEHelpers.GetWorld()
        if not world or not world:IsValid() then
            return
        end
        if world:GetAddress() ~= world_address then
            begin_level(world)
        end
        if not level.checked_arrival and current_player() then
            level.checked_arrival = true
            check_arrival(level)
        end
        finish_arrival(level)
        if level.name == MAP_NAME then
            update_backrooms(world, level)
        elseif DOOR_LEVELS[level.name] then
            update_door_level(level)
        end
        update_enter_requests()
    end)
    if not ok then
        log("Tick failed, trying again: " .. tostring(problem))
    end
    ModSettings.Poll()
end)

math.randomseed(os.time())
log("Loaded.")
